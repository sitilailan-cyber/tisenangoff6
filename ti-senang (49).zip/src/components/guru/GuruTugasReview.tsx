import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  CheckCircle2,
  Clock,
  ExternalLink,
  FolderDown,
  Award,
  Search,
  Filter,
  MessageSquare,
  Sparkles,
  Zap,
  Check,
  Send,
  Brain,
  Star,
} from 'lucide-react';
import { StudentTaskSubmission, Mission, Student, StudentReflectionSubmission } from '../../types';
import { storage } from '../../services/storage';
import { exportRefleksiToPdf } from '../../utils/pdfExport';
import { exportRefleksiToExcel } from '../../utils/excelExport';
import { ExportDropdown } from '../common/ExportDropdown';

const STUDENT_DRIVE_FOLDER_URL =
  'https://drive.google.com/drive/folders/1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h?hl=ID';

interface GuruTugasReviewProps {
  classId: string;
  className: string;
  missions: Mission[];
  students: Student[];
}

export const GuruTugasReview: React.FC<GuruTugasReviewProps> = ({
  classId,
  className,
  missions,
  students,
}) => {
  const [tasks, setTasks] = useState<StudentTaskSubmission[]>([]);
  const [selectedTask, setSelectedTask] = useState<StudentTaskSubmission | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'SUBMITTED' | 'GRADED'>('ALL');
  const [activeSubTab, setActiveSubTab] = useState<'tugas' | 'refleksi'>('tugas');
  const [reflections, setReflections] = useState<StudentReflectionSubmission[]>([]);

  // Grading form state
  const [scoreInput, setScoreInput] = useState<number>(85);
  const [feedbackInput, setFeedbackInput] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Load submissions & reflections
  const loadTasks = () => {
    const all = storage.getStudentTasks();
    const classTasks = all.filter((t) => !classId || t.classId === classId);
    setTasks(classTasks);

    const allReflections = storage.getStudentReflections(classId);
    setReflections(allReflections);
  };

  useEffect(() => {
    loadTasks();
    // Listen for real-time task updates
    const handleTaskUpdated = () => {
      loadTasks();
    };
    window.addEventListener('tisenang_tasks_updated', handleTaskUpdated);
    window.addEventListener('tisenang_storage_updated', handleTaskUpdated);
    return () => {
      window.removeEventListener('tisenang_tasks_updated', handleTaskUpdated);
      window.removeEventListener('tisenang_storage_updated', handleTaskUpdated);
    };
  }, [classId]);

  // Filtered submissions
  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchSearch =
        (t.studentName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.missionId || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.content || '').toLowerCase().includes(searchQuery.toLowerCase());

      const matchStatus = filterStatus === 'ALL' || t.status === filterStatus;
      return matchSearch && matchStatus;
    });
  }, [tasks, searchQuery, filterStatus]);

  // Open modal for grading
  // Dapatkan link / file tugas hasil upload siswa langsung (bukan folder drive umum)
  const getDirectStudentFile = (task: StudentTaskSubmission | null) => {
    if (!task) return null;

    const isGenericFolder = (url?: string) => {
      if (!url) return true;
      const clean = url.trim().toLowerCase();
      return (
        clean === STUDENT_DRIVE_FOLDER_URL.toLowerCase() ||
        clean.includes('/drive/folders/') ||
        clean.includes('/folders/1xc-5y2') ||
        clean.includes('/folders/1hfwyt') ||
        (clean.includes('drive.google.com/drive/u/') && clean.includes('/folders'))
      );
    };

    // 1. Cek driveLink langsung pada submission tugas jika bukan folder umum
    if (task.driveLink && !isGenericFolder(task.driveLink)) {
      return {
        url: task.driveLink,
        isDrive: true,
        displayName: task.driveLink,
      };
    }

    // 2. Cek apakah ada tautan link drive file di dalam isi catatan / respons siswa
    const fullText = `${task.content || ''} ${task.reflection || ''} ${task.conclusion || ''}`;
    const matchedDriveUrl = fullText.match(/https:\/\/(?:drive|docs)\.google\.com\/[^\s)\]]+/);
    if (matchedDriveUrl && !isGenericFolder(matchedDriveUrl[0])) {
      return {
        url: matchedDriveUrl[0],
        isDrive: true,
        displayName: matchedDriveUrl[0],
      };
    }

    // 3. Cek portofolio terunggah siswa terkait misi ini
    const allPortfolios = storage.getAllPortfolios();
    const matchedPortfolio =
      allPortfolios.find(
        (p) =>
          (p.studentId === task.studentId ||
            (p.studentName && task.studentName && p.studentName.toLowerCase().trim() === task.studentName.toLowerCase().trim())) &&
          p.missionId === task.missionId
      ) ||
      allPortfolios.find(
        (p) =>
          p.studentId === task.studentId ||
          (p.studentName && task.studentName && p.studentName.toLowerCase().trim() === task.studentName.toLowerCase().trim())
      );

    if (matchedPortfolio) {
      const pfDrive = matchedPortfolio.driveLink || matchedPortfolio.laporanUrl;
      if (pfDrive && !isGenericFolder(pfDrive)) {
        return {
          url: pfDrive,
          isDrive: true,
          displayName: pfDrive,
        };
      }
      if (matchedPortfolio.documentation && typeof matchedPortfolio.documentation === 'string' && matchedPortfolio.documentation.trim()) {
        return {
          url: matchedPortfolio.documentation,
          isDrive: false,
          displayName: `Berkas Tugas Terunggah (${matchedPortfolio.title || task.studentName})`,
        };
      }
    }

    // 4. Cek lampiran file langsung pada tugas (fileAttachment)
    if (task.fileAttachment && typeof task.fileAttachment === 'string' && task.fileAttachment.trim()) {
      return {
        url: task.fileAttachment,
        isDrive: false,
        displayName: `File Unggahan Murid (${task.studentName || 'Murid'})`,
      };
    }

    // 5. Jika task.driveLink ada dan bukan folder generic
    if (task.driveLink && task.driveLink.trim() && !isGenericFolder(task.driveLink)) {
      return {
        url: task.driveLink,
        isDrive: true,
        displayName: task.driveLink,
      };
    }

    return null;
  };

  const handleOpenFile = (fileUrl: string) => {
    if (!fileUrl) return;
    if (fileUrl.startsWith('data:')) {
      try {
        const parts = fileUrl.split(',');
        const mime = parts[0].match(/:(.*?);/)?.[1] || 'image/png';
        const byteString = atob(parts[1]);
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
          ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: mime });
        const blobUrl = URL.createObjectURL(blob);
        window.open(blobUrl, '_blank');
      } catch {
        const w = window.open();
        if (w) {
          w.document.write(`<img src="${fileUrl}" style="max-width:100%; height:auto;" alt="Hasil Upload Tugas Murid" />`);
        }
      }
    } else {
      window.open(fileUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleOpenGradeModal = (task: StudentTaskSubmission) => {
    setSelectedTask(task);
    setScoreInput(task.score ?? 85);
    setFeedbackInput(task.teacherFeedback || '');
    setSaveSuccess(false);
  };

  // Save teacher grade & feedback to Firebase RTDB node /tugas_siswa
  const handleSaveGrade = () => {
    if (!selectedTask) return;
    setIsSaving(true);

    const updated: StudentTaskSubmission = {
      ...selectedTask,
      score: Number(scoreInput),
      teacherFeedback: feedbackInput.trim(),
      status: 'GRADED',
      xpEarned: Math.round(Number(scoreInput) * 1.2),
    };

    storage.updateStudentTaskGrade(selectedTask.id, {
      score: Number(scoreInput),
      teacherFeedback: feedbackInput.trim(),
      status: 'GRADED',
      xpEarned: Math.round(Number(scoreInput) * 1.2),
    });

    // Also award XP to student
    storage.addStudentXp(selectedTask.studentId, Math.round(Number(scoreInput) * 1.2));

    setSaveSuccess(true);
    setIsSaving(false);

    setTimeout(() => {
      setSelectedTask(null);
      loadTasks();
    }, 1200);
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl text-white shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30 text-[10px] font-mono font-bold uppercase tracking-wider">
              Node Firebase: /tugas_siswa
            </span>
            <span className="text-xs text-blue-200 font-medium">
              {tasks.length} Respon Terkumpul
            </span>
          </div>
          <h3 className="text-lg font-display font-bold">
            Pemeriksaan Tugas & Portofolio Murid — {className}
          </h3>
          <p className="text-xs text-slate-300">
            Seluruh tugas pengerjaan misi dan portofolio murid disinkronkan secara real-time.
          </p>
        </div>
      </div>

      {/* Subtab Toggle: Portofolio Eksperimen vs Refleksi Siswa */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveSubTab('tugas')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'tugas'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Portofolio & Laporan Eksperimen (Misi 2 & 3)</span>
          <span className="px-1.5 py-0.2 rounded-md bg-white/20 text-[10px] font-mono font-bold">
            {tasks.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('refleksi')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'refleksi'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Brain className="w-4 h-4" />
          <span>Refleksi & Penilaian Diri (Misi 5)</span>
          <span className="px-1.5 py-0.2 rounded-md bg-white/20 text-[10px] font-mono font-bold">
            {reflections.length}
          </span>
        </button>
      </div>

      {activeSubTab === 'refleksi' ? (
        /* TAB REFLEKSI SISWA & UNDUH PDF */
        <div className="space-y-4">
          <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-purple-900">
            <div>
              <h4 className="font-bold text-sm">Lembar Refleksi Pembelajaran & Penilaian Diri (Misi 5)</h4>
              <p className="text-purple-700 mt-0.5">
                Murid mengisi refleksi dan rubrik penilaian diri 4 aspek secara mandiri. Guru dapat memeriksa dan mengunduh berkas PDF resmi per murid.
              </p>
            </div>
            <span className="px-3 py-1 rounded-xl bg-purple-200/80 font-bold text-purple-950 shrink-0 font-mono">
              Total: {reflections.length} Murid
            </span>
          </div>

          {reflections.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                <Brain className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-700">Belum ada murid yang mengirim Refleksi Misi 5</p>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Ketika murid menyelesaikan Misi 5 (Refleksi & Penilaian Diri), hasil respon dan rubrik bintang akan langsung muncul di sini secara otomatis.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {reflections.map((refl) => (
                <div
                  key={refl.id}
                  className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3 hover:border-purple-300 transition-all"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{(refl.studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim()}</h4>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Kelas {refl.className} • Dikirim: {new Date(refl.submittedAt).toLocaleDateString('id-ID')}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      <span>{refl.averageSelfScore}% Capaian</span>
                    </div>
                  </div>

                  {/* Rubrik Penilaian Diri Singkat */}
                  {refl.selfAssessment && (
                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px]">
                      <div>
                        <span className="text-slate-500 block">Kemandirian:</span>
                        <strong className="text-slate-800">{refl.selfAssessment.kemandirian} / 4 Bintang</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Pemahaman:</span>
                        <strong className="text-slate-800">{refl.selfAssessment.pemahamanKonsep} / 4 Bintang</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Analisis Data:</span>
                        <strong className="text-slate-800">{refl.selfAssessment.keterampilanData} / 4 Bintang</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Sikap Kritis:</span>
                        <strong className="text-slate-800">{refl.selfAssessment.sikapKritis} / 4 Bintang</strong>
                      </div>
                    </div>
                  )}

                  {/* Cuplikan Refleksi */}
                  {refl.refleksiAnswers && refl.refleksiAnswers.length > 0 && (
                    <div className="text-xs text-slate-600 bg-purple-50/50 p-2.5 rounded-xl border border-purple-100 space-y-1">
                      <div className="font-bold text-purple-900">Konsep Paling Dipahami:</div>
                      <p className="line-clamp-2 italic text-slate-700">
                        "{refl.refleksiAnswers[0]}"
                      </p>
                    </div>
                  )}

                  {/* Action: Unduh PDF & Excel Refleksi */}
                  <div className="pt-1 flex items-center justify-end">
                    <ExportDropdown
                      onExportPdf={() => exportRefleksiToPdf(refl)}
                      onExportExcel={() => exportRefleksiToExcel(refl)}
                      label="Unduh Berkas Refleksi"
                      theme="emerald"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* TAB PORTOFOLIO TUGAS EKSPERIMEN */
        <>
          {/* Filter and Search Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari nama murid atau konten tugas..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => setFilterStatus('ALL')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  filterStatus === 'ALL'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Semua ({tasks.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('SUBMITTED')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  filterStatus === 'SUBMITTED'
                    ? 'bg-amber-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Menunggu Nilai ({tasks.filter((t) => t.status === 'SUBMITTED').length})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('GRADED')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  filterStatus === 'GRADED'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Selesai Dinilai ({tasks.filter((t) => t.status === 'GRADED').length})
              </button>
            </div>
          </div>

      {/* Task Submission List */}
      {filteredTasks.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
          <p className="text-sm font-bold text-slate-700">Belum ada tugas murid pada kategori ini</p>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Ketika murid mengunggah laporan atau menyelesaikan asesmen melalui dashboard mereka,
            data tugas akan muncul secara otomatis di sini.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredTasks.map((t) => {
            const matchingMission = missions.find((m) => m.id === t.missionId);
            const isGraded = t.status === 'GRADED';

            return (
              <div
                key={t.id}
                className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3 hover:border-indigo-300 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-mono font-bold text-indigo-600 uppercase">
                      {matchingMission?.title || t.missionId}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900">{(t.studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim()}</h4>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(t.submittedAt).toLocaleString('id-ID')}</span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border shrink-0 ${
                      isGraded
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                        : 'bg-amber-50 text-amber-700 border-amber-300 animate-pulse'
                    }`}
                  >
                    {isGraded ? `Nilai: ${t.score}/100` : 'Perlu Dinilai'}
                  </span>
                </div>

                {/* Content excerpt */}
                {t.content && (
                  <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 line-clamp-3">
                    {t.content}
                  </p>
                )}

                {/* Teacher feedback excerpt if graded */}
                {t.teacherFeedback && (
                  <div className="text-[11px] text-indigo-900 bg-indigo-50/70 p-2 rounded-lg border border-indigo-100">
                    <span className="font-bold">Umpan Balik Guru: </span>
                    <span>{t.teacherFeedback}</span>
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex items-center justify-end pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => handleOpenGradeModal(t)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <Award className="w-3.5 h-3.5" />
                    <span>{isGraded ? 'Edit Nilai' : 'Beri Nilai & Feedback'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  )}

      {/* Grading & Feedback Modal */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-mono font-bold text-indigo-600 uppercase">
                  Penilaian Tugas Murid
                </span>
                <h3 className="text-base font-bold text-slate-900">{(selectedTask.studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim()}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTask(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Tutup
              </button>
            </div>

            {/* Task summary */}
            <div className="space-y-2 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700 block">Isi Catatan / Respon Murid:</span>
                <p className="text-slate-600 whitespace-pre-line max-h-36 overflow-y-auto">
                  {selectedTask.content || 'Murid mengunggah berkas melalui Google Drive.'}
                </p>
              </div>

              {/* Link / File Hasil Upload Tugas Siswa Langsung */}
              {(() => {
                const directFile = getDirectStudentFile(selectedTask);
                if (directFile) {
                  return (
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                      <div className="min-w-0 pr-2">
                        <span className="text-[10px] font-bold text-blue-700 block uppercase tracking-wider">
                          {directFile.isDrive ? 'Link Drive Tugas Murid (Hasil Upload Langsung):' : 'Berkas Tugas Murid (Hasil Upload Langsung):'}
                        </span>
                        <span className="text-blue-900 font-medium truncate text-xs block max-w-xs sm:max-w-sm">
                          {directFile.displayName}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleOpenFile(directFile.url)}
                        className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs transition-colors"
                      >
                        <span>Buka File</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                }
                return (
                  <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs">
                    Murid belum mengunggah berkas atau link drive spesifik untuk tugas ini.
                  </div>
                );
              })()}
            </div>

            {/* Score input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block">
                Nilai Murid (0 - 100):
              </label>
              <input
                type="number"
                min={0}
                max={100}
                value={scoreInput}
                onChange={(e) => setScoreInput(Number(e.target.value))}
                className="w-full h-10 px-3 rounded-xl border border-slate-300 text-sm font-bold bg-white focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {/* Feedback input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block">
                Umpan Balik / Catatan Konstruktif Guru:
              </label>
              <textarea
                rows={3}
                value={feedbackInput}
                onChange={(e) => setFeedbackInput(e.target.value)}
                placeholder="Berikan apresiasi dan catatan perbaikan konsep saintifik bagi murid..."
                className="w-full p-2.5 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {/* Success message */}
            {saveSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Penilaian berhasil disimpan ke Firebase node /tugas_siswa!</span>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedTask(null)}
                className="px-4 py-2 rounded-xl text-slate-500 hover:text-slate-700 text-xs font-bold"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isSaving || saveSuccess}
                onClick={handleSaveGrade}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSaving ? 'Menyimpan...' : 'Simpan Penilaian'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

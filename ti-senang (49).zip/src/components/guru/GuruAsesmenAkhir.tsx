import React, { useState, useEffect, useMemo } from 'react';
import {
  Award,
  PlusCircle,
  CheckCircle2,
  XCircle,
  Edit2,
  Trash2,
  X,
  FileCheck2,
  Users,
  Search,
  BrainCircuit,
  FolderKanban,
  Zap,
  Filter,
  FileText,
} from 'lucide-react';
import { Student, ClassRoom, Subject, AsesmenAkhirRecord } from '../../types';
import { storage } from '../../services/storage';
import { AlmeEngine } from '../../services/alme/almeEngine';
import { exportAsesmenAkhirToPdf } from '../../utils/pdfExport';
import { exportAsesmenAkhirToExcel } from '../../utils/excelExport';
import { ExportDropdown } from '../common/ExportDropdown';

interface GuruAsesmenAkhirProps {
  selectedClassId: string;
  selectedSubjectId: string;
  classes: ClassRoom[];
  subjects: Subject[];
  students: Student[];
  teacherName: string;
  onRefresh?: () => void;
}

export interface StudentComprehensiveScoreRow {
  student: Student;
  studentId: string;
  studentName: string;
  nisn?: string;
  kelompok: string;
  xp: number;
  level: number;
  misi1Answer: string;
  portofolioScore: number | null;
  portofolioCount: number;
  taskCount: number;
  almeScore: number;
  almeCategory: string;
  misi6Score: number | null;
  isMisi6Completed: boolean;
  record?: AsesmenAkhirRecord;
  finalScore: number;
  kktpStatus: 'Tuntas' | 'Belum Tuntas' | 'Belum Ada';
  predikat: string;
  tpMastery: number;
  catatan?: string;
}

export const GuruAsesmenAkhir: React.FC<GuruAsesmenAkhirProps> = ({
  selectedClassId,
  selectedSubjectId,
  classes = [],
  subjects = [],
  students = [],
  teacherName,
  onRefresh,
}) => {
  const [kktpThreshold, setKktpThreshold] = useState<number>(75);
  const [records, setRecords] = useState<AsesmenAkhirRecord[]>(() =>
    storage.getAsesmenAkhir(selectedClassId, selectedSubjectId),
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'TUNTAS' | 'BELUM_TUNTAS' | 'BELUM_MISI6'>('ALL');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AsesmenAkhirRecord | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string; studentName: string } | null>(null);
  const [misi1Popup, setMisi1Popup] = useState<{ studentName: string; answer: string } | null>(null);

  // Form State
  const [modalStudentId, setModalStudentId] = useState(students?.[0]?.id || 'std-01');
  const [modalScore, setModalScore] = useState<number>(80);
  const [modalTpMastery, setModalTpMastery] = useState<number>(85);
  const [modalCatatan, setModalCatatan] = useState<string>('');

  const currentClass = classes.find((c) => c.id === selectedClassId) || classes?.[0];
  const currentSubject = subjects.find((s) => s.id === selectedSubjectId) || subjects?.[0];

  const reloadData = () => {
    const data = storage.getAsesmenAkhir(selectedClassId, selectedSubjectId);
    setRecords(data);
    if (onRefresh) onRefresh();
  };

  useEffect(() => {
    reloadData();
    const handleSync = () => {
      reloadData();
    };
    window.addEventListener('storage', handleSync);
    window.addEventListener('tisenang_missions_updated', handleSync);
    window.addEventListener('tisenang_storage_updated', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('tisenang_missions_updated', handleSync);
      window.removeEventListener('tisenang_storage_updated', handleSync);
    };
  }, [selectedClassId, selectedSubjectId]);

  // Kalkulasi predikat & kktp
  const calculatePredikat = (sc: number): AsesmenAkhirRecord['predikat'] => {
    if (sc >= 88) return 'A (Sangat Baik)';
    if (sc >= 75) return 'B (Baik)';
    if (sc >= 65) return 'C (Cukup)';
    return 'D (Perlu Bimbingan)';
  };

  // Pastikan daftar murid kelas tersedia
  const classStudents = useMemo(() => {
    if (students && students.length > 0) return students;
    if (selectedClassId) return storage.getStudentsByClass(selectedClassId);
    return [];
  }, [students, selectedClassId]);

  // Rekapitulasi seluruh hasil capaian murid: XP, Nilai Portofolio, Nilai Otomatis ALME, Nilai Misi 6
  const studentRows = useMemo<StudentComprehensiveScoreRow[]>(() => {
    const awalList = storage.getAsesmenAwal(selectedClassId);

    return classStudents.map((st) => {
      const sId = st.id;
      const sName = (st.name || st.user?.fullName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
      const sNisn = st.nisn;
      const kelompok = st.kelompok || 'Kelompok 1';

      // 1. Total XP & Level Murid
      const profile = storage.getStudentProfile(sId);
      const xp = profile?.xp ?? (st.user?.xp || 450);
      const level = profile?.level ?? Math.max(1, Math.floor(xp / 300) + 1);

      // Jawaban Misi 1 Siswa (Informasi penting yang ditemukan dari bahan ajar/video)
      const savedMisi1 = storage.getMisi1Notes(sId) || storage.getMisi1Notes(st.userId);
      const sampleMisi1Notes: Record<string, string> = {
        'std-01': 'Berdasarkan video pembelajaran dan modul materi: Kalor jenis air bernilai 4200 J/(kg·K). Pada sistem kalorimeter tertutup, kalor yang dilepas oleh fluida panas bernilai sama dengan kalor yang diserap oleh fluida dingin sesuai Azas Black (Q_lepas = Q_terima).',
        'std-02': 'Catatan penting dari bahan ajar: Diagram pencar regresi linear menunjukkan korelasi kuat antara waktu pemanasan dengan kenaikan suhu. Nilai koefisien korelasi r mendekati 1 dan R² membuktikan variasi kenaikan suhu dapat diprediksi secara akurat.',
        'std-03': 'Rangkuman materi dari modul: Terdapat 3 mekanisme perpindahan kalor utama yaitu konduksi pada padatan, konveksi pada fluida cair/gas, dan radiasi termal tanpa perantara medium.',
        'std-04': 'Catatan video praktikum: Penggunaan sensor digital dan data logger mempermudah pencatatan temperatur secara real-time dan meminimalkan galat paralaks saat pengamatan eksperimen.',
        'std-05': 'Informasi dari bahan ajar: Hukum Stefan-Boltzmann menyatakan bahwa energi radiasi termal benda hitam sebanding dengan pangkat empat temperatur mutlak benda (E = σ · T⁴).',
      };
      const misi1Answer =
        savedMisi1 ||
        sampleMisi1Notes[sId] ||
        'Informasi penting yang ditemukan dari bahan ajar/video: Murid telah mempelajari prinsip dasar materi pembelajaran, merangkum poin-poin utama dari bahan ajar digital, serta mencatat fenomena fisis dan pemodelan data dari video penjelasan guru.';

      // 2. Nilai Portofolio & Tugas
      const tasks = storage.getStudentTasks(sId);
      const portfolios = storage.getStudentPortfolios(sId);
      const gradedTasks = tasks.filter((t) => typeof t.score === 'number' && !isNaN(t.score!));

      let portofolioScore: number | null = null;
      if (gradedTasks.length > 0) {
        portofolioScore = Math.round(
          gradedTasks.reduce((acc, t) => acc + (t.score || 0), 0) / gradedTasks.length
        );
      } else if (portfolios.length > 0) {
        portofolioScore = Math.min(95, 80 + portfolios.length * 4);
      } else if (tasks.length > 0) {
        portofolioScore = 80;
      }

      // 3. Nilai Otomatis ALME
      const almeRec = storage.getAlmeRecommendation(sId);
      const awal = awalList.find((a) => a.studentId === sId || a.studentId === st.userId);

      let almeScore = 80;
      let almeCategory = 'Latihan Soal';

      if (almeRec) {
        const parsed =
          typeof almeRec.current === 'number'
            ? almeRec.current
            : parseInt(String(almeRec.current).replace(/[^0-9]/g, ''), 10);
        almeScore = !isNaN(parsed) && parsed > 0 ? parsed : (awal?.diagnosticScore ?? 80);
        almeCategory =
          almeRec.category || almeRec.interventionCategory || almeRec.type || 'Latihan Soal';
      } else if (awal) {
        almeScore = awal.diagnosticScore;
        almeCategory = awal.interventionCategory || awal.readinessLevel || 'Siap Mandiri';
      } else {
        const sim = AlmeEngine.analyze({ assessmentResultScore: 80 });
        almeScore = 80;
        almeCategory = sim.category || 'Latihan Soal';
      }

      // 4. Nilai Asesmen Akhir dari Misi 6
      const existingRecord = records.find(
        (r) =>
          r.studentId === sId ||
          r.studentId === st.userId ||
          r.studentName?.toLowerCase() === sName.toLowerCase()
      );
      const progresses = storage.getAllStudentProgress(sId);
      const m6Prog = progresses.find(
        (p) => p.missionId.includes('6') || p.missionId === 'm6' || p.missionId.includes('mis-6')
      );

      let misi6Score: number | null = null;
      let isMisi6Completed = false;

      if (existingRecord) {
        misi6Score = existingRecord.score;
        isMisi6Completed = true;
      } else if (m6Prog && m6Prog.status === 'COMPLETED') {
        misi6Score = typeof m6Prog.score === 'number' ? m6Prog.score : 85;
        isMisi6Completed = true;
      }

      const finalScore = misi6Score ?? (existingRecord ? existingRecord.score : 0);
      const isTuntas = finalScore >= kktpThreshold;
      const kktpStatus: 'Tuntas' | 'Belum Tuntas' | 'Belum Ada' =
        misi6Score !== null ? (isTuntas ? 'Tuntas' : 'Belum Tuntas') : 'Belum Ada';

      const predikat =
        misi6Score !== null
          ? calculatePredikat(finalScore)
          : existingRecord?.predikat || '-';

      const tpMastery =
        existingRecord?.tpMasteryPercentage ?? (misi6Score !== null ? finalScore : 0);

      return {
        student: st,
        studentId: sId,
        studentName: sName,
        nisn: sNisn,
        kelompok,
        xp,
        level,
        misi1Answer,
        portofolioScore,
        portofolioCount: portfolios.length,
        taskCount: tasks.length,
        almeScore,
        almeCategory,
        misi6Score,
        isMisi6Completed,
        record: existingRecord,
        finalScore,
        kktpStatus,
        predikat,
        tpMastery,
        catatan: existingRecord?.catatan,
      };
    });
  }, [classStudents, records, selectedClassId, kktpThreshold]);

  // Filtered rows based on search and status
  const filteredRows = useMemo(() => {
    return studentRows.filter((r) => {
      const matchSearch =
        r.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (r.nisn && r.nisn.includes(searchQuery)) ||
        r.kelompok.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchSearch) return false;

      if (filterStatus === 'TUNTAS') return r.kktpStatus === 'Tuntas';
      if (filterStatus === 'BELUM_TUNTAS') return r.kktpStatus === 'Belum Tuntas';
      if (filterStatus === 'BELUM_MISI6') return r.kktpStatus === 'Belum Ada';

      return true;
    });
  }, [studentRows, searchQuery, filterStatus]);

  // Metrik Ringkasan Komprehensif
  const totalSiswa = studentRows.length;
  const completedM6Rows = studentRows.filter((r) => r.misi6Score !== null);
  const avgMisi6 = completedM6Rows.length
    ? (completedM6Rows.reduce((a, b) => a + (b.misi6Score || 0), 0) / completedM6Rows.length).toFixed(1)
    : '0';

  const rowsWithPorto = studentRows.filter((r) => r.portofolioScore !== null);
  const avgPorto = rowsWithPorto.length
    ? (rowsWithPorto.reduce((a, b) => a + (b.portofolioScore || 0), 0) / rowsWithPorto.length).toFixed(1)
    : '0';

  const avgAlme = totalSiswa
    ? (studentRows.reduce((a, b) => a + b.almeScore, 0) / totalSiswa).toFixed(1)
    : '0';

  const avgXp = totalSiswa
    ? Math.round(studentRows.reduce((a, b) => a + b.xp, 0) / totalSiswa)
    : 0;

  const tuntasCount = completedM6Rows.filter((r) => r.kktpStatus === 'Tuntas').length;
  const tuntasPercentage = completedM6Rows.length
    ? Math.round((tuntasCount / completedM6Rows.length) * 100)
    : 0;

  // Handlers for Input / Edit
  const handleOpenAdd = (targetStudentId?: string) => {
    setEditingRecord(null);
    const chosenStudentId = targetStudentId || studentRows[0]?.studentId || 'std-01';
    setModalStudentId(chosenStudentId);
    setModalScore(80);
    setModalTpMastery(85);
    setModalCatatan('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rec: AsesmenAkhirRecord) => {
    setEditingRecord(rec);
    setModalStudentId(rec.studentId);
    setModalScore(rec.score);
    setModalTpMastery(rec.tpMasteryPercentage);
    setModalCatatan(rec.catatan || '');
    setIsModalOpen(true);
  };

  const handleDelete = (id: string, studentName?: string) => {
    setDeleteConfirm({ id, studentName: studentName || 'Murid' });
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirm) return;
    storage.deleteAsesmenAkhir(deleteConfirm.id);
    setDeleteConfirm(null);
    reloadData();
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const st = studentRows.find((s) => s.studentId === modalStudentId);
    const studentName = st?.studentName || 'Murid TI SENANG';
    const numScore = Number(modalScore);

    const record: AsesmenAkhirRecord = {
      id: editingRecord ? editingRecord.id : `ask-${Date.now()}`,
      studentId: modalStudentId,
      studentName,
      nisn: st?.nisn,
      classId: selectedClassId,
      subjectId: selectedSubjectId,
      score: numScore,
      kktpStatus: numScore >= kktpThreshold ? 'Tuntas' : 'Belum Tuntas',
      predikat: calculatePredikat(numScore),
      tpMasteryPercentage: Number(modalTpMastery),
      catatan: modalCatatan,
      updatedAt: new Date().toISOString(),
    };

    storage.saveAsesmenAkhir(record);
    setIsModalOpen(false);
    reloadData();
  };

  // Export handlers including XP, Portofolio, ALME, and Misi 6
  const handleExportPdf = () => {
    const exportRecords = studentRows.map((r) => ({
      studentName: r.studentName,
      nisn: r.nisn,
      xp: r.xp,
      portofolioScore: r.portofolioScore !== null ? r.portofolioScore : '-',
      almeScore: r.almeScore,
      score: r.misi6Score !== null ? r.misi6Score : 0,
      kktpStatus: (r.kktpStatus === 'Belum Ada' ? 'Belum Tuntas' : r.kktpStatus) as 'Tuntas' | 'Belum Tuntas',
      predikat: r.predikat !== '-' ? r.predikat : 'D',
      tpMasteryPercentage: r.tpMastery,
      catatan: r.catatan || `ALME: ${r.almeCategory}`,
    }));

    exportAsesmenAkhirToPdf({
      className: currentClass?.className || 'XII-1',
      subjectName: currentSubject?.name || 'MIPA',
      teacherName: teacherName || 'Guru Pengampu',
      kktpTarget: kktpThreshold,
      records: exportRecords,
    });
  };

  const handleExportExcel = () => {
    const exportRecords = studentRows.map((r) => ({
      studentName: r.studentName,
      nisn: r.nisn,
      xp: r.xp,
      portofolioScore: r.portofolioScore !== null ? r.portofolioScore : '-',
      almeScore: r.almeScore,
      score: r.misi6Score !== null ? r.misi6Score : 0,
      kktpStatus: (r.kktpStatus === 'Belum Ada' ? 'Belum Tuntas' : r.kktpStatus) as 'Tuntas' | 'Belum Tuntas',
      predikat: r.predikat !== '-' ? r.predikat : 'D',
      tpMasteryPercentage: r.tpMastery,
      catatan: r.catatan || `ALME: ${r.almeCategory}`,
    }));

    exportAsesmenAkhirToExcel({
      className: currentClass?.className || 'XII-1',
      subjectName: currentSubject?.name || 'MIPA',
      teacherName: teacherName || 'Guru Pengampu',
      kktpTarget: kktpThreshold,
      records: exportRecords,
    });
  };

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-[11px] font-bold text-amber-800 mb-1">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            Rekapitulasi Capaian Belajar & Ketuntasan Murid (KKTP)
          </div>
          <h3 className="font-display font-bold text-slate-800 text-lg flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-indigo-600" />
            Cek Nilai Murid
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelas {currentClass?.className} • {currentSubject?.name} • Menampilkan seluruh hasil yang diperoleh murid: XP, nilai portofolio, nilai otomatis ALME, dan nilai asesmen akhir Misi 6.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start md:self-auto">
          {/* KKTP Setter */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1 rounded-xl border border-slate-200 text-xs">
            <span className="font-bold text-slate-600 text-[11px]">KKTP:</span>
            <input
              type="number"
              min={50}
              max={95}
              value={kktpThreshold}
              onChange={(e) => setKktpThreshold(Number(e.target.value))}
              className="w-12 h-7 px-1.5 rounded-lg border border-slate-300 font-mono font-bold text-xs bg-white text-center focus:border-indigo-500 outline-hidden"
            />
          </div>

          {/* Download Consolidated Dropdown */}
          <ExportDropdown
            onExportPdf={handleExportPdf}
            onExportExcel={handleExportExcel}
            label="Unduh Rekap"
            theme="light"
          />

          {/* Input Asesmen Akhir Button */}
          <button
            type="button"
            id="btn-input-asesmen-akhir"
            onClick={() => handleOpenAdd()}
            className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-xs cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Input Nilai Asesmen</span>
          </button>
        </div>
      </div>

      {/* Aggregate Metric Cards (5 Hasil Utama) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
        <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-100 text-center">
          <div className="text-[11px] font-semibold text-amber-800">Rata-rata Misi 6</div>
          <div className="text-xl sm:text-2xl font-display font-extrabold text-amber-900 mt-0.5">
            {avgMisi6}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Asesmen Akhir</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100 text-center">
          <div className="text-[11px] font-semibold text-blue-700">Rata-rata Portofolio</div>
          <div className="text-xl sm:text-2xl font-display font-extrabold text-blue-900 mt-0.5">
            {avgPorto}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Tugas & Praktikum</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-100 text-center">
          <div className="text-[11px] font-semibold text-indigo-700">Rata-rata ALME</div>
          <div className="text-xl sm:text-2xl font-display font-extrabold text-indigo-900 mt-0.5">
            {avgAlme}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Penilaian Otomatis</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-purple-50/70 border border-purple-100 text-center">
          <div className="text-[11px] font-semibold text-purple-700">Rata-rata XP</div>
          <div className="text-xl sm:text-2xl font-display font-extrabold text-purple-900 mt-0.5">
            {avgXp.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Akumulasi Belajar</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-100 text-center col-span-2 sm:col-span-1">
          <div className="text-[11px] font-semibold text-emerald-700">Ketuntasan KKTP</div>
          <div className="text-xl sm:text-2xl font-display font-extrabold text-emerald-900 mt-0.5">
            {tuntasPercentage}%
          </div>
          <div className="text-[10px] text-emerald-700 mt-0.5 font-bold">
            {tuntasCount} / {completedM6Rows.length} Murid
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari murid, NISN, kelompok..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-hidden focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-[11px] font-bold text-slate-500">Filter:</span>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs bg-white font-medium text-slate-700 focus:outline-hidden focus:border-indigo-500"
          >
            <option value="ALL">Semua Murid ({studentRows.length})</option>
            <option value="TUNTAS">Tuntas KKTP</option>
            <option value="BELUM_TUNTAS">Belum Tuntas KKTP</option>
            <option value="BELUM_MISI6">Belum Mengerjakan Misi 6</option>
          </select>
        </div>
      </div>

      {/* Table Records: Menampilkan Seluruh Hasil Murid */}
      {filteredRows.length === 0 ? (
        <div className="py-12 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-2xl space-y-2">
          <p>Tidak ada data murid yang cocok dengan pencarian / filter ini.</p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setFilterStatus('ALL');
            }}
            className="text-indigo-600 hover:text-indigo-700 font-bold underline cursor-pointer"
          >
            Reset Filter
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-200">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 text-center w-10">No</th>
                <th className="py-3 px-4">Nama</th>
                <th className="py-3 px-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Zap className="w-3.5 h-3.5 text-purple-600" />
                    <span>XP Murid</span>
                  </div>
                </th>
                <th className="py-3 px-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Jawaban Misi 1 Murid</span>
                  </div>
                </th>
                <th className="py-3 px-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <FolderKanban className="w-3.5 h-3.5 text-blue-600" />
                    <span>Nilai Portofolio</span>
                  </div>
                </th>
                <th className="py-3 px-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <BrainCircuit className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Nilai ALME</span>
                  </div>
                </th>
                <th className="py-3 px-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Award className="w-3.5 h-3.5 text-amber-600" />
                    <span>Asesmen Akhir</span>
                  </div>
                </th>
                <th className="py-3 px-3 text-center">Predikat</th>
                <th className="py-3 px-3 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredRows.map((row, idx) => {
                const hasMisi6 = row.misi6Score !== null;

                return (
                  <tr key={row.studentId} className="hover:bg-slate-50/80 transition-colors">
                    {/* 1. Nomor Urut */}
                    <td className="py-3 px-3 text-center font-mono text-slate-400 font-medium">
                      {idx + 1}
                    </td>

                    {/* 2. Nama */}
                    <td className="py-3 px-4 font-bold text-slate-800">
                      <div className="flex flex-col">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-900">{row.studentName}</span>
                          <span className="px-1.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold">
                            {row.kelompok}
                          </span>
                        </div>
                        {row.nisn && (
                          <span className="text-[10px] font-mono font-normal text-slate-400">
                            NISN: {row.nisn}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* 3. XP Murid */}
                    <td className="py-3 px-3 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-50 border border-purple-200 text-purple-700 font-mono font-extrabold text-xs">
                          <Zap className="w-3 h-3 text-purple-600" />
                          {row.xp.toLocaleString()} XP
                        </span>
                        <span className="text-[9px] text-slate-400 font-medium mt-0.5">
                          Level {row.level}
                        </span>
                      </div>
                    </td>

                    {/* 4. Jawaban Misi 1 Siswa (Hanya tulisan Buka, buka popup saat diklik) */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() =>
                          setMisi1Popup({
                            studentName: row.studentName,
                            answer: row.misi1Answer,
                          })
                        }
                        className="px-3 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 transition-colors cursor-pointer active:scale-95"
                      >
                        Buka
                      </button>
                    </td>

                    {/* 5. Nilai Portofolio */}
                    <td className="py-3 px-3 text-center">
                      {row.portofolioScore !== null ? (
                        <div className="inline-flex flex-col items-center">
                          <span className="font-mono font-extrabold text-sm text-blue-700">
                            {row.portofolioScore}
                          </span>
                          <span className="text-[9px] text-slate-500 font-medium">
                            {row.portofolioCount} karya • {row.taskCount} tugas
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400 font-mono italic text-[11px]">-</span>
                      )}
                    </td>

                    {/* 6. Nilai ALME */}
                    <td className="py-3 px-3 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className="font-mono font-extrabold text-sm text-indigo-700">
                          {row.almeScore}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-semibold text-[9px] mt-0.5">
                          {row.almeCategory}
                        </span>
                      </div>
                    </td>

                    {/* 7. Asesmen Akhir */}
                    <td className="py-3 px-3 text-center">
                      {hasMisi6 ? (
                        <div className="inline-flex flex-col items-center">
                          <span className="font-mono font-extrabold text-sm text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-lg border border-amber-200">
                            {row.misi6Score}
                          </span>
                          <span className="text-[9px] text-slate-400 mt-0.5">
                            TP: {row.tpMastery}%
                          </span>
                        </div>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 text-[10px] font-medium italic">
                          Belum selesai
                        </span>
                      )}
                    </td>

                    {/* 8. Predikat */}
                    <td className="py-3 px-3 text-center font-bold text-slate-700">
                      {hasMisi6 ? row.predikat : '-'}
                    </td>

                    {/* 9. Aksi Input / Edit */}
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {row.record ? (
                          <>
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(row.record!)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                              title="Edit Nilai Asesmen Akhir"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDelete(row.record!.id, row.studentName)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Hapus Nilai"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenAdd(row.studentId)}
                            className="px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[10px] transition-colors"
                            title="Input Nilai Asesmen Akhir"
                          >
                            + Input
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* MODAL POPUP JAWABAN MISI 1 SISWA */}
      {misi1Popup && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-slate-800 text-sm">
                    Jawaban Misi 1 : Informasi penting yang ditemukan dari bahan ajar/video
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Murid: <strong className="text-slate-800">{misi1Popup.studentName}</strong>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setMisi1Popup(null)}
                className="w-8 h-8 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3">
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                  Catatan Materi Murid
                </span>
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-800 leading-relaxed font-sans whitespace-pre-wrap">
                  {misi1Popup.answer}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50/70 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setMisi1Popup(null)}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL INPUT / EDIT ASESMEN AKHIR */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600">
                  <Award className="w-4 h-4" />
                </div>
                <h3 className="font-display font-bold text-slate-800 text-base">
                  {editingRecord ? 'Edit Nilai Asesmen Akhir' : 'Input Nilai Asesmen Akhir (Sumatif)'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Pilih Murid *
                </label>
                <select
                  value={modalStudentId}
                  disabled={!!editingRecord}
                  onChange={(e) => setModalStudentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 focus:border-indigo-500 outline-hidden font-medium disabled:bg-slate-100"
                >
                  {studentRows.map((st) => (
                    <option key={st.studentId} value={st.studentId}>
                      {st.studentName} ({st.kelompok})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nilai Asesmen Akhir Misi 6 (0 - 100) *
                </label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={modalScore}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setModalScore(val);
                    setModalTpMastery(val);
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-mono font-bold bg-white text-slate-900 focus:border-indigo-500 outline-hidden"
                  required
                />
                <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
                  <span>Predikat: <strong className="text-slate-700">{calculatePredikat(modalScore)}</strong></span>
                  <span className={modalScore >= kktpThreshold ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                    {modalScore >= kktpThreshold ? '✓ Memenuhi KKTP' : '✗ Belum Memenuhi KKTP'}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Persentase Penguasaan TP (%) *
                </label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={modalTpMastery}
                  onChange={(e) => setModalTpMastery(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-mono font-bold bg-white text-slate-900 focus:border-indigo-500 outline-hidden"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Catatan Perkembangan Guru (Opsional)
                </label>
                <textarea
                  rows={3}
                  value={modalCatatan}
                  onChange={(e) => setModalCatatan(e.target.value)}
                  placeholder="Contoh: Pemahaman konsep kalorimeter dan hukum termodinamika sangat baik..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 focus:border-indigo-500 outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
                >
                  <span>Simpan Nilai</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Konfirmasi Hapus Asesmen Akhir */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Hapus Asesmen Akhir</h4>
                <p className="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              Apakah Anda yakin ingin menghapus hasil asesmen akhir murid{' '}
              <strong className="text-slate-800">"{deleteConfirm.studentName}"</strong>?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-delete-ask"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
              >
                <Trash2 className="w-4 h-4" />
                <span>Hapus Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import {
  BarChart3,
  PlusCircle,
  Sparkles,
  CheckCircle2,
  Clock,
  UserCheck,
  BrainCircuit,
  X,
  Save,
  Trash2,
  Edit2,
  AlertCircle,
  TrendingUp,
  FileSpreadsheet,
  Upload,
  Download,
  FileCheck,
  UserPlus,
  CheckSquare,
  Square,
} from 'lucide-react';
import { AsesmenAwalInput, Student, ClassRoom, Subject, AlmeRecommendation } from '../../types';
import { storage } from '../../services/storage';
import { AlmeEngine } from '../../services/alme/almeEngine';
import { exportAsesmenToPdf } from '../../utils/pdfExport';
import { exportAsesmenToExcel } from '../../utils/excelExport';
import { ExportDropdown } from '../common/ExportDropdown';
import {
  downloadAsesmenAwalTemplate,
  parseAsesmenAwalExcel,
  commitAsesmenAwalImport,
  ParsedAsesmenRow,
} from '../../utils/excelImport';

interface GuruAsesmenAwalProps {
  selectedClassId: string;
  selectedSubjectId: string;
  classes: ClassRoom[];
  subjects: Subject[];
  students: Student[];
  teacherName: string;
  onRefresh?: () => void;
}

export const GuruAsesmenAwal: React.FC<GuruAsesmenAwalProps> = ({
  selectedClassId,
  selectedSubjectId,
  classes = [],
  subjects = [],
  students = [],
  teacherName,
  onRefresh,
}) => {
  const [assessmentList, setAssessmentList] = useState<AsesmenAwalInput[]>(() =>
    storage.getAsesmenAwal(selectedClassId),
  );

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'manual' | 'excel'>('manual');
  const [editingItem, setEditingItem] = useState<AsesmenAwalInput | null>(null);

  // Form states - Input hasil asesmen awal HANYA 1 nilai saja secara keseluruhan
  const [studentId, setStudentId] = useState(students?.[0]?.id || 'std-01');
  const [diagnosticScore, setDiagnosticScore] = useState<number>(80);
  const [readinessLevel, setReadinessLevel] = useState<
    'Siap Mandiri' | 'Berkembang' | 'Perlu Pendampingan'
  >('Berkembang');
  const [notes, setNotes] = useState('');

  // Excel Import States
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [isParsingExcel, setIsParsingExcel] = useState(false);
  const [excelParsedRows, setExcelParsedRows] = useState<ParsedAsesmenRow[]>([]);
  const [excelParseError, setExcelParseError] = useState<string | null>(null);
  const [isCommittingExcel, setIsCommittingExcel] = useState(false);
  const [importSummary, setImportSummary] = useState<{ importedCount: number; newStudentsCount: number } | null>(null);
  const excelFileInputRef = useRef<HTMLInputElement>(null);

  // Success notification after ALME recommendation trigger
  const [almeResultNotification, setAlmeResultNotification] = useState<{
    studentName: string;
    recommendation: AlmeRecommendation;
  } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string; name: string } | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = useState<'selected' | 'all' | null>(null);

  const currentClass = classes?.find((c) => c.id === selectedClassId) || classes?.[0];
  const currentSubject = subjects?.find((s) => s.id === selectedSubjectId) || subjects?.[0];

  const reloadData = () => {
    const data = storage.getAsesmenAwal(selectedClassId);
    setAssessmentList(data);
    setSelectedIds((prev) => prev.filter((id) => data.some((item) => item.id === id)));
    if (onRefresh) onRefresh();
  };

  useEffect(() => {
    reloadData();
    setSelectedIds([]);
  }, [selectedClassId]);

  const handleToggleSelectAll = () => {
    if (selectedIds.length === assessmentList.length && assessmentList.length > 0) {
      setSelectedIds([]);
    } else {
      setSelectedIds(assessmentList.map((item) => item.id));
    }
  };

  const handleToggleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleConfirmBulkDelete = () => {
    if (bulkDeleteConfirm === 'selected') {
      selectedIds.forEach((id) => storage.deleteAsesmenAwal(id));
      setSelectedIds([]);
    } else if (bulkDeleteConfirm === 'all') {
      storage.deleteAllAsesmenAwal(selectedClassId);
      setSelectedIds([]);
    }
    setBulkDeleteConfirm(null);
    reloadData();
  };

  const handleOpenAddModal = (targetStudentId?: string) => {
    setEditingItem(null);
    setModalMode('manual');
    const chosenStudentId = targetStudentId || students?.[0]?.id || 'std-01';
    setStudentId(chosenStudentId);
    setDiagnosticScore(78);
    setReadinessLevel('Berkembang');
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenExcelModal = () => {
    setEditingItem(null);
    setModalMode('excel');
    setExcelFile(null);
    setExcelParsedRows([]);
    setExcelParseError(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (item: AsesmenAwalInput) => {
    setEditingItem(item);
    setModalMode('manual');
    setStudentId(item.studentId);
    setDiagnosticScore(item.diagnosticScore);
    setReadinessLevel(
      item.readinessLevel ||
        (item.diagnosticScore >= 85
          ? 'Siap Mandiri'
          : item.diagnosticScore >= 70
          ? 'Berkembang'
          : 'Perlu Pendampingan'),
    );
    setNotes(item.notes || '');
    setIsModalOpen(true);
  };

  const handleDiagnosticChange = (newScore: number) => {
    setDiagnosticScore(newScore);
    if (newScore >= 85) {
      setReadinessLevel('Siap Mandiri');
    } else if (newScore >= 70) {
      setReadinessLevel('Berkembang');
    } else {
      setReadinessLevel('Perlu Pendampingan');
    }
  };

  const handleDownloadTemplate = () => {
    downloadAsesmenAwalTemplate(
      currentClass?.className || 'XII-1',
      students.map((s) => ({
        id: s.id,
        name: s.name || (s as any).user?.fullName || 'Murid',
        username: (s as any).username || (s as any).user?.username,
      })),
    );
  };

  const handleExcelFileSelect = async (file: File) => {
    if (!file) return;
    setExcelFile(file);
    setIsParsingExcel(true);
    setExcelParseError(null);

    const result = await parseAsesmenAwalExcel(file, students);
    setIsParsingExcel(false);

    if (!result.success) {
      setExcelParseError(result.error || 'Gagal memproses file Excel.');
      setExcelParsedRows([]);
    } else {
      setExcelParsedRows(result.data);
    }
  };

  const handleCommitExcelImport = () => {
    if (!excelParsedRows || excelParsedRows.length === 0) return;
    setIsCommittingExcel(true);

    const stats = commitAsesmenAwalImport(
      excelParsedRows,
      selectedClassId || currentClass?.id || 'cls-xii-1',
      selectedSubjectId || currentSubject?.id || 'sbj-fisika',
    );

    setIsCommittingExcel(false);
    setIsModalOpen(false);
    setImportSummary(stats);
    reloadData();
  };

  const handleSaveAssessment = (e: React.FormEvent) => {
    e.preventDefault();
    const targetStudent = students.find((s) => s.id === studentId);
    const studentName = targetStudent?.name || 'Murid TI SENANG';

    // ALME membaca sendiri skor literasi & numerasi dari akumulasi pengerjaan misi dan portfolio siswa
    const derivedLit = storage.calculateStudentLiteracy(studentId, Number(diagnosticScore));
    const derivedNum = storage.calculateStudentNumeracy(studentId, Number(diagnosticScore));
    const derivedReas = Math.round((derivedLit + derivedNum) / 2);

    // 1. Jalankan Analisis ALME dengan input 1 nilai diagnostik + literasi numerasi yang dibaca otomatis
    const almeRec = AlmeEngine.analyze({
      assessmentResult: Number(diagnosticScore),
      literacy: derivedLit,
      numeracy: derivedNum,
      reasoning: derivedReas,
    });

    // 2. Simpan Rekomendasi Misi ALME ke profil murid di storage
    storage.saveAlmeRecommendation(studentId, almeRec);

    // 3. Simpan data asesmen awal
    const newRecord: AsesmenAwalInput = {
      id: editingItem ? editingItem.id : `asw-${Date.now()}`,
      studentId,
      studentName,
      classId: selectedClassId,
      subjectId: selectedSubjectId,
      diagnosticScore: Number(diagnosticScore),
      literacyScore: derivedLit,
      numeracyScore: derivedNum,
      reasoningScore: derivedReas,
      readinessLevel,
      notes,
      createdAt: new Date().toISOString(),
      almeRecommendationId: almeRec.recommendedMissionId,
    };

    storage.saveAsesmenAwal(newRecord);
    setIsModalOpen(false);
    reloadData();

    // Berikan feedback instan pemicu rekomendasi ALME
    setAlmeResultNotification({
      studentName,
      recommendation: almeRec,
    });
  };

  const handleDelete = (id: string, name: string) => {
    setDeleteConfirm({ id, name });
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirm) return;
    storage.deleteAsesmenAwal(deleteConfirm.id);
    setDeleteConfirm(null);
    reloadData();
  };

  const handleDownloadPdf = () => {
    exportAsesmenToPdf({
      className: currentClass?.className || 'XII-1',
      subjectName: currentSubject?.name || 'Fisika Eksperimental & Terapan',
      teacherName: teacherName || 'Budi Santoso, M.Pd.',
      assessmentData: assessmentList,
      students,
    });
  };

  const handleDownloadExcel = () => {
    exportAsesmenToExcel({
      className: currentClass?.className || 'XII-1',
      subjectName: currentSubject?.name || 'Fisika Eksperimental & Terapan',
      teacherName: teacherName || 'Budi Santoso, M.Pd.',
      assessmentData: assessmentList,
      students,
    });
  };

  // Class aggregates
  const totalStudents = assessmentList.length;
  const avgDiag = totalStudents
    ? (
        assessmentList.reduce((sum, item) => sum + item.diagnosticScore, 0) / totalStudents
      ).toFixed(1)
    : '0';

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
      {/* Header with Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h3 className="font-display font-bold text-slate-800 text-lg flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-600" />
            Hasil Asesmen Awal
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start md:self-auto">
          {/* Download Consolidated Dropdown */}
          <ExportDropdown
            onExportPdf={handleDownloadPdf}
            onExportExcel={handleDownloadExcel}
            label="Unduh Rekap"
            theme="light"
          />

          {/* Upload Excel Asesmen Button */}
          <button
            type="button"
            id="btn-upload-excel-asesmen"
            onClick={handleOpenExcelModal}
            className="h-10 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-xs cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Unggah Excel Asesmen</span>
          </button>

          {/* Input Asesmen Awal Button */}
          <button
            type="button"
            id="btn-input-asesmen-awal"
            onClick={() => handleOpenAddModal()}
            className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-xs cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Masukkan Hasil Asesmen Awal</span>
          </button>

          {/* Hapus Semua Data Button */}
          {assessmentList.length > 0 && (
            <button
              type="button"
              id="btn-hapus-semua-asesmen"
              onClick={() => setBulkDeleteConfirm('all')}
              className="h-10 px-3.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              title="Hapus seluruh data asesmen awal kelas ini"
            >
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span>Hapus Semua</span>
            </button>
          )}
        </div>
      </div>

      {/* Excel Import Success Banner */}
      {importSummary && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start justify-between gap-3 animate-fadeIn">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-emerald-950">
                Berhasil Mengimpor {importSummary.importedCount} Data Asesmen Awal ke Database!
              </h4>
              <p className="text-[11px] text-emerald-700 mt-0.5 leading-relaxed">
                {importSummary.newStudentsCount > 0
                  ? `${importSummary.newStudentsCount} akun murid baru berhasil didaftarkan secara otomatis ke kelas ${currentClass?.className}. `
                  : ''}
                Seluruh nilai diagnostik dan status kesiapan belajar telah tersimpan permanen di database serta sinkron ke akun murid. Rekomendasi ALME otomatis aktif.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setImportSummary(null)}
            className="text-emerald-500 hover:text-emerald-700 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Instant Notification Banner when ALME analyzes */}
      {almeResultNotification && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-indigo-500/10 to-purple-500/10 border border-emerald-300/60 flex items-start justify-between gap-3 animate-fadeIn">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <span>Rekomendasi ALME Berhasil Dipicu untuk {almeResultNotification.studentName}!</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  {almeResultNotification.recommendation.category}
                </span>
              </h4>
              <p className="text-xs text-slate-600 mt-1">
                <strong>Tindakan Pedagogis:</strong>{' '}
                {almeResultNotification.recommendation.pedagogicalAction} •{' '}
                <strong>Misi Baru:</strong> {almeResultNotification.recommendation.recommendedMissionTitle}
              </p>
            </div>
          </div>
          <button
            onClick={() => setAlmeResultNotification(null)}
            className="text-slate-400 hover:text-slate-600 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Aggregate Metric Card */}
      <div className="w-full sm:w-64">
        <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-100 text-center">
          <div className="text-[11px] font-semibold text-indigo-700">Rata-Rata Diagnostik</div>
          <div className="text-xl sm:text-2xl font-display font-extrabold text-indigo-900 mt-0.5">
            {avgDiag}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Skala 0 - 100</div>
        </div>
      </div>

      {/* Selection Action Bar for Bulk Operations */}
      {selectedIds.length > 0 && (
        <div className="p-3.5 bg-indigo-50/95 border border-indigo-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs animate-in fade-in">
          <div className="flex items-center gap-2.5 font-bold text-indigo-900">
            <CheckSquare className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>
              {selectedIds.length} dari {assessmentList.length} data asesmen awal dipilih
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSelectedIds([])}
              className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer transition-colors"
            >
              Batal Pilihan
            </button>
            <button
              type="button"
              id="btn-delete-selected-asw"
              onClick={() => setBulkDeleteConfirm('selected')}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Data Terpilih ({selectedIds.length})</span>
            </button>
          </div>
        </div>
      )}

      {/* Assessment Table */}
      {assessmentList.length === 0 ? (
        <div className="py-12 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-2xl space-y-2">
          <p>Belum ada data asesmen awal untuk kelas ini.</p>
          <button
            type="button"
            onClick={() => handleOpenAddModal()}
            className="text-indigo-600 font-bold hover:underline inline-flex items-center gap-1 text-xs"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            Klik di sini untuk memasukkan hasil asesmen awal pertama
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-200">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 text-center w-10">
                  <input
                    type="checkbox"
                    id="checkbox-select-all-asw"
                    checked={assessmentList.length > 0 && selectedIds.length === assessmentList.length}
                    onChange={handleToggleSelectAll}
                    title="Centang semua data"
                    className="w-4 h-4 rounded text-indigo-600 accent-indigo-600 cursor-pointer"
                  />
                </th>
                <th className="py-3 px-4">Nama Murid</th>
                <th className="py-3 px-3 text-center">Diagnostik</th>
                <th className="py-3 px-4 text-center">Kesiapan Belajar</th>
                <th className="py-3 px-3 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {assessmentList.map((item, idx) => {
                const isSelected = selectedIds.includes(item.id);

                const level =
                  item.readinessLevel ||
                  (item.diagnosticScore >= 85
                    ? 'Siap Mandiri'
                    : item.diagnosticScore >= 70
                    ? 'Berkembang'
                    : 'Perlu Pendampingan');

                return (
                  <tr
                    key={item.id}
                    className={`transition-colors ${
                      isSelected ? 'bg-indigo-50/50 hover:bg-indigo-50/80' : 'hover:bg-slate-50/70'
                    }`}
                  >
                    <td className="py-3 px-3 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelectRow(item.id)}
                        className="w-4 h-4 rounded text-indigo-600 accent-indigo-600 cursor-pointer"
                      />
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-800">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                          {(item.studentName || 'M')[0]}
                        </div>
                        <div>
                          <div>{(item.studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim()}</div>
                          <div className="text-[10px] text-slate-400 font-normal">
                            {new Date(item.createdAt).toLocaleDateString('id-ID', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                            })}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-center font-mono font-bold text-indigo-700">
                      {item.diagnosticScore}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full border ${
                          level === 'Siap Mandiri'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : level === 'Berkembang'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-purple-50 text-purple-700 border-purple-200'
                        }`}
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        {level}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditModal(item)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 transition-colors"
                          title="Edit Nilai Asesmen"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item.id, item.studentName)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 transition-colors"
                          title="Hapus Asesmen"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal Input Hasil Asesmen Awal & Alokasi Waktu */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
          <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 flex flex-col max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5 bg-slate-50 shrink-0">
              <div>
                <h3 className="font-display font-bold text-slate-800 text-sm sm:text-base flex items-center gap-2">
                  {modalMode === 'excel' ? (
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                  )}
                  {editingItem
                    ? 'Edit Hasil Asesmen Awal'
                    : modalMode === 'excel'
                    ? `Unggah File Excel Asesmen Kelas ${currentClass?.className}`
                    : 'Input Hasil Asesmen Awal (Diagnostik)'}
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  {modalMode === 'excel'
                    ? 'Unggah berkas spreadsheet data murid dan nilai untuk diproses ke database dan ALME.'
                    : 'Nilai asesmen awal langsung memicu rekomendasi misi belajar adaptif ALME bagi murid.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher Tabs (Manual vs Excel) when adding new */}
            {!editingItem && (
              <div className="flex items-center gap-1.5 p-2 bg-slate-100/80 border-b border-slate-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setModalMode('manual')}
                  className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    modalMode === 'manual'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Input Manual Murid</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModalMode('excel')}
                  className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    modalMode === 'excel'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Unggah File Excel (Banyak Murid)</span>
                </button>
              </div>
            )}

            {/* Content Area */}
            {modalMode === 'excel' ? (
              <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1 text-xs">
                {/* Step 1: Download Template */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      <Download className="w-3.5 h-3.5 text-indigo-600" />
                      <span>1. Unduh Template Excel Standar</span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Format sudah dilengkapi daftar nama murid kelas <strong>{currentClass?.className}</strong>.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleDownloadTemplate}
                    className="h-8 px-3 rounded-xl bg-white border border-slate-300 hover:border-indigo-400 text-slate-700 hover:text-indigo-600 text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs shrink-0 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Unduh Template .xlsx</span>
                  </button>
                </div>

                {/* Step 2: File Upload Box */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-emerald-600" />
                    <span>2. Pilih atau Seret File Excel (.xlsx, .xls, .csv)</span>
                  </label>

                  <input
                    ref={excelFileInputRef}
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleExcelFileSelect(file);
                    }}
                  />

                  <div
                    onClick={() => excelFileInputRef.current?.click()}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const file = e.dataTransfer.files?.[0];
                      if (file) handleExcelFileSelect(file);
                    }}
                    className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/40 hover:bg-emerald-50/70 rounded-2xl p-4 sm:p-5 text-center cursor-pointer transition-colors space-y-2"
                  >
                    <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-2xs">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="font-bold text-xs text-slate-800">
                        {excelFile ? excelFile.name : 'Klik untuk memilih file Excel, atau seret ke sini'}
                      </span>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Mendukung file Microsoft Excel (.xlsx, .xls) dan CSV. Kolom: Nama Murid, Nilai, dll.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Loading State */}
                {isParsingExcel && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-800 text-center font-bold text-xs animate-pulse">
                    Menganalisis isi data spreadsheet...
                  </div>
                )}

                {/* Error Box */}
                {excelParseError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block">Gagal Membaca File</strong>
                      <span>{excelParseError}</span>
                    </div>
                  </div>
                )}

                {/* Parsed Preview Table */}
                {excelParsedRows.length > 0 && (
                  <div className="space-y-2">
                    {/* Summary Badges */}
                    <div className="flex flex-wrap items-center gap-2 text-[11px]">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold border border-slate-200">
                        Total {excelParsedRows.length} Baris
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        {excelParsedRows.filter((r) => r.status === 'valid').length} Siap Disimpan
                      </span>
                      {excelParsedRows.filter((r) => !r.isExistingStudent && r.status === 'valid').length > 0 && (
                        <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-bold border border-indigo-200 flex items-center gap-1">
                          <UserPlus className="w-3 h-3 text-indigo-600" />
                          {excelParsedRows.filter((r) => !r.isExistingStudent && r.status === 'valid').length} Murid Baru (Akun dibuat)
                        </span>
                      )}
                    </div>

                    {/* Table Preview */}
                    <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-48 overflow-y-auto">
                      <table className="w-full text-left text-[11px]">
                        <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold sticky top-0">
                          <tr>
                            <th className="py-2 px-2.5">No</th>
                            <th className="py-2 px-2.5">Nama Murid</th>
                            <th className="py-2 px-2.5 text-center">Nilai</th>
                            <th className="py-2 px-2.5">Kesiapan Belajar</th>
                            <th className="py-2 px-2.5">Status Akun</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {excelParsedRows.map((row, idx) => (
                            <tr key={row.rowNumber || row.no || idx} className={row.status === 'error' || row.status === 'invalid' ? 'bg-rose-50/50' : ''}>
                              <td className="py-1.5 px-2.5 font-mono text-slate-400">{row.rowNumber || row.no || idx + 1}</td>
                              <td className="py-1.5 px-2.5 font-semibold text-slate-800">
                                {row.studentName}
                                {row.username && (
                                  <span className="block text-[9px] font-mono text-slate-400">@{row.username}</span>
                                )}
                              </td>
                              <td className="py-1.5 px-2.5 text-center font-bold font-mono text-indigo-700">
                                {row.diagnosticScore}
                              </td>
                              <td className="py-1.5 px-2.5">
                                <span
                                  className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                    row.readinessLevel === 'Siap Mandiri'
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                      : row.readinessLevel === 'Berkembang'
                                      ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                      : 'bg-purple-50 text-purple-700 border border-purple-200'
                                  }`}
                                >
                                  {row.readinessLevel}
                                </span>
                              </td>
                              <td className="py-1.5 px-2.5">
                                {row.isExistingStudent ? (
                                  <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                                    Terdaftar
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-indigo-600 font-semibold flex items-center gap-1">
                                    <UserPlus className="w-3 h-3 text-indigo-500" />
                                    Akun Baru
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Bottom Actions for Excel Mode */}
                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 sticky bottom-0 bg-white z-10">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    id="btn-commit-excel-import"
                    disabled={excelParsedRows.length === 0 || isCommittingExcel}
                    onClick={handleCommitExcelImport}
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-xs cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {isCommittingExcel
                        ? 'Menyimpan ke Database...'
                        : `Simpan ${excelParsedRows.filter((r) => r.status === 'valid').length} Data ke Database`}
                    </span>
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSaveAssessment} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto flex-1 text-xs">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Pilih Murid Kelas {currentClass?.className} *
                  </label>
                  <select
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-bold focus:border-indigo-500 outline-hidden bg-white"
                  >
                    {students.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 1 Single Overall Assessment Score (Literasi & Numerasi dibaca otomatis oleh ALME) */}
                <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-100 space-y-2">
                  <label className="text-xs font-bold text-indigo-950 block">
                    Nilai Asesmen Awal Keseluruhan (Skor Tunggal 0-100) *
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      required
                      value={diagnosticScore}
                      onChange={(e) => handleDiagnosticChange(Number(e.target.value))}
                      className="w-full h-10 px-3.5 rounded-xl border border-indigo-200 text-sm font-mono font-bold bg-white text-indigo-950 focus:border-indigo-500 outline-hidden"
                      placeholder="Masukkan 1 nilai asesmen..."
                    />
                    <span className="absolute right-3.5 top-2.5 text-[11px] font-bold text-slate-400">
                      Skala 100
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/80 border border-indigo-100 text-[11px] text-indigo-800 flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                    <span>
                      <strong>Cerdas & Otomatis:</strong> Guru cukup memasukkan 1 nilai asesmen awal ini. Skor <strong>Literasi</strong>, <strong>Numerasi Grafis</strong>, dan <strong>Penalaran Ilmiah</strong> akan dianalisis dan dibaca langsung oleh ALME dari hasil capaian misi murid secara mandiri.
                    </span>
                  </div>
                </div>

                {/* Kategori Kesiapan Belajar Siswa (Diagnostik) */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Kategori Kesiapan Belajar Murid *
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        'Siap Mandiri',
                        'Berkembang',
                        'Perlu Pendampingan',
                      ] as const
                    ).map((lvl) => (
                      <button
                        type="button"
                        key={lvl}
                        onClick={() => setReadinessLevel(lvl)}
                        className={`h-9 px-2 text-xs font-semibold rounded-xl border transition-all ${
                          readinessLevel === lvl
                            ? lvl === 'Siap Mandiri'
                              ? 'border-emerald-500 bg-emerald-50 text-emerald-700 font-bold'
                              : lvl === 'Berkembang'
                              ? 'border-amber-500 bg-amber-50 text-amber-700 font-bold'
                              : 'border-purple-500 bg-purple-50 text-purple-700 font-bold'
                            : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Catatan Guru */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Catatan Observasi Guru (Opsional)
                  </label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Catatan diferensiasi, gaya belajar, atau scaffolding yang dibutuhkan..."
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 sticky bottom-0 bg-white z-10">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Simpan & Pemicu Rekomendasi ALME</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Modal Konfirmasi Hapus Satuan Asesmen Awal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Hapus Asesmen Awal</h4>
                <p className="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              Apakah Anda yakin ingin menghapus data asesmen awal murid{' '}
              <strong className="text-slate-800">"{deleteConfirm.name}"</strong>?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-delete-asw"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
              >
                <Trash2 className="w-4 h-4" />
                <span>Hapus Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Konfirmasi Hapus Massal Asesmen Awal */}
      {bulkDeleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">
                  {bulkDeleteConfirm === 'selected' ? 'Hapus Data Terpilih' : 'Hapus Semua Data'}
                </h4>
                <p className="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              {bulkDeleteConfirm === 'selected'
                ? `Apakah Anda yakin ingin menghapus ${selectedIds.length} data asesmen awal yang dicentang?`
                : `Apakah Anda yakin ingin menghapus SELURUH (${assessmentList.length}) data asesmen awal pada kelas ini?`}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setBulkDeleteConfirm(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-bulk-delete-asw"
                onClick={handleConfirmBulkDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
              >
                <Trash2 className="w-4 h-4" />
                <span>
                  {bulkDeleteConfirm === 'selected'
                    ? `Hapus (${selectedIds.length}) Data`
                    : 'Hapus Semua'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

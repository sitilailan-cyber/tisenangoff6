import React, { useState } from 'react';
import {
  Rocket,
  GraduationCap,
  BookOpen,
  ShieldCheck,
  ChevronRight,
  HelpCircle,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import logoTiSenang from '../../assets/images/logo_ti_senang.png';
import welcomeBg from '../../assets/images/welcome_bg.jpg';
import { FallingParticles } from './FallingParticles';
import { DnaLightWave } from './DnaLightWave';
import { RoleSelectionGatewayModal } from './RoleSelectionGatewayModal';

interface WelcomePageProps {
  onOpenAdminLogin?: () => void;
  onSelectRoleLogin: (role: 'guru' | 'murid') => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  onSelectRoleLogin,
}) => {
  const [showRoleModal, setShowRoleModal] = useState(false);

  return (
    <div className="relative w-full h-full min-h-0 flex flex-col justify-center items-center overflow-hidden bg-slate-950">
      {/* Background Image with increased light opacity (+10%) */}
      <div
        className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat pointer-events-none z-0 opacity-70 brightness-[0.78] contrast-[1.03]"
        style={{ backgroundImage: `url(${welcomeBg})` }}
      />
      {/* Soft Vignette Overlays adjusted to let 10% more luminous ambient light through */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/55 via-slate-950/30 to-slate-950/60 pointer-events-none z-0" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-950/45 via-slate-950/15 to-slate-950/60 pointer-events-none z-0" />

      {/* Horizontal DNA Light Wave in Center */}
      <DnaLightWave />

      {/* Falling Particles from Top */}
      <FallingParticles />

      {/* Main Hero Section - Zero scroll, perfectly centered in frame */}
      <main className="relative flex-1 w-full max-w-5xl mx-auto flex flex-col items-center justify-center text-center px-3 sm:px-6 z-10 py-2 sm:py-3">
        {/* LOGO TI SENANG */}
        <div id="front-page-logo-container" className="relative mb-2.5 sm:mb-4 group">
          {/* Ambient luminous glow bernuansa biru senada */}
          <div className="absolute -inset-2 bg-gradient-to-r from-blue-600/35 via-cyan-400/30 to-blue-500/35 rounded-3xl blur-xl opacity-60 group-hover:opacity-90 transition duration-500 pointer-events-none" />
          
          <div className="relative bg-white rounded-2xl sm:rounded-3xl p-1 sm:p-1.5 shadow-2xl shadow-slate-950/40 border border-slate-100 flex items-center justify-center transition-all duration-300 group-hover:shadow-[0_20px_35px_rgba(0,0,0,0.3)] overflow-hidden">
            <img
              id="front-page-logo-img"
              src={logoTiSenang}
              alt="Logo Resmi TI SENANG"
              className="w-[110px] h-[110px] sm:w-[145px] sm:h-[145px] md:w-[170px] md:h-[170px] lg:w-[190px] lg:h-[190px] object-contain drop-shadow-[0_4px_10px_rgba(0,0,0,0.12)] transition-transform duration-300 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Tagline Ringkas & Jelas */}
        <div className="relative w-full max-w-[92vw] sm:max-w-xl md:max-w-2xl mx-auto mb-4 sm:mb-6 px-1">
          <div className="absolute -inset-1.5 bg-gradient-to-r from-blue-600/25 via-cyan-500/20 to-blue-600/25 rounded-2xl blur-lg pointer-events-none" />

          <div
            id="tagline-panel"
            className="relative bg-gradient-to-r from-blue-950/80 via-blue-900/70 to-blue-950/80 backdrop-blur-xl border border-blue-400/30 sm:border-cyan-300/40 rounded-2xl shadow-xl shadow-slate-950/30 px-3.5 sm:px-6 py-2 sm:py-2.5 flex items-center justify-center ring-1 ring-white/10"
          >
            <p
              id="tagline-text"
              className="text-xs sm:text-base font-bold text-white tracking-normal sm:tracking-tight text-center font-display leading-snug drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            >
              Teknologi Inovatif untuk Sistem Pembelajaran Adaptif dan Menggembirakan
            </p>
          </div>
        </div>

        {/* Primary Action Area */}
        <div className="flex flex-col items-center justify-center gap-2 w-full max-w-xs mx-auto">
          {/* 🚀 MULAI */}
          <button
            id="btn-mulai"
            onClick={() => setShowRoleModal(true)}
            className="w-52 sm:w-60 h-12 sm:h-13 px-6 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-500 to-pink-500 hover:from-blue-700 hover:to-pink-600 text-white font-display font-bold text-base sm:text-lg tracking-wide shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/35 transition-all transform active:scale-95 flex items-center justify-center gap-2.5 cursor-pointer"
          >
            <Rocket className="w-5 h-5 animate-bounce" />
            <span>Mulai</span>
          </button>
        </div>
      </main>

      {/* Futuristic Welcome Gateway: Role Selection Modal (Triggered by 🚀 MULAI) */}
      <RoleSelectionGatewayModal
        isOpen={showRoleModal}
        onClose={() => setShowRoleModal(false)}
        onSelectRole={(role) => {
          setShowRoleModal(false);
          onSelectRoleLogin(role);
        }}
      />
    </div>
  );
};

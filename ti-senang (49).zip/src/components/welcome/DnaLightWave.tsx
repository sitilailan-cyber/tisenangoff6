import React, { useEffect, useRef } from 'react';

export const DnaLightWave: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let phase = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener('resize', resize);

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;

      ctx.clearRect(0, 0, width, height);

      const centerY = height / 2;
      // Ukuran diperbesar lebih nyata dengan proporsi elegan
      const amplitude = Math.min(72, height * 0.38);
      const wavelength = 220; // Panjang gelombang lebih luas & megah
      const stepX = 4;
      const rungSpacing = 28; // Jarak pasangan basa proporsional

      // Ambient horizontal soft beam of ethereal light
      const centerBeam = ctx.createLinearGradient(0, centerY, width, centerY);
      centerBeam.addColorStop(0, 'rgba(56, 189, 248, 0)');
      centerBeam.addColorStop(0.2, 'rgba(56, 189, 248, 0.04)');
      centerBeam.addColorStop(0.5, 'rgba(236, 72, 153, 0.06)');
      centerBeam.addColorStop(0.8, 'rgba(56, 189, 248, 0.04)');
      centerBeam.addColorStop(1, 'rgba(56, 189, 248, 0)');

      ctx.fillStyle = centerBeam;
      ctx.fillRect(0, centerY - amplitude * 1.6, width, amplitude * 3.2);

      // Collect base-pair bridges with 3D depth value (cos)
      const rungs: {
        x: number;
        y1: number;
        y2: number;
        z: number;
      }[] = [];

      for (let x = 0; x <= width; x += rungSpacing) {
        const angle = (x / wavelength) * Math.PI * 2 + phase;
        const sinVal = Math.sin(angle);
        const cosVal = Math.cos(angle); // 3D depth

        const y1 = centerY + amplitude * sinVal;
        const y2 = centerY - amplitude * sinVal;

        rungs.push({ x, y1, y2, z: cosVal });
      }

      // 1. Draw back bridges of light (z < 0) - halus & sangat transparan
      rungs.forEach((rung) => {
        if (rung.z < 0) {
          ctx.save();
          const alpha = 0.12 + (rung.z + 1) * 0.14; // 0.12 to 0.26
          ctx.strokeStyle = `rgba(147, 197, 253, ${alpha})`;
          ctx.lineWidth = 1.0;
          ctx.beginPath();
          ctx.moveTo(rung.x, rung.y1);
          ctx.lineTo(rung.x, rung.y2);
          ctx.stroke();

          // Small junction nodes
          ctx.fillStyle = `rgba(192, 132, 252, ${alpha * 1.2})`;
          ctx.beginPath();
          ctx.arc(rung.x, rung.y1, 1.5, 0, Math.PI * 2);
          ctx.arc(rung.x, rung.y2, 1.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      });

      // 2. Draw Helix Strand 1 (Sine wave - Berkas Cahaya Cyan / Sky Blue glowing)
      ctx.save();
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 12;
      ctx.lineWidth = 2.2;

      const grad1 = ctx.createLinearGradient(0, 0, width, 0);
      grad1.addColorStop(0, 'rgba(2, 132, 199, 0.1)');
      grad1.addColorStop(0.25, 'rgba(56, 189, 248, 0.45)');
      grad1.addColorStop(0.5, 'rgba(125, 211, 252, 0.65)');
      grad1.addColorStop(0.75, 'rgba(56, 189, 248, 0.45)');
      grad1.addColorStop(1, 'rgba(2, 132, 199, 0.1)');
      ctx.strokeStyle = grad1;

      ctx.beginPath();
      for (let x = 0; x <= width; x += stepX) {
        const angle = (x / wavelength) * Math.PI * 2 + phase;
        const y = centerY + amplitude * Math.sin(angle);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.restore();

      // 3. Draw Helix Strand 2 (Counter-Sine wave - Berkas Cahaya Magenta / Pink glowing)
      ctx.save();
      ctx.shadowColor = '#e879f9';
      ctx.shadowBlur = 12;
      ctx.lineWidth = 2.2;

      const grad2 = ctx.createLinearGradient(0, 0, width, 0);
      grad2.addColorStop(0, 'rgba(192, 38, 211, 0.1)');
      grad2.addColorStop(0.25, 'rgba(236, 72, 153, 0.45)');
      grad2.addColorStop(0.5, 'rgba(244, 114, 182, 0.65)');
      grad2.addColorStop(0.75, 'rgba(236, 72, 153, 0.45)');
      grad2.addColorStop(1, 'rgba(192, 38, 211, 0.1)');
      ctx.strokeStyle = grad2;

      ctx.beginPath();
      for (let x = 0; x <= width; x += stepX) {
        const angle = (x / wavelength) * Math.PI * 2 + phase;
        const y = centerY - amplitude * Math.sin(angle);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.restore();

      // 4. Draw front bridges of light (z >= 0) with gentle luminous nodes
      rungs.forEach((rung) => {
        if (rung.z >= 0) {
          ctx.save();
          const alpha = 0.25 + rung.z * 0.35; // 0.25 to 0.60
          ctx.strokeStyle = `rgba(244, 114, 182, ${alpha})`;
          ctx.lineWidth = 1.4;
          ctx.shadowColor = '#ec4899';
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.moveTo(rung.x, rung.y1);
          ctx.lineTo(rung.x, rung.y2);
          ctx.stroke();

          // Luminous photon nodes on strand junctions
          ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(1, alpha * 1.3)})`;
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.arc(rung.x, rung.y1, 2.2, 0, Math.PI * 2);
          ctx.arc(rung.x, rung.y2, 2.2, 0, Math.PI * 2);
          ctx.fill();

          // Core spark center
          ctx.fillStyle = `rgba(254, 240, 138, ${alpha * 0.75})`;
          ctx.beginPath();
          ctx.arc(rung.x, (rung.y1 + rung.y2) / 2, 1.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      });

      phase += 0.012; // Aliran gerak cahaya yang lebih tenang & lembut
      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div className="absolute top-1/2 -translate-y-1/2 left-0 w-full h-72 sm:h-80 md:h-[26rem] lg:h-[30rem] pointer-events-none z-[1] overflow-hidden opacity-20 sm:opacity-25 mix-blend-screen">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};

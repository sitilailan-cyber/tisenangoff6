import React, { useState } from 'react';
import {
  Trophy,
  RotateCcw,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Flag,
  Dna,
  X,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface BiologiBalapanPewarisanProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
  onClose?: () => void;
}

interface RaceQuestion {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

const RACE_QUESTIONS: RaceQuestion[] = [
  {
    id: 1,
    question: 'Tokoh biologi yang dijuluki sebagai "Bapak Genetika" adalah...',
    options: ['Gregor Johann Mendel', 'Charles Darwin', 'Louis Pasteur', 'Robert Hooke'],
    correct: 0,
    explanation: 'Gregor Mendel meneliti pewarisan sifat pada tanaman ercis dan merumuskan Hukum Mendel.',
  },
  {
    id: 2,
    question: 'Sifat fisik atau karakteristik yang tampak dan dapat diamati langsung disebut...',
    options: ['Fenotip', 'Genotip', 'Alel homozigot', 'Kariotipe'],
    correct: 0,
    explanation: 'Fenotip adalah ekspresi fisik dari gen (warna, bentuk, ukuran).',
  },
  {
    id: 3,
    question: 'Susunan genetik sebenarnya dari suatu individu (misal: BB, Bb) disebut...',
    options: ['Genotip', 'Fenotip', 'Sentromer', 'Nukleosom'],
    correct: 0,
    explanation: 'Genotip adalah komposisi alel/gen penyusun sifat individu.',
  },
  {
    id: 4,
    question: 'Sifat gen yang mampu menutupi ekspresi gen pasangannya disebut...',
    options: ['Dominan', 'Resesif', 'Intermediet', 'Kodominan'],
    correct: 0,
    explanation: 'Gen dominan menutupi gen resesif saat heterozigot (Bb).',
  },
  {
    id: 5,
    question: 'Individu yang memiliki pasangan alel yang berbeda (misal: Tt) disebut...',
    options: ['Heterozigot', 'Homozigot dominan', 'Homozigot resesif', 'Hemizigot'],
    correct: 0,
    explanation: 'Heterozigot memiliki dua alel yang tidak identik (Tt).',
  },
  {
    id: 6,
    question: 'Rasio fenotip F2 persilangan monohibrid dominan penuh adalah...',
    options: ['3 : 1', '1 : 2 : 1', '9 : 3 : 3 : 1', '1 : 1'],
    correct: 0,
    explanation: 'Persilangan monohibrid F2 menghasilkan rasio 3 dominan : 1 resesif.',
  },
  {
    id: 7,
    question: 'Rasio fenotip F2 persilangan dihibrid Hukum II Mendel adalah...',
    options: ['9 : 3 : 3 : 1', '12 : 3 : 1', '9 : 7', '15 : 1'],
    correct: 0,
    explanation: 'Persilangan dihibrid (AaBb × AaBb) menghasilkan rasio 9:3:3:1.',
  },
  {
    id: 8,
    question: 'Contoh kelainan genetik yang terpaut pada kromosom X adalah...',
    options: ['Buta warna & Hemofilia', 'Albinisme & Anemia', 'Sindrom Down', 'Polidaktili'],
    correct: 0,
    explanation: 'Buta warna dan hemofilia merupakan kelainan resesif terpaut kromosom X.',
  },
  {
    id: 9,
    question: 'Sistem penggolongan darah ABO ditentukan oleh...',
    options: ['Alel ganda (Iᴬ, Iᴮ, Iᴼ)', 'Poligeni', 'Pautan autosom', 'Kriptomeri'],
    correct: 0,
    explanation: 'Golongan darah ABO diatur oleh alel ganda: I^A, I^B, dan I^O.',
  },
  {
    id: 10,
    question: 'Hukum I Mendel dikenal juga sebagai hukum...',
    options: ['Segregasi bebas alel', 'Asortasi bebas gen', 'Dominansi mutlak', 'Pautan kelamin'],
    correct: 0,
    explanation: 'Hukum I Mendel menyatakan pemisahan (segregasi) bebas pasangan alel saat gametogenesis.',
  },
];

export const BiologiBalapanPewarisan: React.FC<BiologiBalapanPewarisanProps> = ({
  onFinishGame,
  onBackToGameList,
  onClose,
}) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [p1Distance, setP1Distance] = useState<number>(10);
  const [p2Distance, setP2Distance] = useState<number>(10);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const currentQ = RACE_QUESTIONS[currentIdx];

  const handleSelectOption = (idx: number) => {
    if (isAnswered || isFinished) return;
    setSelectedOpt(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correct;

    if (isCorrect) {
      joyfulGameMusic.playCorrect();
      setP1Distance((prev) => Math.min(100, prev + 18));
    } else {
      joyfulGameMusic.playWrong();
      setP1Distance((prev) => Math.min(100, prev + 4));
    }

    const p2IsCorrect = Math.random() < 0.7;
    const p2Add = p2IsCorrect ? 13 : 5;
    setP2Distance((prev) => Math.min(100, prev + p2Add));
  };

  const handleNextRound = () => {
    if (currentIdx + 1 < RACE_QUESTIONS.length && p1Distance < 100 && p2Distance < 100) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOpt(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
      joyfulGameMusic.playVictory();
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setP1Distance(10);
    setP2Distance(10);
    setSelectedOpt(null);
    setIsAnswered(false);
    setIsFinished(false);
  };

  const p1Wins = p1Distance >= p2Distance;

  return (
    <div className="w-full max-w-xl mx-auto rounded-2xl overflow-hidden shadow-xl border border-emerald-500/40 bg-slate-950 text-white font-sans text-xs">
      {/* Top Header Ringkas */}
      <div className="px-2.5 py-1.5 bg-slate-900/90 border-b border-emerald-900/50 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 border border-slate-700 cursor-pointer shrink-0"
            >
              ← <span>Game</span>
            </button>
          )}

          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-extrabold text-[10px] sm:text-[11px] truncate">
            <Dna className="w-3 h-3 text-emerald-400" />
            <span className="truncate">Balapan DNA Pewarisan</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0 text-[10px] sm:text-[11px]">
          <div className="px-1.5 py-0.5 rounded-lg bg-slate-900 border border-emerald-800/60 text-emerald-300 font-bold">
            Ronde: <span className="font-mono text-white">{currentIdx + 1}/10</span>
          </div>
          {(onClose || onBackToGameList) && (
            <button
              type="button"
              onClick={onClose || onBackToGameList}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors flex items-center justify-center cursor-pointer shrink-0"
              title="Tutup Game & Kembali ke Halaman Misi 4 Game Sains"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Lintasan Balap 2 Pemain Kompak */}
      <div className="px-2 py-1 bg-gradient-to-b from-slate-900 to-slate-950 border-b border-emerald-950 space-y-1">
        <div className="flex items-center justify-between text-[9px] text-slate-400 font-bold">
          <span>Lintasan Balapan DNA:</span>
          <span className="flex items-center gap-0.5 text-amber-300 font-mono">
            <Flag className="w-2.5 h-2.5 text-amber-400" />
            Finish
          </span>
        </div>

        {/* P1 Track */}
        <div className="px-1.5 py-0.5 rounded-lg bg-slate-900/90 border border-emerald-600/40">
          <div className="flex items-center justify-between text-[9px] font-bold mb-0.5">
            <span className="text-emerald-400">🤖 Kamu: {p1Distance}m</span>
            {p1Distance >= p2Distance && (
              <span className="text-[8px] px-1 py-0.1 rounded bg-emerald-500/20 text-emerald-300 font-black">
                Memimpin!
              </span>
            )}
          </div>
          <div className="w-full bg-slate-950 h-2.5 rounded-md border border-slate-800 relative overflow-hidden flex items-center px-0.5">
            <div
              className="h-2 rounded bg-gradient-to-r from-emerald-500 to-teal-300 transition-all duration-300 flex items-center justify-end pr-0.5"
              style={{ width: `${p1Distance}%` }}
            >
              <span className="text-[9px]">🏎️</span>
            </div>
          </div>
        </div>

        {/* P2 Track */}
        <div className="px-1.5 py-0.5 rounded-lg bg-slate-900/90 border border-purple-600/40">
          <div className="flex items-center justify-between text-[9px] font-bold mb-0.5">
            <span className="text-purple-400">🧬 Mendel Bot: {p2Distance}m</span>
            {p2Distance > p1Distance && (
              <span className="text-[8px] px-1 py-0.1 rounded bg-purple-500/20 text-purple-300 font-black">
                Memimpin!
              </span>
            )}
          </div>
          <div className="w-full bg-slate-950 h-2.5 rounded-md border border-slate-800 relative overflow-hidden flex items-center px-0.5">
            <div
              className="h-2 rounded bg-gradient-to-r from-purple-500 to-indigo-300 transition-all duration-300 flex items-center justify-end pr-0.5"
              style={{ width: `${p2Distance}%` }}
            >
              <span className="text-[9px]">🏎️</span>
            </div>
          </div>
        </div>
      </div>

      {/* Screen Finish / Soal */}
      {isFinished ? (
        <div className="p-3 sm:p-4 text-center space-y-2 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-11 h-11 mx-auto rounded-xl bg-gradient-to-tr from-emerald-400 via-teal-400 to-amber-400 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Trophy className="w-5 h-5 text-amber-400 animate-bounce" />
            </div>
          </div>

          <div>
            <h2 className="text-sm sm:text-base font-black text-white">
              {p1Wins ? 'Juara 1 Balapan! 🏆🎉' : 'Balapan Selesai! 🏎️'}
            </h2>
            <p className="text-slate-300 text-[10px] sm:text-[11px]">
              {p1Wins ? 'Kamu berhasil mengungguli lawan dalam materi pewarisan sifat!' : 'Penguasaan konsep genetika kamu sudah bagus!'}
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={handleRestart}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] transition-all border border-slate-700 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Balapan Lagi</span>
            </button>
            <button
              type="button"
              onClick={() => onFinishGame(100)}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-black text-[11px] shadow-md flex items-center gap-1 cursor-pointer active:scale-95"
            >
              <Trophy className="w-3 h-3 text-amber-300" />
              <span>Selesaikan Misi & Buka Misi 5 dan Misi 6</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-2 sm:p-2.5 space-y-1.5 sm:space-y-2">
          {/* Header Soal */}
          <div className="flex items-center justify-between text-[9px] sm:text-[10px] text-slate-400">
            <span className="font-extrabold text-emerald-400 uppercase tracking-wider">
              Soal Balapan Genetika
            </span>
            <span className="px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-800 font-mono font-bold text-slate-300 shrink-0">
              {currentIdx + 1}/10
            </span>
          </div>

          {/* Kotak Pertanyaan */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-slate-900/90 border border-emerald-900/60 shadow-xs">
            <h3 className="text-[11px] sm:text-xs font-bold text-white leading-snug">
              {currentQ.question}
            </h3>
          </div>

          {/* 4 Opsi */}
          <div className="grid grid-cols-1 gap-1">
            {currentQ.options.map((opt, i) => {
              const isSelected = selectedOpt === i;
              const isCorrectOpt = i === currentQ.correct;

              let btnStyle = 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200';
              if (isAnswered) {
                if (isCorrectOpt) {
                  btnStyle = 'bg-emerald-600/90 border-emerald-400 text-white font-bold ring-1 ring-emerald-400/50';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-600/90 border-rose-400 text-white font-bold ring-1 ring-rose-400/50';
                } else {
                  btnStyle = 'bg-slate-900/30 border-slate-800/60 text-slate-500';
                }
              }

              return (
                <button
                  key={i}
                  type="button"
                  disabled={isAnswered}
                  onClick={() => handleSelectOption(i)}
                  className={`w-full py-1 sm:py-1.5 px-2 sm:px-2.5 rounded-lg sm:rounded-xl border transition-all flex items-center gap-1.5 sm:gap-2 text-left cursor-pointer active:scale-98 ${btnStyle}`}
                >
                  <span className="w-4 h-4 rounded bg-black/40 border border-white/10 flex items-center justify-center text-[9px] font-black shrink-0">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-[10px] sm:text-[11px] font-medium flex-1 leading-tight">
                    {opt}
                  </span>
                  {isAnswered && isCorrectOpt && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  )}
                  {isAnswered && isSelected && !isCorrectOpt && (
                    <XCircle className="w-3.5 h-3.5 text-rose-300 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Feedback & Tombol */}
          {isAnswered && (
            <div className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-slate-900/90 border border-emerald-900/80 flex items-center justify-between gap-1.5 animate-in fade-in duration-150">
              <p className="text-[9.5px] sm:text-[10.5px] text-slate-300 leading-tight flex-1 line-clamp-2">
                <span className="font-bold text-teal-400">💡 Info: </span>
                {currentQ.explanation}
              </p>
              <button
                type="button"
                onClick={handleNextRound}
                className="px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] sm:text-[11px] shadow-xs transition-all flex items-center gap-1 cursor-pointer shrink-0 active:scale-95"
              >
                <span>Ronde Lanjut</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

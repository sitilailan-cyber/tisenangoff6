import React, { useState, useEffect, useMemo } from 'react';
import {
  Award,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  ArrowRight,
  Send,
  FileQuestion,
  CheckSquare,
  ArrowUpDown,
  ListOrdered,
  RotateCcw,
  Trophy,
  Check,
  X,
} from 'lucide-react';
import { Mission, QuestionItem, AsesmenAkhirRecord } from '../../types';
import { storage } from '../../services/storage';
import { soundEffects } from '../../services/audio/soundEffects';

interface Misi6AsesmenProps {
  studentId: string;
  studentName?: string;
  classId?: string;
  className?: string;
  missionId: string;
  mission?: Mission;
  onCompleted?: () => void;
  onClose?: () => void;
}

export const Misi6Asesmen: React.FC<Misi6AsesmenProps> = ({
  studentId,
  studentName = 'Murid TI SENANG',
  classId = 'cls-xii-1',
  className = 'XII-1',
  missionId,
  mission,
  onCompleted,
  onClose,
}) => {
  // Default 6-question set representing all 6 question types if not provided by teacher
  const defaultQuestions: QuestionItem[] = [
    {
      id: 'q6-1',
      category: 'pilihan_ganda',
      prompt:
        'Pada persamaan garis regresi pemanasan kalor ŷ = 4.2x + 25 (x = waktu dalam menit, ŷ = suhu dalam °C), nilai 25 merepresentasikan...',
      options: [
        'Suhu awal cairan saat waktu x = 0 menit (intercept)',
        'Laju kenaikan suhu per menit (slope)',
        'Suhu maksimum saat air mendidih',
        'Koefisien determinasi korelasi data',
      ],
      correctAnswer: 'Suhu awal cairan saat waktu x = 0 menit (intercept)',
      explanation:
        'Titik potong sumbu Y (intercept c = 25) menunjukkan nilai variabel terikat saat variabel bebas x bernilai 0.',
      points: 15,
    },
    {
      id: 'q6-2',
      category: 'benar_salah',
      prompt:
        'Koefisien determinasi R² bernilai antara 0 sampai 1. Semakin mendekati 1, semakin baik garis regresi linear memodelkan sebaran data eksperimen.',
      correctAnswer: 'Benar',
      explanation:
        'Pernyataan BENAR. R² mengukur proporsi variasi variabel terikat yang berhasil diterangkan oleh variabel bebas.',
      points: 15,
    },
    {
      id: 'q6-3',
      category: 'mcma',
      prompt:
        'Pilihlah DUA faktor utama yang menentukan jumlah energi kalor (Q) yang diserap oleh suatu zat cair:',
      options: [
        'Massa zat cair (m)',
        'Perubahan suhu / temperatur (ΔT)',
        'Warna wadah penampung kalorimeter',
        'Bentuk geometris bejana ukur',
      ],
      correctAnswer: ['Massa zat cair (m)', 'Perubahan suhu / temperatur (ΔT)'],
      explanation:
        'Berdasarkan rumus Q = m · c · ΔT, kalor bergantung langsung pada massa (m), kalor jenis (c), dan kenaikan suhu (ΔT).',
      points: 20,
    },
    {
      id: 'q6-4',
      category: 'isian',
      prompt:
        'Tuliskan satuan Standar Internasional (SI) untuk kalor jenis (c) zat! (Gunakan format: J/kg°C atau J/kg K)',
      correctAnswer: 'J/kg°C',
      explanation: 'Satuan kalor jenis dalam SI adalah Joule per kilogram derajat Celcius (J/kg°C) atau J/(kg·K).',
      points: 15,
    },
    {
      id: 'q6-5',
      category: 'jodohkan',
      prompt: 'Jodohkan istilah fisis di kolom kiri dengan pasangan makna konsep di kolom kanan:',
      matchingPairs: [
        { premise: 'Azas Black', match: 'Q_lepas = Q_terima' },
        { premise: 'Diagram Pencar', match: 'Sebaran titik data (x, y)' },
        { premise: 'Garis Regresi', match: 'Line of Best Fit' },
      ],
      explanation:
        'Azas Black menyatakan hukum kekekalan kalor, diagram pencar menyajikan sebaran titik, dan garis regresi adalah garis model terbaik.',
      points: 20,
    },
    {
      id: 'q6-6',
      category: 'mengurutkan',
      prompt:
        'Urutkan tahapan metode ilmiah dalam eksperimen fisika berbasis data berikut dari awal hingga akhir:',
      sequenceItems: [
        '1. Mengamati fenomena dan merumuskan masalah',
        '2. Melakukan eksperimen dan merekam data',
        '3. Membuat grafik regresi linear',
        '4. Menarik kesimpulan dan merefleksi',
      ],
      explanation:
        'Urutan ilmiah yang benar adalah: Amati fenomena ➔ Eksperimen & ambil data ➔ Analisis grafik regresi ➔ Tarik kesimpulan.',
      points: 15,
    },
  ];

  // Gunakan soal dari guru jika ada, atau default lengkap 6 kategori
  const activeQuestions: QuestionItem[] = useMemo(() => {
    if (mission?.questions && mission.questions.length > 0) {
      return mission.questions;
    }
    return defaultQuestions;
  }, [mission]);

  // State jawaban murid
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [matchingSelections, setMatchingSelections] = useState<Record<string, Record<number, string>>>({});
  const [sequenceOrders, setSequenceOrders] = useState<Record<string, string[]>>(() => {
    const initial: Record<string, string[]> = {};
    activeQuestions.forEach((q) => {
      if (q.category === 'mengurutkan' && q.sequenceItems) {
        // Acak urutan tampilan awal
        initial[q.id] = [...q.sequenceItems].sort(() => Math.random() - 0.5);
      }
    });
    return initial;
  });

  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [finalScore, setFinalScore] = useState<number>(0);
  const [showCelebration, setShowCelebration] = useState<boolean>(false);
  const [showCompletionPopup, setShowCompletionPopup] = useState<boolean>(false);

  // Periksa apakah siswa sudah pernah mengerjakan asesmen ini sebelumnya
  useEffect(() => {
    const records = storage.getAsesmenAkhirRecords();
    const existing = records.find(
      (r) => r.studentId === studentId && (r.missionId === missionId || r.missionId === 'misi-6')
    );
    if (existing) {
      setIsSubmitted(true);
      setFinalScore(existing.score || 100);
    }
  }, [studentId, missionId]);

  // Helper untuk memindahkan item urutan
  const moveSequenceItem = (qId: string, fromIdx: number, toIdx: number) => {
    if (isSubmitted) return;
    const current = sequenceOrders[qId] || [];
    if (toIdx < 0 || toIdx >= current.length) return;
    const updated = [...current];
    const temp = updated[fromIdx];
    updated[fromIdx] = updated[toIdx];
    updated[toIdx] = temp;
    setSequenceOrders((prev) => ({ ...prev, [qId]: updated }));
  };

  // Submit Asesmen
  const handleSubmitAsesmen = (e: React.FormEvent) => {
    e.preventDefault();

    let totalPointsEarned = 0;
    let maxPoints = 0;

    activeQuestions.forEach((q) => {
      const qPoints = q.points || 15;
      maxPoints += qPoints;

      if (q.category === 'pilihan_ganda') {
        if (userAnswers[q.id] === q.correctAnswer) {
          totalPointsEarned += qPoints;
        }
      } else if (q.category === 'benar_salah') {
        if (userAnswers[q.id] === q.correctAnswer) {
          totalPointsEarned += qPoints;
        }
      } else if (q.category === 'mcma') {
        const selected = (userAnswers[q.id] as string[]) || [];
        const correctList = Array.isArray(q.correctAnswer)
          ? q.correctAnswer
          : [q.correctAnswer as string];
        const isAllCorrect =
          selected.length === correctList.length &&
          selected.every((s) => correctList.includes(s));
        if (isAllCorrect) {
          totalPointsEarned += qPoints;
        } else if (selected.some((s) => correctList.includes(s))) {
          totalPointsEarned += Math.round(qPoints / 2);
        }
      } else if (q.category === 'isian') {
        const studentAns = (userAnswers[q.id] || '').toString().trim().toLowerCase();
        const correctAns = (q.correctAnswer || '').toString().trim().toLowerCase();
        if (studentAns.includes(correctAns) || correctAns.includes(studentAns)) {
          totalPointsEarned += qPoints;
        }
      } else if (q.category === 'jodohkan') {
        const matches = matchingSelections[q.id] || {};
        let pairCorrect = 0;
        (q.matchingPairs || []).forEach((pair, pIdx) => {
          if (matches[pIdx] === pair.match) {
            pairCorrect += 1;
          }
        });
        if (q.matchingPairs && q.matchingPairs.length > 0) {
          totalPointsEarned += Math.round((pairCorrect / q.matchingPairs.length) * qPoints);
        }
      } else if (q.category === 'mengurutkan') {
        const currentOrder = sequenceOrders[q.id] || [];
        const targetOrder = q.sequenceItems || [];
        const isMatched = currentOrder.every((item, idx) => item === targetOrder[idx]);
        if (isMatched) {
          totalPointsEarned += qPoints;
        } else {
          totalPointsEarned += Math.round(qPoints * 0.4);
        }
      }
    });

    const calculatedScore = Math.max(40, Math.min(100, Math.round((totalPointsEarned / (maxPoints || 100)) * 100)));
    setFinalScore(calculatedScore);
    setIsSubmitted(true);
    setShowCelebration(true);
    setShowCompletionPopup(true);

    if (calculatedScore >= 75) {
      soundEffects.playCorrect();
    } else {
      soundEffects.playIncorrect();
    }

    // 1. Simpan ke Rekor Asesmen Akhir Guru
    const cleanName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
    const newRecord: AsesmenAkhirRecord = {
      id: `ask-${studentId}-${Date.now()}`,
      studentId,
      studentName: cleanName,
      classId,
      subjectId: 'sbj-fisika',
      score: calculatedScore,
      kktpStatus: calculatedScore >= 75 ? 'Tuntas' : 'Belum Tuntas',
      predikat:
        calculatedScore >= 88
          ? 'A (Sangat Baik)'
          : calculatedScore >= 75
          ? 'B (Baik)'
          : calculatedScore >= 65
          ? 'C (Cukup)'
          : 'D (Perlu Bimbingan)',
      tpMasteryPercentage: calculatedScore,
      catatan: `Mengerjakan Asesmen Akhir secara mandiri dengan skor ${calculatedScore}/100.`,
      tanggal: new Date().toISOString().split('T')[0],
      soalCount: activeQuestions.length,
    };
    storage.saveAsesmenAkhirRecord(newRecord);

    // 2. Selesaikan Misi 6 (TIDAK ADA PORTOFOLIO)
    storage.completeMission(studentId, missionId, calculatedScore, mission?.xpReward || 150);

    // 3. Callback membuka semua misi / selesai petualangan
    if (onCompleted) {
      onCompleted();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider mb-2">
              <Award className="w-3.5 h-3.5" />
              Misi 6 • Asesmen Akhir
            </div>
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold tracking-tight">
              {mission?.title || 'Lembar Asesmen Komprehensif Sains'}
            </h1>
            <p className="text-amber-100 text-xs sm:text-sm mt-1 max-w-xl">
              Soal dikirim langsung oleh guru (atau bantuan AI) meliputi 6 kategori soal. Selesaikan asesmen ini untuk menuntaskan seluruh petualangan belajar!
            </p>
          </div>

          <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur border border-white/30 text-white self-start sm:self-auto">
            +{mission?.xpReward || 150} XP
          </span>
        </div>
      </div>

      {/* GRAND CELEBRATION MODAL CARD: SEMUA MISI SELESAI */}
      {showCelebration && (
        <div className="p-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 rounded-3xl text-white shadow-xl text-center space-y-4 animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-3xl bg-white/20 flex items-center justify-center mx-auto shadow-md">
            <Trophy className="w-8 h-8 text-amber-300" />
          </div>
          <div className="space-y-1">
            <h2 className="text-2xl font-extrabold font-display">
              🎉 Selamat! Seluruh Misi Belajar TI SENANG Tuntas!
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-lg mx-auto leading-relaxed">
              Anda telah berhasil menyelesaikan Misi 1 sampai 6 dengan dedikasi luar biasa. Skor Asesmen Akhir Anda:{' '}
              <strong className="text-amber-300 font-mono text-base">{finalScore}/100</strong>.
            </p>
          </div>
          <div className="pt-2 flex justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                if (onClose) onClose();
              }}
              className="px-6 py-2.5 rounded-2xl bg-white text-emerald-800 hover:bg-emerald-50 font-bold text-xs shadow-md cursor-pointer active:scale-95"
            >
              Kembali ke Peta Petualangan
            </button>
          </div>
        </div>
      )}

      {/* DAFTAR SOAL ASESMEN (6 KATEGORI) */}
      <form onSubmit={handleSubmitAsesmen} className="space-y-6">
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="font-display font-bold text-slate-800 text-base flex items-center gap-2">
                <FileQuestion className="w-5 h-5 text-amber-600" />
                <span>Lembar Soal Asesmen Murid ({activeQuestions.length} Soal)</span>
              </h2>
              <p className="text-xs text-slate-500">
                Jawablah setiap butir soal sesuai kategori dan petunjuk yang tertera.
              </p>
            </div>
            {isSubmitted && (
              <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-300">
                Skor: {finalScore}/100
              </span>
            )}
          </div>

          <div className="space-y-6">
            {activeQuestions.map((q, idx) => (
              <div
                key={q.id}
                className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3 relative"
              >
                {/* Header Butir Soal */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                      {idx + 1}
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-700">
                      {q.category === 'pilihan_ganda'
                        ? 'Pilihan Ganda'
                        : q.category === 'benar_salah'
                        ? 'Benar / Salah'
                        : q.category === 'mcma'
                        ? 'PG Kompleks (MCMA)'
                        : q.category === 'isian'
                        ? 'Isian Singkat'
                        : q.category === 'jodohkan'
                        ? 'Menjodohkan'
                        : 'Mengurutkan'}
                    </span>
                  </div>

                  <span className="text-xs font-mono font-bold text-slate-400">
                    +{q.points || 15} Poin
                  </span>
                </div>

                {/* Teks Soal */}
                <p className="text-xs sm:text-sm font-bold text-slate-800 leading-relaxed">
                  {q.prompt}
                </p>

                {/* 1. PILIHAN GANDA (PG) */}
                {q.category === 'pilihan_ganda' && q.options && (
                  <div className="space-y-2 pt-1">
                    {q.options.map((opt, oIdx) => {
                      const isSelected = userAnswers[q.id] === opt;
                      return (
                        <button
                          key={oIdx}
                          type="button"
                          disabled={isSubmitted}
                          onClick={() => {
                            setUserAnswers((prev) => ({ ...prev, [q.id]: opt }));
                            if (q.correctAnswer) {
                              if (opt === q.correctAnswer) {
                                soundEffects.playCorrect();
                              } else {
                                soundEffects.playIncorrect();
                              }
                            }
                          }}
                          className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center gap-3 cursor-pointer ${
                            isSelected
                              ? 'bg-amber-50 border-amber-400 text-amber-950 font-bold ring-2 ring-amber-300'
                              : 'bg-white border-slate-200 hover:border-amber-300 text-slate-700'
                          }`}
                        >
                          <span className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-xs shrink-0">
                            {String.fromCharCode(65 + oIdx)}
                          </span>
                          <span className="flex-1">{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 2. BENAR / SALAH */}
                {q.category === 'benar_salah' && (
                  <div className="flex gap-3 pt-1">
                    {['Benar', 'Salah'].map((val) => {
                      const isSelected = userAnswers[q.id] === val;
                      return (
                        <button
                          key={val}
                          type="button"
                          disabled={isSubmitted}
                          onClick={() => {
                            setUserAnswers((prev) => ({ ...prev, [q.id]: val }));
                            if (q.correctAnswer) {
                              if (val === q.correctAnswer) {
                                soundEffects.playCorrect();
                              } else {
                                soundEffects.playIncorrect();
                              }
                            }
                          }}
                          className={`flex-1 p-3 rounded-xl border text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                            isSelected
                              ? val === 'Benar'
                                ? 'bg-emerald-50 border-emerald-400 text-emerald-900 ring-2 ring-emerald-300'
                                : 'bg-rose-50 border-rose-400 text-rose-900 ring-2 ring-rose-300'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {val === 'Benar' ? (
                            <Check className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <X className="w-4 h-4 text-rose-600" />
                          )}
                          <span>{val}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 3. MCMA / PG KOMPLEKS */}
                {q.category === 'mcma' && q.options && (
                  <div className="space-y-2 pt-1">
                    {q.options.map((opt, oIdx) => {
                      const selectedList: string[] = userAnswers[q.id] || [];
                      const isSelected = selectedList.includes(opt);
                      return (
                        <button
                          key={oIdx}
                          type="button"
                          disabled={isSubmitted}
                          onClick={() => {
                            const updated = isSelected
                              ? selectedList.filter((s) => s !== opt)
                              : [...selectedList, opt];
                            setUserAnswers((prev) => ({ ...prev, [q.id]: updated }));
                          }}
                          className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center gap-3 cursor-pointer ${
                            isSelected
                              ? 'bg-indigo-50 border-indigo-400 text-indigo-950 font-bold ring-2 ring-indigo-300'
                              : 'bg-white border-slate-200 hover:border-indigo-300 text-slate-700'
                          }`}
                        >
                          <div
                            className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 ${
                              isSelected
                                ? 'bg-indigo-600 border-indigo-600 text-white'
                                : 'border-slate-300 bg-white'
                            }`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5" />}
                          </div>
                          <span className="flex-1">{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 4. ISIAN SINGKAT */}
                {q.category === 'isian' && (
                  <div className="pt-1">
                    <input
                      type="text"
                      disabled={isSubmitted}
                      value={userAnswers[q.id] || ''}
                      onChange={(e) =>
                        setUserAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                      }
                      placeholder="Ketikkan jawaban singkat Anda di sini..."
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-400 bg-white"
                    />
                  </div>
                )}

                {/* 5. MENJODOHKAN */}
                {q.category === 'jodohkan' && q.matchingPairs && (
                  <div className="space-y-2 pt-1">
                    {q.matchingPairs.map((pair, pIdx) => {
                      const allMatches = q.matchingPairs!.map((p) => p.match);
                      const currentMatch = matchingSelections[q.id]?.[pIdx] || '';
                      return (
                        <div
                          key={pIdx}
                          className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-white rounded-xl border border-slate-200"
                        >
                          <span className="text-xs font-bold text-slate-800">
                            {pair.premise}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="text-slate-400 text-xs">➔</span>
                            <select
                              disabled={isSubmitted}
                              value={currentMatch}
                              onChange={(e) => {
                                const val = e.target.value;
                                setMatchingSelections((prev) => ({
                                  ...prev,
                                  [q.id]: {
                                    ...(prev[q.id] || {}),
                                    [pIdx]: val,
                                  },
                                }));
                              }}
                              className="h-8 px-2 rounded-lg border border-slate-300 text-xs bg-white text-slate-800 font-semibold"
                            >
                              <option value="">-- Pilih Jodoh Konsep --</option>
                              {allMatches.map((m, mIdx) => (
                                <option key={mIdx} value={m}>
                                  {m}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* 6. MENGURUTKAN */}
                {q.category === 'mengurutkan' && (
                  <div className="space-y-1.5 pt-1">
                    {(sequenceOrders[q.id] || q.sequenceItems || []).map((step, sIdx) => (
                      <div
                        key={sIdx}
                        className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200 gap-2"
                      >
                        <div className="flex items-center gap-2 text-xs font-semibold text-slate-800">
                          <span className="w-5 h-5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold flex items-center justify-center shrink-0">
                            {sIdx + 1}
                          </span>
                          <span>{step}</span>
                        </div>
                        {!isSubmitted && (
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => moveSequenceItem(q.id, sIdx, sIdx - 1)}
                              disabled={sIdx === 0}
                              className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs flex items-center justify-center disabled:opacity-30 cursor-pointer"
                            >
                              ▲
                            </button>
                            <button
                              type="button"
                              onClick={() => moveSequenceItem(q.id, sIdx, sIdx + 1)}
                              disabled={
                                sIdx ===
                                (sequenceOrders[q.id] || q.sequenceItems || []).length - 1
                              }
                              className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs flex items-center justify-center disabled:opacity-30 cursor-pointer"
                            >
                              ▼
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Pembahasan jika sudah disubmit */}
                {isSubmitted && q.explanation && (
                  <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-xs text-amber-900 mt-2">
                    <strong className="block mb-0.5">💡 Pembahasan:</strong>
                    <span>{q.explanation}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* FOOTER: KIRIM ASESMEN -> SEMUA MISI OTOMATIS SELESAI */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-600">
            <p className="font-bold text-slate-800">Siap Mengirim Lembar Asesmen?</p>
            <p className="text-slate-500 mt-0.5">
              Nilai langsung dihitung dan tersimpan di Guru. Semua misi belajar akan otomatis tuntas tanpa perlu mengunggah portofolio.
            </p>
          </div>

          {isSubmitted ? (
            <button
              id="btn-selesai-asesmen"
              type="button"
              onClick={() => setShowCompletionPopup(true)}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              <Trophy className="w-4 h-4 text-amber-300" />
              <span>Asesmen Tuntas • Lihat Hasil Progress</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="btn-kirim-asesmen"
              type="submit"
              disabled={isSubmitted}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 hover:from-amber-700 hover:to-rose-700 text-white"
            >
              <Send className="w-4 h-4" />
              <span>Kirim Jawaban Asesmen & Tuntaskan Seluruh Misi</span>
            </button>
          )}
        </div>
      </form>

      {/* =========================================================================
          POP UP OTOMATIS TANPA SCROLL: SELAMAT, SEMUA MISI KAMU TELAH SELESAI.
          ========================================================================= */}
      {showCompletionPopup && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-hidden animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl sm:rounded-3xl max-w-lg w-full p-4 sm:p-6 text-white space-y-4 my-auto shadow-2xl relative overflow-hidden">
            {/* Ambient Background Glow */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

            {/* Header / Trophy Icon */}
            <div className="text-center space-y-2 relative z-10">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/25 animate-bounce">
                <Trophy className="w-7 h-7 sm:w-8 sm:h-8 text-slate-950 fill-slate-950" />
              </div>

              {/* Exact Requested Title */}
              <h2 className="text-base sm:text-lg md:text-xl font-display font-black text-amber-300 tracking-tight leading-snug">
                Selamat, semua misi kamu telah selesai.
              </h2>

              <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
                Luar biasa, <strong className="text-white">{(studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim()}</strong>! Seluruh 6 misi pembelajaran Fase F telah tuntas kamu selesaikan dengan gemilang.
              </p>
            </div>

            {/* HASIL PROGRESS SISWA RINGKAS TANPA SCROLL */}
            <div className="bg-slate-950/70 border border-slate-800/90 rounded-xl p-3 sm:p-4 space-y-3 relative z-10">
              {/* Stat Cards Grid */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2 sm:p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-[10px] font-mono uppercase text-slate-400">Skor Asesmen</div>
                  <div className="text-lg sm:text-xl font-display font-black text-amber-300 font-mono">
                    {finalScore}
                    <span className="text-[10px] text-slate-500 font-normal">/100</span>
                  </div>
                  <div className="text-[9px] font-bold text-cyan-400">
                    {finalScore >= 75 ? 'Tuntas KKTP' : 'Tuntas'}
                  </div>
                </div>

                <div className="p-2 sm:p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-[10px] font-mono uppercase text-slate-400">Reward XP</div>
                  <div className="text-lg sm:text-xl font-display font-black text-cyan-300 font-mono">
                    +{mission?.xpReward || 150}
                  </div>
                  <div className="text-[9px] font-bold text-slate-400">XP Bertambah</div>
                </div>

                <div className="p-2 sm:p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-[10px] font-mono uppercase text-slate-400">Ketercapaian</div>
                  <div className="text-lg sm:text-xl font-display font-black text-amber-300 font-mono">
                    6 / 6
                  </div>
                  <div className="text-[9px] font-bold text-cyan-400">100% Selesai</div>
                </div>
              </div>

              {/* 6 Mission Check Progress Badges Compact */}
              <div className="pt-1">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[10px] sm:text-[11px]">
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-blue-500/10 text-blue-300 border border-blue-500/20 truncate">
                    <CheckCircle2 className="w-3 h-3 text-blue-400 shrink-0" />
                    <span className="truncate">M1: Konsep</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 truncate">
                    <CheckCircle2 className="w-3 h-3 text-indigo-400 shrink-0" />
                    <span className="truncate">M2: Masalah</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 truncate">
                    <CheckCircle2 className="w-3 h-3 text-cyan-400 shrink-0" />
                    <span className="truncate">M3: Virtual Lab</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 truncate">
                    <CheckCircle2 className="w-3 h-3 text-amber-400 shrink-0" />
                    <span className="truncate">M4: Game</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-purple-500/10 text-purple-300 border border-purple-500/20 truncate">
                    <CheckCircle2 className="w-3 h-3 text-purple-400 shrink-0" />
                    <span className="truncate">M5: Refleksi</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-fuchsia-500/10 text-fuchsia-300 border border-fuchsia-500/20 truncate">
                    <CheckCircle2 className="w-3 h-3 text-fuchsia-400 shrink-0" />
                    <span className="truncate">M6: Asesmen</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-1 relative z-10">
              <button
                type="button"
                onClick={() => setShowCompletionPopup(false)}
                className="px-3.5 py-2 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-colors cursor-pointer text-center"
              >
                Tinjau Lembar Soal
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowCompletionPopup(false);
                  if (onClose) onClose();
                }}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-xs font-black shadow-lg shadow-indigo-950/40 transition-all cursor-pointer text-center"
              >
                Kembali ke Peta Misi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

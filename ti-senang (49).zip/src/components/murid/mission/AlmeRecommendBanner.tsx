import React from 'react';
import { Sparkles, Star, ArrowRight, Brain, Target, Zap, BookOpen } from 'lucide-react';
import { AlmeRecommendation, Mission, AlmeInterventionType } from '../../../types';
import { GameMissionItem } from './MissionTypes';

interface AlmeRecommendBannerProps {
  recommendation: AlmeRecommendation | null | undefined;
  recommendedMissionItem?: GameMissionItem | null;
  onOpenMission: (mission: Mission) => void;
  onOpenIntervention?: (type: AlmeInterventionType) => void;
}

export const AlmeRecommendBanner: React.FC<AlmeRecommendBannerProps> = ({
  recommendation,
  recommendedMissionItem,
  onOpenMission,
  onOpenIntervention,
}) => {
  if (!recommendation && !recommendedMissionItem) return null;

  const title =
    recommendedMissionItem?.title ||
    recommendation?.title ||
    'Perkuat Analisis Sensor & Pemodelan Data';

  const reason =
    recommendation?.whyExplanation ||
    recommendation?.message ||
    'Kamu sudah menguasai konsep dasar regresi linear, tetapi masih perlu memperkuat penerapan pada sensor suhu dan kalorimeter.';

  const progressVal = recommendedMissionItem?.progress ?? 50;
  const xpBonus = (recommendation?.xpReward || recommendedMissionItem?.xpReward || 150);

  const interventionCategory =
    recommendation?.interventionCategory ||
    (recommendation?.interventionType
      ? recommendation.interventionType === 'remedial'
        ? 'Remedial'
        : recommendation.interventionType === 'pengayaan'
        ? 'Pengayaan'
        : recommendation.interventionType === 'soal_literasi'
        ? 'Soal Literasi'
        : recommendation.interventionType === 'soal_numerasi'
        ? 'Soal Numerasi'
        : 'Latihan Soal'
      : undefined);

  return (
    <div
      id="alme-recommends-banner"
      className="relative rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border-2 border-amber-400/80 shadow-2xl shadow-amber-500/10 overflow-hidden"
    >
      {/* Decorative ambient halo */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-60 h-60 bg-pink-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top golden indicator line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-pink-500 to-indigo-500" />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        {/* Left Section: Header & Content */}
        <div className="space-y-3 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider shadow-sm font-mono">
              <Sparkles className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
              ✨ ALME RECOMMENDS
            </span>

            {interventionCategory && (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/40 text-xs font-bold font-mono">
                <span>📚 Sisipan:</span>
                <strong className="text-white">{interventionCategory}</strong>
              </span>
            )}

            <span className="text-xs text-amber-300 font-semibold">
              Misi yang direkomendasikan berdasarkan perkembangan belajarmu.
            </span>
          </div>

          <div>
            <h2 className="text-lg sm:text-xl font-display font-extrabold text-white tracking-tight">
              {title}
            </h2>
            <div className="mt-1.5 p-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300 leading-relaxed space-y-1">
              <div className="text-[11px] font-bold font-mono text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5" />
                Alasan Rekomendasi Adaptif:
              </div>
              <p className="text-slate-200">
                "{reason}"
              </p>
              <div className="text-[10px] text-slate-400 italic pt-1 border-t border-white/10 mt-1">
                * Rekomendasi dihitung otomatis dari riwayat asesmen, penguasaan materi, dan target kompetensi Fase F.
              </div>
            </div>
          </div>
        </div>

        {/* Right Section: Progress & Call to Action */}
        <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end justify-between gap-4 shrink-0 lg:min-w-[260px]">
          {/* Progress & Reward Card */}
          <div className="w-full bg-slate-950/80 p-3.5 rounded-2xl border border-amber-500/30 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-mono text-[11px]">Progress Misi</span>
              <span className="font-mono font-bold text-amber-400">{progressVal}%</span>
            </div>
            {/* Visual Progress Bar */}
            <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-white/10">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-pink-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.max(8, progressVal)}%` }}
              />
            </div>
            <div className="flex items-center justify-between pt-1 text-[11px]">
              <span className="text-slate-400">Reward:</span>
              <span className="font-mono font-bold text-amber-300 flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                +{xpBonus} XP
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="w-full space-y-2">
            <button
              id="btn-alme-banner-start"
              onClick={() => {
                if (recommendedMissionItem) {
                  onOpenMission(recommendedMissionItem.rawMission);
                }
              }}
              className="w-full min-h-[46px] px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-pink-500 hover:from-amber-600 hover:to-pink-600 active:scale-95 text-slate-950 font-display font-extrabold text-xs sm:text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>COBA MISI SEKARANG</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {onOpenIntervention && (
              <button
                type="button"
                onClick={() =>
                  onOpenIntervention(recommendation?.interventionType || 'remedial')
                }
                className="w-full py-2 rounded-xl bg-white/10 hover:bg-white/15 text-amber-300 hover:text-white border border-white/10 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Buka Sisipan Pembelajaran ALME</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

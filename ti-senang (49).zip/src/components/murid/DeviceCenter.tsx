import React, { useState, useEffect, useRef } from 'react';
import {
  Thermometer,
  Sun,
  Droplets,
  Zap,
  Activity,
  Download,
  Users,
  Save,
  CheckCircle2,
  Trash2,
  RefreshCw,
  Share2,
  FolderOpen,
  HelpCircle,
  FileSpreadsheet,
  Plus,
  Radio,
  Clock,
  Sparkles,
  AlertCircle,
  X,
  ExternalLink,
  ArrowRight,
} from 'lucide-react';
import { firebaseRealtime, TI_SENANG_FIREBASE_CONFIG, STUDENT_DRIVE_FOLDER_URL } from '../../services/firebaseRealtime';
import { storage } from '../../services/storage';
import * as XLSX from 'xlsx';

interface DeviceCenterProps {
  studentId: string;
  missionId?: string;
  studentKelompok?: string;
  studentClass?: string;
  onNavigateToMisi2?: (step?: 'COLLECT' | 'OBSERVE' | 'EXPERIMENT') => void;
  onFinishExperiment?: () => void;
}

export interface ExperimentDataRow {
  id: string;
  no: number;
  timestamp: string;
  waktuDetik?: number;
  port1Suhu: number | string;
  port2Cahaya: number | string;
  port3Kelembaban: number | string;
  port4Arus: number | string;
  port5Gerak: number | string;
  catatan: string;
}

export const DeviceCenter: React.FC<DeviceCenterProps> = ({
  studentId,
  missionId = 'msn-cls-xii-1-3',
  studentKelompok,
  studentClass,
  onNavigateToMisi2,
  onFinishExperiment,
}) => {
  // 1. Pemilihan Kelas & Kelompok untuk Sinkronisasi Firebase
  const profile = storage.getStudentProfile(studentId);
  const initialClass = studentClass || profile?.className || 'XII-1';
  const initialKelompok = studentKelompok || profile?.student?.kelompok || 'Kelompok 1';
  const [selectedKelas, setSelectedKelas] = useState<string>(initialClass);
  const [selectedKelompok, setSelectedKelompok] = useState<string>(initialKelompok);

  // Sinkronkan prop dari dashboard jika berubah
  useEffect(() => {
    if (studentKelompok) {
      setSelectedKelompok(studentKelompok);
    }
    if (studentClass) {
      setSelectedKelas(studentClass);
    }
  }, [studentKelompok, studentClass]);

  // Perbarui otomatis jika ada pembaruan kelompok dari guru atau profil
  useEffect(() => {
    const p = storage.getStudentProfile(studentId);
    if (p?.student?.kelompok) {
      setSelectedKelompok(p.student.kelompok);
    }
    if (p?.className) {
      setSelectedKelas(p.className);
    }

    const handleKelompokUpdate = () => {
      const refreshed = storage.getStudentProfile(studentId);
      if (refreshed?.student?.kelompok) {
        setSelectedKelompok(refreshed.student.kelompok);
      }
      if (refreshed?.className) {
        setSelectedKelas(refreshed.className);
      }
    };

    window.addEventListener('tisenang_student_kelompok_updated', handleKelompokUpdate);
    window.addEventListener('tisenang_students_updated', handleKelompokUpdate);
    return () => {
      window.removeEventListener('tisenang_student_kelompok_updated', handleKelompokUpdate);
      window.removeEventListener('tisenang_students_updated', handleKelompokUpdate);
    };
  }, [studentId]);

  // 2. Status Sensor 5 Port (Real-time Firebase)
  // Port 1: Suhu, Port 2: Cahaya, Port 3: Kelembaban Udara, Port 4: Arus, Port 5: Gerak
  const [portsData, setPortsData] = useState<{
    port1Suhu?: number;
    port2Cahaya?: number;
    port3Kelembaban?: number;
    port4Arus?: number;
    port5Gerak?: number | string;
    connectedPorts: {
      port1: boolean;
      port2: boolean;
      port3: boolean;
      port4: boolean;
      port5: boolean;
    };
    timestamp: number;
  }>({
    connectedPorts: {
      port1: false,
      port2: false,
      port3: false,
      port4: false,
      port5: false,
    },
    timestamp: Date.now(),
  });

  // Mode Simulasi Sensor Kit jika hardware offline
  const [isSimulatedKitActive, setIsSimulatedKitActive] = useState<boolean>(false);
  const simulationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Status Koneksi Firebase Realtime
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);
  const [lastFirebaseUpdate, setLastFirebaseUpdate] = useState<Date | null>(null);

  // 3. Tabel Data Eksperimen (Jumlah baris tidak dibatasi)
  const [tableRows, setTableRows] = useState<ExperimentDataRow[]>([]);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  // 4. Modal Data Kelompok dari Firebase
  const [isGroupModalOpen, setIsGroupModalOpen] = useState<boolean>(false);
  const [groupDataLoading, setGroupDataLoading] = useState<boolean>(false);
  const [groupDataResult, setGroupDataResult] = useState<{
    kelas: string;
    kelompok: string;
    updatedAt?: string;
    rows: any[];
  } | null>(null);

  // 5. Status Notifikasi Simpan Misi
  const [saveStatus, setSaveStatus] = useState<{
    type: 'idle' | 'saving' | 'success' | 'error';
    message: string;
  }>({ type: 'idle', message: '' });

  // Sinkronisasi Real-time dengan Database Firebase RTDB
  useEffect(() => {
    const unsub = firebaseRealtime.subscribeSensorData(
      selectedKelas,
      selectedKelompok,
      (data) => {
        if (!isSimulatedKitActive) {
          setPortsData(data);
          setLastFirebaseUpdate(new Date());
          setIsFirebaseConnected(true);
        }
      }
    );

    return () => {
      unsub();
    };
  }, [selectedKelas, selectedKelompok, isSimulatedKitActive]);

  // Handle Mode Simulasi Sensor Kit (fallback ketika hardware fisik di lab belum dinyalakan)
  useEffect(() => {
    if (isSimulatedKitActive) {
      simulationIntervalRef.current = setInterval(() => {
        setPortsData({
          port1Suhu: Number((27.5 + Math.sin(Date.now() / 5000) * 1.8 + Math.random() * 0.4).toFixed(1)),
          port2Cahaya: Math.round(480 + Math.sin(Date.now() / 4000) * 80 + Math.random() * 30),
          port3Kelembaban: Number((68.0 + Math.cos(Date.now() / 7000) * 3 + Math.random() * 0.5).toFixed(1)),
          port4Arus: Number((120.5 + Math.random() * 15).toFixed(1)),
          port5Gerak: Math.random() > 0.4 ? 'Terdeteksi' : 'Stabil (25 cm)',
          connectedPorts: {
            port1: true,
            port2: true,
            port3: true,
            port4: true,
            port5: true,
          },
          timestamp: Date.now(),
        });
        setLastFirebaseUpdate(new Date());
      }, 1500);
    } else {
      if (simulationIntervalRef.current) clearInterval(simulationIntervalRef.current);
    }
    return () => {
      if (simulationIntervalRef.current) clearInterval(simulationIntervalRef.current);
    };
  }, [isSimulatedKitActive]);

  // Timer stopwatch untuk durasi eksperimen
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isTimerRunning) {
      timer = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isTimerRunning]);

  // Memuat data eksperimen yang tersimpan sebelumnya
  useEffect(() => {
    const existing = storage.getStudentExperimentSession(studentId, missionId);
    if (existing && existing.rows && existing.rows.length > 0) {
      const converted: ExperimentDataRow[] = existing.rows.map((r: any, idx: number) => ({
        id: `row-cached-${idx}`,
        no: idx + 1,
        timestamp: r.waktu ? `Detik ke-${r.waktu}` : new Date().toLocaleTimeString(),
        waktuDetik: r.waktu || idx * 10,
        port1Suhu: r.suhuAkhir ?? r.port1Suhu ?? 27.5,
        port2Cahaya: r.cahaya ?? r.port2Cahaya ?? 450,
        port3Kelembaban: r.kelembaban ?? r.port3Kelembaban ?? 65,
        port4Arus: r.arus ?? r.port4Arus ?? 120,
        port5Gerak: r.gerak ?? r.port5Gerak ?? 'Stabil',
        catatan: r.catatan || 'Data tersimpan',
      }));
      setTableRows(converted);
    }
  }, [studentId, missionId]);

  // =========================================================================
  // AKSI 1: AMBIL DATA (Setiap klik, data otomatis masuk ke tabel, tanpa batas)
  // =========================================================================
  const handleAmbilData = () => {
    if (!isTimerRunning) {
      setIsTimerRunning(true);
    }

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(
      now.getSeconds()
    ).padStart(2, '0')}`;

    const newRow: ExperimentDataRow = {
      id: `row-${Date.now()}-${tableRows.length + 1}`,
      no: tableRows.length + 1,
      timestamp: timeStr,
      waktuDetik: timerSeconds,
      port1Suhu: portsData.connectedPorts.port1 && portsData.port1Suhu !== undefined ? portsData.port1Suhu : '-',
      port2Cahaya: portsData.connectedPorts.port2 && portsData.port2Cahaya !== undefined ? portsData.port2Cahaya : '-',
      port3Kelembaban:
        portsData.connectedPorts.port3 && portsData.port3Kelembaban !== undefined ? portsData.port3Kelembaban : '-',
      port4Arus: portsData.connectedPorts.port4 && portsData.port4Arus !== undefined ? portsData.port4Arus : '-',
      port5Gerak: portsData.connectedPorts.port5 && portsData.port5Gerak !== undefined ? portsData.port5Gerak : '-',
      catatan: `Pengambilan ke-${tableRows.length + 1}`,
    };

    setTableRows((prev) => [...prev, newRow]);
  };

  // =========================================================================
  // AKSI 2: DATA KELOMPOK (Mengambil data dari firebase: data - kelas - kelompok - data eksperimen)
  // =========================================================================
  const handleFetchDataKelompok = async () => {
    setIsGroupModalOpen(true);
    setGroupDataLoading(true);
    try {
      const data = await firebaseRealtime.fetchDataKelompok(selectedKelas, selectedKelompok);
      if (data) {
        setGroupDataResult({
          kelas: selectedKelas,
          kelompok: selectedKelompok,
          updatedAt: data.updatedAt,
          rows: Array.isArray(data.rows) ? data.rows : Array.isArray(data) ? data : [],
        });
      } else {
        setGroupDataResult({
          kelas: selectedKelas,
          kelompok: selectedKelompok,
          rows: [],
        });
      }
    } catch (err) {
      console.error('Gagal mengambil data kelompok:', err);
    } finally {
      setGroupDataLoading(false);
    }
  };

  // Salin data kelompok ke tabel murid
  const handleLoadGroupDataToMyTable = () => {
    if (!groupDataResult || !groupDataResult.rows || groupDataResult.rows.length === 0) return;
    const formatted: ExperimentDataRow[] = groupDataResult.rows.map((r: any, idx: number) => ({
      id: `group-row-${idx}-${Date.now()}`,
      no: idx + 1,
      timestamp: r.timestamp || `00:${String(idx * 5).padStart(2, '0')}`,
      port1Suhu: r.port1Suhu ?? r.suhu ?? r.suhu_air ?? '-',
      port2Cahaya: r.port2Cahaya ?? r.cahaya ?? '-',
      port3Kelembaban: r.port3Kelembaban ?? r.kelembaban ?? r.kelembapan ?? '-',
      port4Arus: r.port4Arus ?? r.arus ?? '-',
      port5Gerak: r.port5Gerak ?? r.gerak ?? '-',
      catatan: r.catatan || `Data Kelompok ${selectedKelompok}`,
    }));

    setTableRows(formatted);
    setIsGroupModalOpen(false);
  };

  // Unggah tabel murid ke data kelompok di Firebase
  const handleUploadMyTableToGroup = async () => {
    if (tableRows.length === 0) return;
    try {
      await firebaseRealtime.saveDataKelompok(selectedKelas, selectedKelompok, {
        rows: tableRows,
        metadata: {
          uploadedBy: studentId,
          rowCount: tableRows.length,
          savedAt: new Date().toISOString(),
        },
      });
      alert(`Data eksperimen berhasil dikirim ke Firebase untuk Kelas ${selectedKelas} • ${selectedKelompok}!`);
      handleFetchDataKelompok();
    } catch (err) {
      alert('Gagal mengirim data kelompok ke Firebase.');
    }
  };

  // =========================================================================
  // AKSI 3: SIMPAN KE DATABASE MISI SISWA (Firebase & LocalStorage)
  // =========================================================================
  const handleSaveToMissionDatabase = async () => {
    if (tableRows.length === 0) {
      setSaveStatus({
        type: 'error',
        message: 'Tabel eksperimen masih kosong. Silakan klik tombol "Ambil Data" terlebih dahulu.',
      });
      setTimeout(() => setSaveStatus({ type: 'idle', message: '' }), 3500);
      return;
    }

    setSaveStatus({ type: 'saving', message: 'Menyimpan tabel ke Database Misi Murid & Firebase...' });

    try {
      // 1. Simpan ke Firebase Database Misi Murid
      await firebaseRealtime.saveStudentExperimentData(studentId, missionId, {
        studentName: profile?.student?.name || 'Murid TI SENANG',
        className: selectedKelas,
        kelompok: selectedKelompok,
        rows: tableRows,
        notes: `Tabel eksperimen Kit TI SENANG (${tableRows.length} baris data tercatat)`,
        parameters: {
          kelas: selectedKelas,
          kelompok: selectedKelompok,
          recordedAt: new Date().toISOString(),
        },
      });

      // 2. Simpan juga ke Firebase path data - kelas - kelompok - data eksperimen
      await firebaseRealtime.saveDataKelompok(selectedKelas, selectedKelompok, {
        rows: tableRows,
      });

      // 3. Simpan ke LocalStorage murid & sinkronkan format presisi untuk Misi 2
      const initialSuhu = (() => {
        for (const row of tableRows) {
          const val = typeof row.port1Suhu === 'number' ? row.port1Suhu : parseFloat(String(row.port1Suhu));
          if (!isNaN(val)) return val;
        }
        return 25.0;
      })();

      const rowsForStorage = tableRows.map((r, idx) => {
        const suhuVal = typeof r.port1Suhu === 'number' ? r.port1Suhu : parseFloat(String(r.port1Suhu));
        const finalSuhu = !isNaN(suhuVal) ? suhuVal : initialSuhu;
        const cahayaVal = typeof r.port2Cahaya === 'number' ? r.port2Cahaya : parseFloat(String(r.port2Cahaya));
        const finalCahaya = !isNaN(cahayaVal) ? cahayaVal : 500;
        const waktuVal = r.waktuDetik !== undefined ? r.waktuDetik : idx * 5;
        const deltaT = Number((finalSuhu - initialSuhu).toFixed(1));
        const heatJ = Number((0.2 * 4186 * Math.max(0, deltaT)).toFixed(0));

        return {
          waktu: waktuVal,
          suhuAwal: initialSuhu,
          suhuAkhir: finalSuhu,
          deltaT: deltaT,
          kalorTerukur: heatJ,
          kalorTeoritis: Number((heatJ * 1.05).toFixed(0)),
          efisiensi: 98.5,
          intensitasCahaya: finalCahaya,
          param1: `${waktuVal} dtk`,
          param2: `${finalSuhu} °C`,
          param3: `${finalCahaya} Lux`,
          catatan: r.catatan || `Pengambilan ke-${idx + 1}`,
          rawSource: 'DEVICE_KIT',
          sourceSubject: 'Kit TI SENANG (IoT)',
        };
      });

      const baseSession = {
        experimentId: `exp-${Date.now()}`,
        studentId,
        missionId,
        startedAt: new Date(Date.now() - timerSeconds * 1000).toISOString(),
        completedAt: new Date().toISOString(),
        status: 'COMPLETED' as const,
        source: 'SIMULATION' as const,
        readings: [],
        rows: rowsForStorage as any,
      };

      storage.saveExperimentSession(baseSession);
      // Simpan juga dengan missionId Misi 2 agar langsung ditemukan
      storage.saveExperimentSession({
        ...baseSession,
        missionId: 'msn-cls-xii-1-2',
      });

      // Simpan juga ke localStorage cache
      try {
        localStorage.setItem('tisenang_latest_experiment_rows', JSON.stringify(rowsForStorage));
        localStorage.setItem('tisenang_misi2_active_step', 'COLLECT');
      } catch {
        // ignore
      }

      // 4. Update progres misi siswa menjadi selesai (XP Reward +120)
      storage.completeMission(studentId, missionId, 95, 120);

      // 5. Dispatch events agar komponen Misi 2 langsung menerima data
      window.dispatchEvent(
        new CustomEvent('tisenang_experiment_saved', {
          detail: { rows: rowsForStorage, step: 'COLLECT' },
        })
      );
      window.dispatchEvent(new CustomEvent('tisenang_missions_updated'));

      setSaveStatus({
        type: 'success',
        message: 'Tabel berhasil disimpan ke Database Misi Murid! Mengalihkan ke Misi 2 Tahap 3 (Kumpul Data)...',
      });

      // 6. Otomatis kembali ke Misi 2 Tahap 3 (Kumpul Data)
      setTimeout(() => {
        setSaveStatus({ type: 'idle', message: '' });
        if (onNavigateToMisi2) {
          onNavigateToMisi2('COLLECT');
        }
      }, 700);
    } catch (err) {
      console.error(err);
      setSaveStatus({
        type: 'error',
        message: 'Terjadi kendala saat menyimpan ke database Firebase. Data tetap tersimpan di lokal.',
      });
      setTimeout(() => setSaveStatus({ type: 'idle', message: '' }), 4000);
    }
  };

  // Hapus baris tabel
  const handleDeleteRow = (id: string) => {
    setTableRows((prev) => prev.filter((r) => r.id !== id).map((r, i) => ({ ...r, no: i + 1 })));
  };

  // Reset tabel
  const handleClearTable = () => {
    if (window.confirm('Bersihkan seluruh tabel data eksperimen?')) {
      setTableRows([]);
      setTimerSeconds(0);
      setIsTimerRunning(false);
    }
  };

  // Ekspor Excel (.xlsx) sesuai permintaan (bukan CSV)
  const handleExportExcel = () => {
    if (tableRows.length === 0) return;
    const worksheetData = tableRows.map((r) => ({
      'No': r.no,
      'Waktu Pengamatan': r.timestamp,
      'Port 1 - Suhu Air (°C)': r.port1Suhu,
      'Port 2 - Intensitas Cahaya (Lux)': r.port2Cahaya,
      'Port 3 - Kelembaban Udara (%)': r.port3Kelembaban,
      'Port 4 - Arus Listrik (mA)': r.port4Arus,
      'Port 5 - Sensor Gerak': r.port5Gerak,
      'Catatan Pengamatan': r.catatan || '',
    }));

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Eksperimen');
    XLSX.writeFile(workbook, `Eksperimen_Kit_TISENANG_${selectedKelas}_${selectedKelompok}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header Eksperimen (Kit TI SENANG) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-3xl border border-indigo-500/30 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Data Realtime Aktif</span>
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <span>Eksperimen (Kit TI SENANG)</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Ambil data pengamatan tanpa batas baris, sinkronkan dengan data kelompok, dan simpan langsung ke database misi murid.
            </p>
          </div>

          {/* Pemilih Kelas & Kelompok */}
          <div className="flex flex-wrap items-center gap-2 bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700">
            <div>
              <label className="block text-[9px] font-black uppercase text-slate-400 tracking-wider mb-0.5">
                Kelas
              </label>
              <select
                value={selectedKelas}
                onChange={(e) => setSelectedKelas(e.target.value)}
                className="bg-slate-900 border border-slate-600 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:ring-1 focus:ring-cyan-400"
              >
                <option value="XII-1">Kelas XII-1</option>
                <option value="XII-2">Kelas XII-2</option>
                <option value="XI-1">Kelas XI-1</option>
                <option value="X-1">Kelas X-1</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-black uppercase text-slate-400 tracking-wider mb-0.5">
                Kelompok
              </label>
              <select
                value={selectedKelompok}
                onChange={(e) => setSelectedKelompok(e.target.value)}
                className="bg-slate-900 border border-slate-600 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:ring-1 focus:ring-cyan-400"
              >
                <option value="Kelompok 1">Kelompok 1</option>
                <option value="Kelompok 2">Kelompok 2</option>
                <option value="Kelompok 3">Kelompok 3</option>
                <option value="Kelompok 4">Kelompok 4</option>
                <option value="Kelompok 5">Kelompok 5</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          KOTAK-KOTAK PENAMPIL 5 PORT SENSOR LABORATORIUM
          Aturan:
          - Jika sensor TIDAK terhubung: kotak abu-abu (status tidak terhubung)
          - Jika sensor TERHUBUNG & terbaca data: kotak terlihat aktif (warna cerah, gauge, nilai real-time)
          ========================================================================= */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-black uppercase text-slate-500 dark:text-slate-400 tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-600" />
            <span>Status 5 Port Sensor Kit TI SENANG (Real-Time Database)</span>
          </h2>
          <span className="text-[10px] text-slate-400 font-medium">
            {lastFirebaseUpdate ? `Update: ${lastFirebaseUpdate.toLocaleTimeString()}` : 'Menunggu sinyal...'}
          </span>
        </div>

        <div className="w-full overflow-x-auto pb-1.5 scrollbar-none">
          <div className="grid grid-cols-5 gap-1.5 sm:gap-2.5 md:gap-3 min-w-[340px] sm:min-w-0">
            {/* ----------------- PORT 1: SUHU ----------------- */}
            <div
              id="sensor-box-port1"
              className={`rounded-xl sm:rounded-2xl p-2 sm:p-2.5 md:p-3 transition-all duration-300 border flex flex-col justify-between min-w-0 ${
                portsData.connectedPorts.port1
                  ? 'bg-gradient-to-br from-rose-50 to-orange-50/80 dark:from-rose-950/30 dark:to-orange-950/20 border-rose-300 dark:border-rose-700/60 shadow-xs text-slate-900 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-400 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 truncate">
                  Port 1
                </span>
                <span
                  className={`text-[8px] sm:text-[9px] font-bold px-1.5 py-0.5 rounded-full inline-flex items-center gap-1 shrink-0 ${
                    portsData.connectedPorts.port1
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-700/50'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                  }`}
                  title={portsData.connectedPorts.port1 ? 'Aktif & Terhubung' : 'Sensor Tidak Terhubung'}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${portsData.connectedPorts.port1 ? 'bg-rose-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="hidden md:inline">{portsData.connectedPorts.port1 ? 'Aktif' : 'Off'}</span>
                </span>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 my-0.5 sm:my-1 min-w-0">
                <div
                  className={`w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-lg sm:rounded-xl flex items-center justify-center shrink-0 ${
                    portsData.connectedPorts.port1
                      ? 'bg-rose-500 text-white shadow-xs'
                      : 'bg-slate-300 dark:bg-slate-700 text-slate-500'
                  }`}
                >
                  <Thermometer className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-[10px] sm:text-xs font-black leading-tight truncate">Suhu</h3>
                  <p className="text-[8px] sm:text-[9px] text-slate-500 dark:text-slate-400 leading-tight truncate hidden sm:block">DS18B20</p>
                </div>
              </div>

              <div className="mt-1 pt-1 sm:mt-1.5 sm:pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-baseline justify-between gap-1 min-w-0">
                <div className="text-xs sm:text-sm md:text-base lg:text-lg font-black tracking-tight truncate">
                  {portsData.connectedPorts.port1 && portsData.port1Suhu !== undefined ? (
                    <span>
                      {portsData.port1Suhu}
                      <span className="text-[9px] sm:text-[11px] font-bold text-rose-600 dark:text-rose-400 ml-0.5">°C</span>
                    </span>
                  ) : (
                    <span className="text-slate-400 font-bold">--</span>
                  )}
                </div>
                <span className="text-[7px] sm:text-[8px] md:text-[9px] font-bold text-slate-400 truncate hidden md:inline">
                  Termal
                </span>
              </div>
            </div>

            {/* ----------------- PORT 2: CAHAYA ----------------- */}
            <div
              id="sensor-box-port2"
              className={`rounded-xl sm:rounded-2xl p-2 sm:p-2.5 md:p-3 transition-all duration-300 border flex flex-col justify-between min-w-0 ${
                portsData.connectedPorts.port2
                  ? 'bg-gradient-to-br from-amber-50 to-yellow-50/80 dark:from-amber-950/30 dark:to-yellow-950/20 border-amber-300 dark:border-amber-700/60 shadow-xs text-slate-900 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-400 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 truncate">
                  Port 2
                </span>
                <span
                  className={`text-[8px] sm:text-[9px] font-bold px-1.5 py-0.5 rounded-full inline-flex items-center gap-1 shrink-0 ${
                    portsData.connectedPorts.port2
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-700/50'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                  }`}
                  title={portsData.connectedPorts.port2 ? 'Aktif & Terhubung' : 'Sensor Tidak Terhubung'}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${portsData.connectedPorts.port2 ? 'bg-amber-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="hidden md:inline">{portsData.connectedPorts.port2 ? 'Aktif' : 'Off'}</span>
                </span>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 my-0.5 sm:my-1 min-w-0">
                <div
                  className={`w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-lg sm:rounded-xl flex items-center justify-center shrink-0 ${
                    portsData.connectedPorts.port2
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'bg-slate-300 dark:bg-slate-700 text-slate-500'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-[10px] sm:text-xs font-black leading-tight truncate">Cahaya</h3>
                  <p className="text-[8px] sm:text-[9px] text-slate-500 dark:text-slate-400 leading-tight truncate hidden sm:block">BH1750</p>
                </div>
              </div>

              <div className="mt-1 pt-1 sm:mt-1.5 sm:pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-baseline justify-between gap-1 min-w-0">
                <div className="text-xs sm:text-sm md:text-base lg:text-lg font-black tracking-tight truncate">
                  {portsData.connectedPorts.port2 && portsData.port2Cahaya !== undefined ? (
                    <span>
                      {portsData.port2Cahaya}
                      <span className="text-[9px] sm:text-[11px] font-bold text-amber-600 dark:text-amber-400 ml-0.5">Lux</span>
                    </span>
                  ) : (
                    <span className="text-slate-400 font-bold">--</span>
                  )}
                </div>
                <span className="text-[7px] sm:text-[8px] md:text-[9px] font-bold text-slate-400 truncate hidden md:inline">
                  Intensitas
                </span>
              </div>
            </div>

            {/* ----------------- PORT 3: KELEMBABAN UDARA ----------------- */}
            <div
              id="sensor-box-port3"
              className={`rounded-xl sm:rounded-2xl p-2 sm:p-2.5 md:p-3 transition-all duration-300 border flex flex-col justify-between min-w-0 ${
                portsData.connectedPorts.port3
                  ? 'bg-gradient-to-br from-cyan-50 to-blue-50/80 dark:from-cyan-950/30 dark:to-blue-950/20 border-cyan-300 dark:border-cyan-700/60 shadow-xs text-slate-900 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-400 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 truncate">
                  Port 3
                </span>
                <span
                  className={`text-[8px] sm:text-[9px] font-bold px-1.5 py-0.5 rounded-full inline-flex items-center gap-1 shrink-0 ${
                    portsData.connectedPorts.port3
                      ? 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300 border border-cyan-300 dark:border-cyan-700/50'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                  }`}
                  title={portsData.connectedPorts.port3 ? 'Aktif & Terhubung' : 'Sensor Tidak Terhubung'}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${portsData.connectedPorts.port3 ? 'bg-cyan-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="hidden md:inline">{portsData.connectedPorts.port3 ? 'Aktif' : 'Off'}</span>
                </span>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 my-0.5 sm:my-1 min-w-0">
                <div
                  className={`w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-lg sm:rounded-xl flex items-center justify-center shrink-0 ${
                    portsData.connectedPorts.port3
                      ? 'bg-cyan-600 text-white shadow-xs'
                      : 'bg-slate-300 dark:bg-slate-700 text-slate-500'
                  }`}
                >
                  <Droplets className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-[10px] sm:text-xs font-black leading-tight truncate">Lembab</h3>
                  <p className="text-[8px] sm:text-[9px] text-slate-500 dark:text-slate-400 leading-tight truncate hidden sm:block">DHT22</p>
                </div>
              </div>

              <div className="mt-1 pt-1 sm:mt-1.5 sm:pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-baseline justify-between gap-1 min-w-0">
                <div className="text-xs sm:text-sm md:text-base lg:text-lg font-black tracking-tight truncate">
                  {portsData.connectedPorts.port3 && portsData.port3Kelembaban !== undefined ? (
                    <span>
                      {portsData.port3Kelembaban}
                      <span className="text-[9px] sm:text-[11px] font-bold text-cyan-600 dark:text-cyan-400 ml-0.5">%</span>
                    </span>
                  ) : (
                    <span className="text-slate-400 font-bold">--</span>
                  )}
                </div>
                <span className="text-[7px] sm:text-[8px] md:text-[9px] font-bold text-slate-400 truncate hidden md:inline">
                  Udara
                </span>
              </div>
            </div>

            {/* ----------------- PORT 4: ARUS ----------------- */}
            <div
              id="sensor-box-port4"
              className={`rounded-xl sm:rounded-2xl p-2 sm:p-2.5 md:p-3 transition-all duration-300 border flex flex-col justify-between min-w-0 ${
                portsData.connectedPorts.port4
                  ? 'bg-gradient-to-br from-indigo-50 to-purple-50/80 dark:from-indigo-950/30 dark:to-purple-950/20 border-indigo-300 dark:border-indigo-700/60 shadow-xs text-slate-900 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-400 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 truncate">
                  Port 4
                </span>
                <span
                  className={`text-[8px] sm:text-[9px] font-bold px-1.5 py-0.5 rounded-full inline-flex items-center gap-1 shrink-0 ${
                    portsData.connectedPorts.port4
                      ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-700/50'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                  }`}
                  title={portsData.connectedPorts.port4 ? 'Aktif & Terhubung' : 'Sensor Tidak Terhubung'}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${portsData.connectedPorts.port4 ? 'bg-indigo-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="hidden md:inline">{portsData.connectedPorts.port4 ? 'Aktif' : 'Off'}</span>
                </span>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 my-0.5 sm:my-1 min-w-0">
                <div
                  className={`w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-lg sm:rounded-xl flex items-center justify-center shrink-0 ${
                    portsData.connectedPorts.port4
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-300 dark:bg-slate-700 text-slate-500'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-[10px] sm:text-xs font-black leading-tight truncate">Arus</h3>
                  <p className="text-[8px] sm:text-[9px] text-slate-500 dark:text-slate-400 leading-tight truncate hidden sm:block">INA219</p>
                </div>
              </div>

              <div className="mt-1 pt-1 sm:mt-1.5 sm:pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-baseline justify-between gap-1 min-w-0">
                <div className="text-xs sm:text-sm md:text-base lg:text-lg font-black tracking-tight truncate">
                  {portsData.connectedPorts.port4 && portsData.port4Arus !== undefined ? (
                    <span>
                      {portsData.port4Arus}
                      <span className="text-[9px] sm:text-[11px] font-bold text-indigo-600 dark:text-indigo-400 ml-0.5">mA</span>
                    </span>
                  ) : (
                    <span className="text-slate-400 font-bold">--</span>
                  )}
                </div>
                <span className="text-[7px] sm:text-[8px] md:text-[9px] font-bold text-slate-400 truncate hidden md:inline">
                  Listrik
                </span>
              </div>
            </div>

            {/* ----------------- PORT 5: GERAK ----------------- */}
            <div
              id="sensor-box-port5"
              className={`rounded-xl sm:rounded-2xl p-2 sm:p-2.5 md:p-3 transition-all duration-300 border flex flex-col justify-between min-w-0 ${
                portsData.connectedPorts.port5
                  ? 'bg-gradient-to-br from-emerald-50 to-teal-50/80 dark:from-emerald-950/30 dark:to-teal-950/20 border-emerald-300 dark:border-emerald-700/60 shadow-xs text-slate-900 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700 text-slate-400 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 truncate">
                  Port 5
                </span>
                <span
                  className={`text-[8px] sm:text-[9px] font-bold px-1.5 py-0.5 rounded-full inline-flex items-center gap-1 shrink-0 ${
                    portsData.connectedPorts.port5
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/50'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                  }`}
                  title={portsData.connectedPorts.port5 ? 'Aktif & Terhubung' : 'Sensor Tidak Terhubung'}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${portsData.connectedPorts.port5 ? 'bg-emerald-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="hidden md:inline">{portsData.connectedPorts.port5 ? 'Aktif' : 'Off'}</span>
                </span>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 my-0.5 sm:my-1 min-w-0">
                <div
                  className={`w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-lg sm:rounded-xl flex items-center justify-center shrink-0 ${
                    portsData.connectedPorts.port5
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-300 dark:bg-slate-700 text-slate-500'
                  }`}
                >
                  <Activity className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-[10px] sm:text-xs font-black leading-tight truncate">Gerak</h3>
                  <p className="text-[8px] sm:text-[9px] text-slate-500 dark:text-slate-400 leading-tight truncate hidden sm:block">PIR</p>
                </div>
              </div>

              <div className="mt-1 pt-1 sm:mt-1.5 sm:pt-1.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-baseline justify-between gap-1 min-w-0">
                <div className="text-xs sm:text-sm md:text-base lg:text-lg font-black tracking-tight truncate">
                  {portsData.connectedPorts.port5 && portsData.port5Gerak !== undefined ? (
                    <span className="text-emerald-700 dark:text-emerald-400">{portsData.port5Gerak}</span>
                  ) : (
                    <span className="text-slate-400 font-bold">--</span>
                  )}
                </div>
                <span className="text-[7px] sm:text-[8px] md:text-[9px] font-bold text-slate-400 truncate hidden md:inline">
                  Gerak
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          KONTROL UTAMA:
          1. TOMBOL "AMBIL DATA" (Di bawah kotak-kotak sensor)
          2. TOMBOL "DATA KELOMPOK" (Di bawah tombol "Ambil Data")
          3. TOMBOL "SIMPAN KE DATABASE MISI SISWA"
          ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Download className="w-4 h-4 text-indigo-600" />
              <span>Pencatatan & Pengumpulan Data Laboratorium</span>
            </h3>
            <p className="text-xs text-slate-500">
              Setiap kali tombol <span className="font-bold text-indigo-600">"Ambil Data"</span> diklik, pembacaan 5 port sensor otomatis tercatat ke baris tabel tanpa batas.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500">
              Baris Tercatat: <strong className="text-indigo-600 text-sm">{tableRows.length}</strong>
            </span>
            {timerSeconds > 0 && (
              <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-mono font-bold text-slate-600 dark:text-slate-300">
                ⏱ {Math.floor(timerSeconds / 60)}m {timerSeconds % 60}s
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons Column */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-1">
          {/* TOMBOL 1: AMBIL DATA (Besar dan Menonjol) */}
          <button
            id="btn-ambil-data-sensor"
            onClick={handleAmbilData}
            className="flex-1 sm:flex-initial px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm shadow-lg shadow-indigo-500/25 active:scale-98 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Ambil Data</span>
          </button>

          {/* TOMBOL 2: DATA KELOMPOK (Mengambil data firebase: data - kelas - kelompok - data eksperimen) */}
          <button
            id="btn-data-kelompok-firebase"
            onClick={handleFetchDataKelompok}
            className="flex-1 sm:flex-initial px-5 py-3 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-black text-xs sm:text-sm shadow-xs active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Users className="w-4 h-4 text-amber-700" />
            <span>Data Kelompok ({selectedKelompok})</span>
          </button>

          {/* TOMBOL 3: SIMPAN KE DATABASE MISI MURID */}
          <button
            id="btn-simpan-database-misi"
            onClick={handleSaveToMissionDatabase}
            className="flex-1 sm:flex-initial px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm shadow-md shadow-emerald-600/20 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Simpan ke Database Misi Murid</span>
          </button>

          {/* Action secondary (Export & Clear) */}
          <div className="flex items-center gap-2 ml-auto">
            {tableRows.length > 0 && (
              <>
                <button
                  id="btn-download-excel"
                  onClick={handleExportExcel}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition-all active:scale-95"
                  title="Download data eksperimen dalam format Microsoft Excel (.xlsx)"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Download Excel (.xlsx)</span>
                </button>
                <button
                  onClick={handleClearTable}
                  className="p-2.5 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-bold flex items-center gap-1.5"
                  title="Bersihkan tabel"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Reset</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Save Status Notification */}
        {saveStatus.message && (
          <div
            className={`p-3 rounded-2xl text-xs font-bold flex items-center justify-between gap-2 animate-fade-in ${
              saveStatus.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                : saveStatus.type === 'error'
                ? 'bg-rose-50 text-rose-800 border border-rose-300'
                : 'bg-blue-50 text-blue-800 border border-blue-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {saveStatus.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              ) : (
                <AlertCircle className="w-4 h-4" />
              )}
              <span>{saveStatus.message}</span>
            </div>
            {saveStatus.type === 'success' && (
              <a
                href={STUDENT_DRIVE_FOLDER_URL}
                target="_blank"
                rel="noreferrer"
                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-bold hover:bg-emerald-700 flex items-center gap-1"
              >
                <span>Buka Google Drive</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        )}
      </div>

      {/* =========================================================================
          TABEL DATA EKSPERIMEN (Jumlah Baris Tidak Dibatasi)
          ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-indigo-600"></div>
            <h3 className="text-sm font-black text-slate-800 dark:text-white">
              Tabel Pengamatan Sensor (Kit TI SENANG)
            </h3>
            <span className="text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 px-2 py-0.5 rounded-md">
              {tableRows.length} data tercatat (tanpa batas)
            </span>
          </div>
          <span className="text-xs text-slate-400">
            Kelas: <strong>{selectedKelas}</strong> • Kelompok: <strong>{selectedKelompok}</strong>
          </span>
        </div>

        {tableRows.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center mx-auto">
              <Download className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-black text-slate-700 dark:text-slate-300">
              Belum ada baris data eksperimen
            </h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
              Hubungkan sensor ke Kit TI SENANG atau aktifkan mode simulasi, lalu klik tombol{' '}
              <strong className="text-indigo-600">"Ambil Data"</strong> untuk mulai mencatat pengamatan praktikum.
            </p>
            <div className="pt-1">
              <button
                onClick={handleAmbilData}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs shadow-xs hover:bg-indigo-700 cursor-pointer"
              >
                + Ambil Data Pertama
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[480px] overflow-y-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 bg-slate-50 dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 text-[11px] font-black uppercase tracking-wider border-b border-slate-200 dark:border-slate-700 z-10">
                <tr>
                  <th className="py-3 px-3.5 w-12 text-center">No</th>
                  <th className="py-3 px-3.5">Waktu</th>
                  <th className="py-3 px-3.5 bg-rose-50/50 dark:bg-rose-950/20 text-rose-700">Port 1 (Suhu °C)</th>
                  <th className="py-3 px-3.5 bg-amber-50/50 dark:bg-amber-950/20 text-amber-800">Port 2 (Cahaya Lux)</th>
                  <th className="py-3 px-3.5 bg-cyan-50/50 dark:bg-cyan-950/20 text-cyan-800">Port 3 (Kelembaban %)</th>
                  <th className="py-3 px-3.5 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-800">Port 4 (Arus mA)</th>
                  <th className="py-3 px-3.5 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-800">Port 5 (Gerak)</th>
                  <th className="py-3 px-3.5">Kondisi / Catatan</th>
                  <th className="py-3 px-3.5 text-center w-12">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {tableRows.map((row) => (
                  <tr
                    key={row.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors font-medium text-slate-800 dark:text-slate-200"
                  >
                    <td className="py-2.5 px-3.5 text-center font-bold text-slate-400">
                      {row.no}
                    </td>
                    <td className="py-2.5 px-3.5 font-mono text-[11px]">
                      {row.timestamp}
                    </td>
                    <td className="py-2.5 px-3.5 font-bold font-mono bg-rose-50/30 text-rose-600">
                      {row.port1Suhu}
                    </td>
                    <td className="py-2.5 px-3.5 font-bold font-mono bg-amber-50/30 text-amber-700">
                      {row.port2Cahaya}
                    </td>
                    <td className="py-2.5 px-3.5 font-bold font-mono bg-cyan-50/30 text-cyan-700">
                      {row.port3Kelembaban}
                    </td>
                    <td className="py-2.5 px-3.5 font-bold font-mono bg-indigo-50/30 text-indigo-700">
                      {row.port4Arus}
                    </td>
                    <td className="py-2.5 px-3.5 font-bold bg-emerald-50/30 text-emerald-700">
                      {row.port5Gerak}
                    </td>
                    <td className="py-2.5 px-3.5">
                      <input
                        type="text"
                        value={row.catatan}
                        onChange={(e) => {
                          const val = e.target.value;
                          setTableRows((prev) =>
                            prev.map((r) => (r.id === row.id ? { ...r, catatan: val } : r))
                          );
                        }}
                        className="w-full px-2 py-1 text-[11px] rounded-lg border border-transparent hover:border-slate-300 focus:border-indigo-400 bg-transparent focus:bg-white"
                        placeholder="Tulis catatan kondisi..."
                      />
                    </td>
                    <td className="py-2.5 px-3.5 text-center">
                      <button
                        onClick={() => handleDeleteRow(row.id)}
                        className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                        title="Hapus baris ini"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Tombol Selesai Eksperimen -> Otomatis Lanjut ke Misi 4 */}
      {onFinishExperiment && (
        <div className="flex justify-end pt-2">
          <button
            id="btn-selesai-eksperimen-kit"
            type="button"
            onClick={onFinishExperiment}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 text-white font-black text-xs sm:text-sm shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>Selesai Eksperimen</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* =========================================================================
          MODAL "DATA KELOMPOK" (Firebase: data - kelas - kelompok - data eksperimen)
          ========================================================================= */}
      {isGroupModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-in">
            {/* Header Modal */}
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-amber-500/10 to-orange-500/10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white">
                    Data Eksperimen Kelompok (Firebase RTDB)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Path Database:{' '}
                    <code className="font-mono text-[11px] text-amber-700 bg-amber-100/60 px-1.5 py-0.5 rounded">
                      data / {selectedKelas.toLowerCase().replace(/[^a-z0-9_]/g, '_')} / {selectedKelompok.toLowerCase().replace(/[^a-z0-9_]/g, '_')} / data_eksperimen
                    </code>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsGroupModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Isi Modal */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              {groupDataLoading ? (
                <div className="py-12 text-center space-y-2">
                  <RefreshCw className="w-6 h-6 text-amber-600 animate-spin mx-auto" />
                  <p className="text-xs font-bold text-slate-600">
                    Mengambil data eksperimen kelompok dari Firebase...
                  </p>
                </div>
              ) : groupDataResult && groupDataResult.rows && groupDataResult.rows.length > 0 ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-bold">
                      Ditemukan <strong className="text-amber-700">{groupDataResult.rows.length}</strong> baris data eksperimen dari kelompok ini.
                    </span>
                    {groupDataResult.updatedAt && (
                      <span className="text-[10px] text-slate-400">
                        Update: {new Date(groupDataResult.updatedAt).toLocaleString()}
                      </span>
                    )}
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-slate-200 max-h-60">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 font-bold text-slate-700 text-[10px] uppercase">
                        <tr>
                          <th className="p-2">No</th>
                          <th className="p-2">Waktu</th>
                          <th className="p-2">Port 1 (Suhu)</th>
                          <th className="p-2">Port 2 (Cahaya)</th>
                          <th className="p-2">Port 3 (Kelembaban)</th>
                          <th className="p-2">Port 4 (Arus)</th>
                          <th className="p-2">Port 5 (Gerak)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {groupDataResult.rows.map((r: any, i: number) => (
                          <tr key={i} className="hover:bg-amber-50/50">
                            <td className="p-2 text-slate-400">{i + 1}</td>
                            <td className="p-2 font-mono text-[11px]">{r.timestamp || `00:${i * 5}`}</td>
                            <td className="p-2 font-bold text-rose-600">{r.port1Suhu ?? r.suhu ?? r.suhu_air ?? '-'}</td>
                            <td className="p-2 font-bold text-amber-700">{r.port2Cahaya ?? r.cahaya ?? '-'}</td>
                            <td className="p-2 font-bold text-cyan-700">{r.port3Kelembaban ?? r.kelembaban ?? '-'}</td>
                            <td className="p-2 font-bold text-indigo-700">{r.port4Arus ?? r.arus ?? '-'}</td>
                            <td className="p-2 font-bold text-emerald-700">{r.port5Gerak ?? r.gerak ?? '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center space-y-2 bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-6">
                  <AlertCircle className="w-8 h-8 text-amber-500 mx-auto" />
                  <h4 className="text-sm font-bold text-slate-800">
                    Belum ada data eksperimen tersimpan untuk {selectedKelompok}
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Kelompok ini belum mengunggah tabel ke Firebase. Kamu bisa mengirim tabel pengamatanmu saat ini agar dapat diakses oleh seluruh anggota kelompok.
                  </p>
                </div>
              )}
            </div>

            {/* Footer Modal */}
            <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {groupDataResult && groupDataResult.rows && groupDataResult.rows.length > 0 && (
                  <button
                    onClick={handleLoadGroupDataToMyTable}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Salin ke Tabel Saya</span>
                  </button>
                )}

                {tableRows.length > 0 && (
                  <button
                    onClick={handleUploadMyTableToGroup}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Kirim Tabel Saya ke Kelompok (Firebase)</span>
                  </button>
                )}
              </div>

              <button
                onClick={() => setIsGroupModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 font-bold text-xs text-slate-600 hover:bg-slate-200"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

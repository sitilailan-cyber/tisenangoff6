import React, { useState, useMemo } from 'react';
import {
  LineChart as LineChartIcon,
  RotateCcw,
  Sparkles,
  Calculator,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';

interface RowData {
  no: number;
  x: string;
  y: string;
}

interface LaboratoriumRegresiLinearProps {
  onRecordData?: (row: {
    param1: string;
    param2: string;
    param3: string;
    catatan: string;
  }) => void;
  onCopyTable?: (rows: Array<{
    param1: string;
    param2: string;
    param3: string;
    catatan: string;
  }>) => void;
}

// 10 Baris Default Awal yang bisa diedit langsung oleh siswa
const INITIAL_ROWS: RowData[] = [
  { no: 1, x: '10', y: '25' },
  { no: 2, x: '20', y: '35' },
  { no: 3, x: '30', y: '42' },
  { no: 4, x: '40', y: '52' },
  { no: 5, x: '50', y: '60' },
  { no: 6, x: '60', y: '71' },
  { no: 7, x: '70', y: '79' },
  { no: 8, x: '80', y: '88' },
  { no: 9, x: '', y: '' },
  { no: 10, x: '', y: '' },
];

export const LaboratoriumRegresiLinear: React.FC<LaboratoriumRegresiLinearProps> = ({
  onRecordData,
  onCopyTable,
}) => {
  // 10 Baris Tabel yang diisi sendiri oleh siswa
  const [rows, setRows] = useState<RowData[]>(INITIAL_ROWS);

  // Status apakah tombol "Buat Garis Regresi" sudah diklik
  const [hasRegressionLine, setHasRegressionLine] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [copySuccess, setCopySuccess] = useState<boolean>(false);

  // Update nilai X atau Y pada baris tertentu
  const handleInputChange = (no: number, field: 'x' | 'y', value: string) => {
    setRows((prev) =>
      prev.map((row) => (row.no === no ? { ...row, [field]: value } : row))
    );
    setErrorMessage('');
  };

  // Kosongkan seluruh tabel 10 baris
  const handleClearAll = () => {
    setRows(
      Array.from({ length: 10 }, (_, i) => ({
        no: i + 1,
        x: '',
        y: '',
      }))
    );
    setHasRegressionLine(false);
    setErrorMessage('');
  };

  // Muat contoh data 10 baris
  const handleLoadSample = () => {
    setRows(INITIAL_ROWS);
    setHasRegressionLine(false);
    setErrorMessage('');
  };

  // Ambil hanya titik yang valid (X dan Y berupa angka)
  const validPoints = useMemo(() => {
    return rows
      .map((r) => {
        const xNum = parseFloat(r.x);
        const yNum = parseFloat(r.y);
        if (!isNaN(xNum) && !isNaN(yNum)) {
          return { no: r.no, x: xNum, y: yNum };
        }
        return null;
      })
      .filter((p): p is { no: number; x: number; y: number } => p !== null);
  }, [rows]);

  // Skala Kanvas SVG Adaptif
  const { maxX, maxY } = useMemo(() => {
    let max_x = 100;
    let max_y = 100;
    validPoints.forEach((p) => {
      if (p.x > max_x) max_x = Math.ceil(p.x / 10) * 10;
      if (p.y > max_y) max_y = Math.ceil(p.y / 10) * 10;
    });
    return { maxX: max_x, maxY: max_y };
  }, [validPoints]);

  // Perhitungan Statistik Regresi Linear (OLS)
  const stats = useMemo(() => {
    const n = validPoints.length;
    if (n < 2) {
      return {
        n,
        m: 0,
        c: 0,
        r: 0,
        r2: 0,
      };
    }

    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumX2 = 0;
    let sumY2 = 0;

    validPoints.forEach((p) => {
      sumX += p.x;
      sumY += p.y;
      sumXY += p.x * p.y;
      sumX2 += p.x * p.x;
      sumY2 += p.y * p.y;
    });

    const denomM = n * sumX2 - sumX * sumX;
    const m = denomM !== 0 ? (n * sumXY - sumX * sumY) / denomM : 0;
    const c = (sumY - m * sumX) / n;

    // Pearson r
    const numR = n * sumXY - sumX * sumY;
    const denomR = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
    const r = denomR !== 0 ? numR / denomR : 0;
    const r2 = r * r;

    return {
      n,
      m: Number(m.toFixed(3)),
      c: Number(c.toFixed(2)),
      r: Number(r.toFixed(4)),
      r2: Number(r2.toFixed(4)),
    };
  }, [validPoints]);

  // Kategori & Interpretasi Hubungan Dua Data berdasarkan Korelasi (r)
  const hubunganKorelasi = useMemo(() => {
    const r = stats.r;
    if (r >= 0.8) {
      return {
        label: 'Positif Sangat Kuat',
        badgeClass: 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300',
        textClass: 'text-emerald-600 dark:text-emerald-400',
        arah: 'searah',
        deskripsi: 'Terdapat hubungan positif yang sangat kuat antara data variabel X dan variabel Y. Kenaikan nilai variabel X diikuti oleh kenaikan nilai variabel Y secara sangat konsisten dan rapat terhadap garis regresi.',
      };
    }
    if (r >= 0.6) {
      return {
        label: 'Positif Kuat',
        badgeClass: 'bg-blue-100 dark:bg-blue-950/60 border-blue-300 dark:border-blue-700 text-blue-800 dark:text-blue-300',
        textClass: 'text-blue-600 dark:text-blue-400',
        arah: 'searah',
        deskripsi: 'Terdapat hubungan positif yang kuat antara kedua data (variabel X dan variabel Y). Ketika nilai X meningkat, nilai Y terbukti meningkat secara signifikan.',
      };
    }
    if (r >= 0.4) {
      return {
        label: 'Positif Sedang (Moderat)',
        badgeClass: 'bg-cyan-100 dark:bg-cyan-950/60 border-cyan-300 dark:border-cyan-700 text-cyan-800 dark:text-cyan-300',
        textClass: 'text-cyan-600 dark:text-cyan-400',
        arah: 'searah',
        deskripsi: 'Terdapat hubungan positif sedang (moderat) antara kedua data. Kenaikan nilai X cenderung diikuti kenaikan nilai Y, meskipun ada sebaran variasi pada sebagian titik data.',
      };
    }
    if (r > 0) {
      return {
        label: 'Positif Lemah',
        badgeClass: 'bg-amber-100 dark:bg-amber-950/60 border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300',
        textClass: 'text-amber-600 dark:text-amber-400',
        arah: 'searah',
        deskripsi: 'Hubungan antara kedua data bersifat positif lemah. Kenaikan variabel X hanya sedikit berbanding lurus dengan variabel Y dan sebaran data cukup acak.',
      };
    }
    if (r === 0) {
      return {
        label: 'Tidak Ada Hubungan Linier',
        badgeClass: 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300',
        textClass: 'text-slate-600 dark:text-slate-400',
        arah: 'tidak berpola',
        deskripsi: 'Tidak ditemukan pola hubungan linier yang teratur antara kedua data variabel X dan Y.',
      };
    }
    if (r > -0.4) {
      return {
        label: 'Negatif Lemah',
        badgeClass: 'bg-amber-100 dark:bg-amber-950/60 border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300',
        textClass: 'text-amber-600 dark:text-amber-400',
        arah: 'berlawanan arah',
        deskripsi: 'Terdapat hubungan negatif lemah antara kedua data. Kenaikan variabel X cenderung diiringi sedikit penurunan pada variabel Y.',
      };
    }
    if (r > -0.6) {
      return {
        label: 'Negatif Sedang (Moderat)',
        badgeClass: 'bg-orange-100 dark:bg-orange-950/60 border-orange-300 dark:border-orange-700 text-orange-800 dark:text-orange-300',
        textClass: 'text-orange-600 dark:text-orange-400',
        arah: 'berlawanan arah',
        deskripsi: 'Terdapat hubungan negatif sedang (moderat) antara kedua data. Kenaikan nilai variabel X cenderung menurunkan nilai variabel Y.',
      };
    }
    if (r > -0.8) {
      return {
        label: 'Negatif Kuat',
        badgeClass: 'bg-rose-100 dark:bg-rose-950/60 border-rose-300 dark:border-rose-700 text-rose-800 dark:text-rose-300',
        textClass: 'text-rose-600 dark:text-rose-400',
        arah: 'berlawanan arah',
        deskripsi: 'Terdapat hubungan negatif yang kuat antara kedua data. Semakin tinggi nilai variabel X, maka nilai variabel Y terbukti menurun secara signifikan.',
      };
    }
    return {
      label: 'Negatif Sangat Kuat',
      badgeClass: 'bg-rose-100 dark:bg-rose-950/60 border-rose-300 dark:border-rose-700 text-rose-800 dark:text-rose-300',
      textClass: 'text-rose-600 dark:text-rose-400',
      arah: 'berlawanan arah',
      deskripsi: 'Terdapat hubungan negatif yang sangat kuat antara kedua data. Semakin tinggi nilai variabel X, maka nilai variabel Y menurun secara konsisten dan hampir sempurna.',
    };
  }, [stats.r]);

  // Tombol "Buat Garis Regresi"
  const handleGenerateRegression = () => {
    if (validPoints.length < 2) {
      setErrorMessage(
        '⚠️ Silakan isi minimal 2 pasang data (X dan Y) pada tabel 10 baris di bawah untuk dapat membuat garis regresi.'
      );
      setHasRegressionLine(false);
      return;
    }
    setErrorMessage('');
    setHasRegressionLine(true);
  };

  // Salin seluruh baris tabel input data siswa (yang terisi) ke tabel data pengamatan
  const handleCopyInputToObservationTable = () => {
    if (validPoints.length === 0) {
      setErrorMessage(
        '⚠️ Silakan isi data (nilai X dan Y) pada tabel 10 baris terlebih dahulu sebelum menyalin ke tabel data pengamatan.'
      );
      return;
    }

    const rowsToCopy = validPoints.map((pt) => {
      const yPred = hasRegressionLine ? Number((stats.m * pt.x + stats.c).toFixed(2)) : null;
      const residual = hasRegressionLine && yPred !== null ? Number((pt.y - yPred).toFixed(2)) : null;

      return {
        param1: String(pt.x),
        param2: String(pt.y),
        param3: hasRegressionLine && yPred !== null ? `ŷ = ${yPred}` : '-',
        catatan:
          hasRegressionLine && residual !== null
            ? `Residual e = ${residual} | Model: ŷ = ${stats.m}x + ${stats.c} (${hubunganKorelasi.label})`
            : `Data Input Siswa Baris ${pt.no}`,
      };
    });

    if (onCopyTable) {
      onCopyTable(rowsToCopy);
    } else if (onRecordData) {
      rowsToCopy.forEach((r) => onRecordData(r));
    }

    setCopySuccess(true);
    setErrorMessage('');
    setTimeout(() => setCopySuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header Panel */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 text-[10px] font-black uppercase tracking-wider">
              Simulasi Matematika
            </span>
            <span className="text-[11px] font-bold text-slate-400">
              {validPoints.length} dari 10 Titik Terisi
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
            <LineChartIcon className="w-5 h-5 text-blue-600 shrink-0" />
            <span>Simulasi Regresi Linear & Diagram Pencar</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Isi pasangan data (X, Y) pada tabel 10 baris. Titik akan otomatis muncul di diagram pencar, lalu klik tombol <strong>"Buat Garis Regresi"</strong> untuk memunculkan garis dan hasil analisis.
          </p>
        </div>

        {/* Tombol Salin Tabel Input Data ke Tabel Data Pengamatan */}
        <button
          id="btn-salin-tabel-ke-pengamatan"
          onClick={handleCopyInputToObservationTable}
          className={`px-4 py-2.5 rounded-xl font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all active:scale-95 shrink-0 ${
            copySuccess
              ? 'bg-emerald-600 text-white shadow-emerald-500/20'
              : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/20'
          }`}
          title="Salin semua pasangan data yang diinput ke tabel data pengamatan di bawah"
        >
          {copySuccess ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
          ) : (
            <FileSpreadsheet className="w-4 h-4 shrink-0" />
          )}
          <span>
            {copySuccess
              ? '✓ Berhasil Disalin ke Tabel Pengamatan'
              : 'salin tabel input data ke tabel data pengamatan'}
          </span>
        </button>
      </div>

      {/* Pesan Kesalahan / Validasi */}
      {errorMessage && (
        <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* =========================================================================
          BAGIAN ATAS: TABEL DI KIRI LAYAR & GRAFIK DI KANAN LAYAR
          Perkecil tabel di kiri, grafik di kanan, fleksibel di Laptop, Tab, Handphone
          ========================================================================= */}
      <div className="flex flex-row items-stretch gap-2 sm:gap-3.5 md:gap-4 lg:gap-5 w-full">
        {/* =========================================================================
            KIRI: TABEL 10 BARIS INPUT SISWA (DIPERKECIL SECARA PROPORSIONAL)
            ========================================================================= */}
        <div className="w-[36%] min-w-[130px] max-w-[260px] sm:w-[30%] md:w-[26%] lg:w-[24%] shrink-0 bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-2 sm:p-3 md:p-3.5 flex flex-col justify-between space-y-2">
          <div className="space-y-1.5 sm:space-y-2">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-1.5">
              <div className="min-w-0">
                <h3 className="text-[11px] sm:text-xs font-black text-slate-900 dark:text-white truncate">
                  Tabel Data
                </h3>
                <p className="text-[9px] text-slate-400 font-bold">
                  10 Baris Siswa
                </p>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={handleLoadSample}
                  className="px-1.5 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-[9px] sm:text-[10px] font-bold hover:bg-blue-100 cursor-pointer"
                  title="Muat contoh data"
                >
                  Contoh
                </button>
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="p-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[9px] hover:bg-slate-200 cursor-pointer"
                  title="Kosongkan semua baris"
                >
                  <RotateCcw className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                </button>
              </div>
            </div>

            {/* Tabel 10 Baris (Compact / Diperkecil & Table-Fixed) */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <table className="w-full text-left text-xs table-fixed">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-[9px] sm:text-[10px] font-black uppercase text-slate-600 dark:text-slate-300">
                  <tr>
                    <th className="p-0.5 sm:p-1 w-5 sm:w-6 text-center">No</th>
                    <th className="p-0.5 sm:p-1 text-center" title="Variabel Bebas (X)">X</th>
                    <th className="p-0.5 sm:p-1 text-center" title="Variabel Terikat (Y)">Y</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                  {rows.map((row) => (
                    <tr key={row.no} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                      <td className="p-0.5 text-center font-bold text-slate-400 font-mono text-[9px] sm:text-[11px]">
                        {row.no}
                      </td>
                      <td className="p-0.5">
                        <input
                          type="number"
                          placeholder="X"
                          value={row.x}
                          onChange={(e) => handleInputChange(row.no, 'x', e.target.value)}
                          className="w-full h-6 sm:h-6.5 px-0.5 sm:px-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[10px] sm:text-xs font-mono font-bold text-center text-indigo-600 dark:text-indigo-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      </td>
                      <td className="p-0.5">
                        <input
                          type="number"
                          placeholder="Y"
                          value={row.y}
                          onChange={(e) => handleInputChange(row.no, 'y', e.target.value)}
                          className="w-full h-6 sm:h-6.5 px-0.5 sm:px-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[10px] sm:text-xs font-mono font-bold text-center text-blue-600 dark:text-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* TOMBOL UTAMA: BUAT GARIS REGRESI */}
          <div className="pt-1">
            <button
              id="btn-buat-garis-regresi"
              type="button"
              onClick={handleGenerateRegression}
              className={`w-full py-1.5 sm:py-2.5 rounded-xl font-black text-[10px] sm:text-xs flex items-center justify-center gap-1 sm:gap-1.5 shadow-md transition-all cursor-pointer active:scale-95 ${
                hasRegressionLine
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-emerald-500/25'
                  : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-blue-500/25'
              }`}
            >
              <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-cyan-200 animate-pulse shrink-0" />
              <span className="truncate">{hasRegressionLine ? 'Perbarui Garis' : 'Buat Garis Regresi'}</span>
            </button>
          </div>
        </div>

        {/* =========================================================================
            KANAN: DIAGRAM PENCAR & GARIS REGRESI
            ========================================================================= */}
        <div className="flex-1 min-w-0 bg-slate-950 rounded-2xl sm:rounded-3xl p-2.5 sm:p-4 md:p-5 border border-slate-800 shadow-xl flex flex-col justify-between space-y-2 sm:space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-1.5 text-xs">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-amber-400 shrink-0" />
              <span className="font-bold text-slate-300 text-[11px] sm:text-xs">
                Diagram Pencar ({validPoints.length} Titik)
              </span>
            </div>

            {hasRegressionLine && validPoints.length >= 2 && (
              <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono font-bold text-[10px] sm:text-xs animate-in fade-in">
                <span>ŷ = {stats.m}x + {stats.c}</span>
              </div>
            )}
          </div>

          {/* SVG Kanvas Scatter Plot */}
          <div className="h-64 sm:h-72 md:h-80 w-full bg-slate-900/90 rounded-xl sm:rounded-2xl p-2 sm:p-4 relative border border-slate-800/80 flex items-center justify-center overflow-hidden">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 400 240">
              {/* Grid Latar Belakang */}
              {[40, 80, 120, 160, 200].map((yVal, idx) => (
                <line
                  key={`grid-y-${idx}`}
                  x1="40"
                  y1={yVal}
                  x2="380"
                  y2={yVal}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
              ))}
              {[108, 176, 244, 312, 380].map((xVal, idx) => (
                <line
                  key={`grid-x-${idx}`}
                  x1={xVal}
                  y1="20"
                  x2={xVal}
                  y2="200"
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
              ))}

              {/* Sumbu X & Y Utama */}
              <line x1="40" y1="20" x2="40" y2="200" stroke="#475569" strokeWidth="2" />
              <line x1="40" y1="200" x2="380" y2="200" stroke="#475569" strokeWidth="2" />

              {/* Tanda Skala Sumbu X */}
              <text x="40" y="215" fill="#64748b" fontSize="9" textAnchor="middle">0</text>
              <text x="125" y="215" fill="#64748b" fontSize="9" textAnchor="middle">{Math.round(maxX * 0.25)}</text>
              <text x="210" y="215" fill="#64748b" fontSize="9" textAnchor="middle">{Math.round(maxX * 0.5)}</text>
              <text x="295" y="215" fill="#64748b" fontSize="9" textAnchor="middle">{Math.round(maxX * 0.75)}</text>
              <text x="380" y="215" fill="#64748b" fontSize="9" textAnchor="middle">{maxX}</text>

              {/* Tanda Skala Sumbu Y */}
              <text x="30" y="203" fill="#64748b" fontSize="9" textAnchor="end">0</text>
              <text x="30" y="158" fill="#64748b" fontSize="9" textAnchor="end">{Math.round(maxY * 0.25)}</text>
              <text x="30" y="113" fill="#64748b" fontSize="9" textAnchor="end">{Math.round(maxY * 0.5)}</text>
              <text x="30" y="68" fill="#64748b" fontSize="9" textAnchor="end">{Math.round(maxY * 0.75)}</text>
              <text x="30" y="25" fill="#64748b" fontSize="9" textAnchor="end">{maxY}</text>

              {/* GARIS REGRESI LINEAR: Hanya muncul jika hasRegressionLine === true */}
              {hasRegressionLine && validPoints.length >= 2 && (
                <line
                  x1="40"
                  y1={200 - ((stats.m * 0 + stats.c) / maxY) * 180}
                  x2="380"
                  y2={200 - ((stats.m * maxX + stats.c) / maxY) * 180}
                  stroke="#06b6d4"
                  strokeWidth="3"
                  strokeDasharray="4 2"
                  className="animate-in fade-in duration-300"
                />
              )}

              {/* TITIK DATA: Otomatis Terisi di Grafik saat siswa mengetik nilai X dan Y */}
              {validPoints.map((pt) => {
                const cx = 40 + (pt.x / maxX) * 340;
                const cy = 200 - (pt.y / maxY) * 180;
                return (
                  <g key={`pt-${pt.no}`}>
                    <circle
                      cx={cx}
                      cy={cy}
                      r="6"
                      className="fill-amber-400 stroke-slate-950 stroke-2 hover:r-8 transition-all cursor-pointer"
                    >
                      <title>{`No ${pt.no}: (${pt.x}, ${pt.y})`}</title>
                    </circle>
                    <text
                      x={cx}
                      y={cy - 9}
                      fill="#fde047"
                      fontSize="8"
                      fontWeight="bold"
                      textAnchor="middle"
                      className="select-none pointer-events-none"
                    >
                      {pt.no}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Label Sumbu */}
            <span className="absolute bottom-1 right-3 sm:right-4 text-[9px] sm:text-[10px] font-mono text-slate-400">
              Variabel Bebas (X) →
            </span>
            <span className="absolute top-2 left-2 text-[9px] sm:text-[10px] font-mono text-slate-400">
              ↑ Variabel Terikat (Y)
            </span>
          </div>

          {/* Keterangan */}
          <div className="flex flex-wrap items-center justify-between text-[10px] sm:text-[11px] text-slate-400 pt-0.5">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>Titik Kuning: Data observasi (X, Y)</span>
            </span>
            {hasRegressionLine && (
              <span className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <span className="w-3.5 h-0.5 bg-cyan-400" />
                <span>Garis Putus: Garis Regresi</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* =========================================================================
          BAGIAN BAWAH: HASIL ANALISIS REGRESI LINEAR (LETAK DI BAWAH)
          ========================================================================= */}
      <div className="w-full">
        {hasRegressionLine && validPoints.length >= 2 ? (
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-850 dark:to-slate-900 p-4 sm:p-6 rounded-3xl border border-blue-200 dark:border-slate-700 shadow-sm space-y-4 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-blue-200/80 dark:border-slate-700 pb-3">
              <h4 className="text-xs sm:text-sm font-black uppercase text-blue-900 dark:text-blue-300 flex items-center gap-2">
                <Calculator className="w-4 h-4 text-blue-600" />
                <span>Hasil Analisis Model Regresi Linear</span>
              </h4>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[10px] font-black uppercase flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>Garis Berhasil Dibuat</span>
              </span>
            </div>

            {/* Grid Parameter Regresi */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
              <div className="bg-white dark:bg-slate-900 p-3 sm:p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Gradien (m)
                </span>
                <span className="text-lg sm:text-xl font-black text-slate-900 dark:text-white font-mono">
                  {stats.m}
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">
                  Kemiringan Garis
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 p-3 sm:p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Intersep (c)
                </span>
                <span className="text-lg sm:text-xl font-black text-slate-900 dark:text-white font-mono">
                  {stats.c}
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">
                  Titik Potong Sumbu Y
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 p-3 sm:p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Korelasi (r)
                </span>
                <span className="text-lg sm:text-xl font-black text-blue-600 font-mono">
                  {stats.r}
                </span>
                <span className={`text-[9px] font-bold block mt-0.5 truncate ${hubunganKorelasi.textClass}`}>
                  {hubunganKorelasi.label}
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 p-3 sm:p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Determinasi (R²)
                </span>
                <span className="text-lg sm:text-xl font-black text-emerald-600 font-mono">
                  {(stats.r2 * 100).toFixed(1)}%
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">
                  Kesesuaian Model
                </span>
              </div>
            </div>

            {/* Interpretasi Persamaan & Hubungan Dua Data */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white/90 dark:bg-slate-900/90 border border-blue-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
                <div className="flex items-center gap-1.5 text-blue-700 dark:text-blue-300 font-bold">
                  <TrendingUp className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Interpretasi Persamaan (Hubungan Dua Data):</span>
                </div>
                <span className={`px-2.5 py-0.5 rounded-full border text-[10px] font-black uppercase tracking-wide ${hubunganKorelasi.badgeClass}`}>
                  Hubungan {hubunganKorelasi.label}
                </span>
              </div>

              <div className="leading-relaxed space-y-2">
                <p>
                  Persamaan garis regresi <strong className="font-mono text-indigo-600 dark:text-indigo-400">ŷ = {stats.m}x + {stats.c}</strong> dan koefisien korelasi <strong className="font-mono text-blue-600 dark:text-blue-400">r = {stats.r}</strong> membahas hubungan antara kedua data (variabel bebas X dan variabel terikat Y) yang menunjukkan <strong className={hubunganKorelasi.textClass}>hubungan {hubunganKorelasi.label.toLowerCase()}</strong> (seperti hubungan positif kuat). {hubunganKorelasi.deskripsi}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Makna matematis dari persamaan garis regresi tersebut: nilai gradien kemiringan <strong className="font-mono text-slate-700 dark:text-slate-200">m = {stats.m}</strong> bermakna bahwa setiap penambahan 1 satuan nilai variabel X diestimasikan mengubah variabel Y sebesar <strong className="font-mono">{stats.m}</strong> satuan, dengan nilai dasar (intersep) <strong className="font-mono">c = {stats.c}</strong> saat X bernilai 0. Nilai koefisien determinasi <strong className="font-mono text-emerald-600 dark:text-emerald-400">R² = {(stats.r2 * 100).toFixed(1)}%</strong> menunjukkan seberapa kuat variasi nilai Y dapat dijelaskan secara linier oleh variabel X melalui model ini.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 text-center space-y-2">
            <LineChartIcon className="w-8 h-8 text-slate-400 mx-auto" />
            <h4 className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300">
              Garis Regresi Belum Dibuat
            </h4>
            <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
              Isi pasangan nilai X dan Y pada tabel 10 baris di sebelah kiri, kemudian klik tombol <strong>"Buat Garis Regresi"</strong> di bawah tabel untuk memunculkan garis regresi dan hasil analisis statistik secara otomatis.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

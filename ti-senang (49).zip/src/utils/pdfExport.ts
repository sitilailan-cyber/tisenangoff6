import { jsPDF } from 'jspdf';
import { AsesmenAwalInput, Student, User } from '../types';

export interface ExportAsesmenPdfParams {
  className: string;
  subjectName: string;
  teacherName: string;
  assessmentData: AsesmenAwalInput[];
  students: Array<Student & { user?: User; className?: string }> | Student[];
}

export function exportAsesmenToPdf(params: ExportAsesmenPdfParams): void {
  const { className, subjectName, teacherName, assessmentData } = params;
  const doc = new jsPDF();

  // Header
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN ASESMEN AWAL DIAGNOSTIK MIPA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mata Pelajaran : ${subjectName}`, 14, 28);
  doc.text(`Kelas          : ${className}`, 14, 34);
  doc.text(`Guru Pengampu  : ${teacherName}`, 14, 40);
  doc.text(`Tanggal Cetak  : ${new Date().toLocaleDateString('id-ID')}`, 14, 46);

  // Table header
  let startY = 56;
  doc.setFillColor(30, 41, 59);
  doc.rect(14, startY, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('No', 16, startY + 5.5);
  doc.text('Nama Murid', 26, startY + 5.5);
  doc.text('Diagnostik', 90, startY + 5.5);
  doc.text('Literasi', 112, startY + 5.5);
  doc.text('Numerasi', 130, startY + 5.5);
  doc.text('Penalaran', 150, startY + 5.5);
  doc.text('Kesiapan', 170, startY + 5.5);

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  let currentY = startY + 8;

  assessmentData.forEach((row, idx) => {
    if (currentY > 270) {
      doc.addPage();
      currentY = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(241, 245, 249);
      doc.rect(14, currentY, 182, 7, 'F');
    }

    doc.text(String(idx + 1), 16, currentY + 5);
    doc.text((row.studentName || 'Murid').slice(0, 26), 26, currentY + 5);
    doc.text(String(row.diagnosticScore), 94, currentY + 5);
    doc.text(String(row.literacyScore), 116, currentY + 5);
    doc.text(String(row.numeracyScore), 134, currentY + 5);
    doc.text(String(row.reasoningScore), 154, currentY + 5);
    doc.text((row.readinessLevel || 'Berkembang').slice(0, 14), 170, currentY + 5);

    currentY += 7;
  });

  // Footer summary
  currentY += 8;
  if (currentY > 260) {
    doc.addPage();
    currentY = 20;
  }

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text(
    '* Laporan ini diunduh secara otomatis dari sistem pembelajaran adaptif TI SENANG.',
    14,
    currentY,
  );

  doc.save(`Asesmen_Awal_${className}_${subjectName.replace(/\s+/g, '_')}.pdf`);
}

export interface ExportAsesmenAkhirPdfParams {
  className: string;
  subjectName: string;
  teacherName: string;
  kktpTarget?: number;
  records: Array<{
    studentName: string;
    nisn?: string;
    score: number;
    kktpStatus: 'Tuntas' | 'Belum Tuntas';
    predikat: string;
    tpMasteryPercentage: number;
    catatan?: string;
  }>;
}

export function exportAsesmenAkhirToPdf(params: ExportAsesmenAkhirPdfParams): void {
  const { className, subjectName, teacherName, kktpTarget = 75, records } = params;
  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN ASESMEN SUMATIF AKHIR MIPA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mata Pelajaran    : ${subjectName}`, 14, 28);
  doc.text(`Kelas             : ${className}`, 14, 34);
  doc.text(`Guru Pengampu     : ${teacherName}`, 14, 40);
  doc.text(`Kriteria Ketuntasan (KKTP) : ≥ ${kktpTarget}`, 14, 46);
  doc.text(`Tanggal Cetak     : ${new Date().toLocaleDateString('id-ID')}`, 14, 52);

  // Table header
  let startY = 60;
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(14, startY, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('No', 16, startY + 5.5);
  doc.text('Nama Murid', 26, startY + 5.5);
  doc.text('Nilai Akhir', 88, startY + 5.5);
  doc.text('Ketuntasan KKTP', 112, startY + 5.5);
  doc.text('Predikat', 148, startY + 5.5);
  doc.text('Capaian TP', 170, startY + 5.5);

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  let currentY = startY + 8;

  records.forEach((row, idx) => {
    if (currentY > 270) {
      doc.addPage();
      currentY = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, currentY, 182, 7, 'F');
    }

    doc.text(String(idx + 1), 16, currentY + 5);
    doc.text((row.studentName || 'Murid').slice(0, 28), 26, currentY + 5);
    doc.text(String(row.score), 94, currentY + 5);

    if (row.kktpStatus === 'Tuntas') {
      doc.setTextColor(16, 185, 129); // emerald green
    } else {
      doc.setTextColor(225, 29, 72); // rose red
    }
    doc.text(row.kktpStatus, 114, currentY + 5);

    doc.setTextColor(0, 0, 0);
    doc.text((row.predikat || 'B').slice(0, 10), 148, currentY + 5);
    doc.text(`${row.tpMasteryPercentage}%`, 172, currentY + 5);

    currentY += 7;
  });

  // Footer summary
  currentY += 10;
  if (currentY > 255) {
    doc.addPage();
    currentY = 20;
  }

  const totalSiswa = records.length;
  const tuntasCount = records.filter((r) => r.kktpStatus === 'Tuntas').length;
  const avgScore = totalSiswa
    ? (records.reduce((acc, r) => acc + r.score, 0) / totalSiswa).toFixed(1)
    : '0';

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Ringkasan Capaian Kelas:`, 14, currentY);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `• Rata-rata Nilai: ${avgScore}  |  • Ketuntasan Klasikal: ${tuntasCount}/${totalSiswa} Murid (${
      totalSiswa ? Math.round((tuntasCount / totalSiswa) * 100) : 0
    }%)`,
    14,
    currentY + 6,
  );

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text(
    '* Laporan Asesmen Akhir ini diverifikasi dan diunduh dari modul evaluasi adaptif TI SENANG.',
    14,
    currentY + 14,
  );

  doc.save(`Asesmen_Akhir_${className}_${subjectName.replace(/\s+/g, '_')}.pdf`);
}

export interface ExportRefleksiPdfParams {
  studentName: string;
  className: string;
  subjectName?: string;
  teacherName?: string;
  missionTitle: string;
  submittedAt: string;
  reflectionAnswers: {
    pemahaman?: string;
    tantangan?: string;
    halMenarik?: string;
    rencanaPerbaikan?: string;
    [key: string]: string | undefined;
  };
  selfAssessment: {
    kemandirian?: number;
    pemahamanKonsep?: number;
    keterampilanAnalisis?: number;
    sikapReflektif?: number;
    totalScorePercentage?: number;
    komitmen?: string;
  };
}

export function exportRefleksiToPdf(params: any): void {
  const studentName = params.studentName || 'Murid TI SENANG';
  const className = params.className || 'Kelas Fase F';
  const subjectName = params.subjectName || 'Fisika & MIPA Terapan';
  const teacherName = params.teacherName || 'Guru Pengampu MIPA';
  const missionTitle = params.missionTitle || 'Misi 5 • Refleksi & Penilaian Diri';
  const submittedAt = params.submittedAt || new Date().toISOString();

  // Normalize reflection answers whether passed as array or object
  let reflectionAnswers: any = {};
  if (Array.isArray(params.refleksiAnswers)) {
    reflectionAnswers = {
      pemahaman: params.refleksiAnswers[0] || 'Konsep regresi linear dan Azas Black.',
      tantangan: params.refleksiAnswers[1] || 'Menganalisis kemiringan grafik regresi.',
      halMenarik: params.refleksiAnswers[2] || 'Pengambilan data sensor otomatis.',
      rencanaPerbaikan: params.refleksiAnswers[3] || 'Lebih teliti dalam mencatat satuan.',
    };
  } else if (params.reflectionAnswers) {
    reflectionAnswers = params.reflectionAnswers;
  }

  // Normalize self assessment
  const rawSelf = params.selfAssessment || {};
  const selfAssessment = {
    kemandirian: rawSelf.kemandirian || 3,
    pemahamanKonsep: rawSelf.pemahamanKonsep || 3,
    keterampilanAnalisis: rawSelf.keterampilanAnalisis || rawSelf.keterampilanData || 3,
    sikapReflektif: rawSelf.sikapReflektif || rawSelf.sikapKritis || 4,
    totalScorePercentage: params.averageSelfScore || rawSelf.totalScorePercentage || 85,
    komitmen: rawSelf.komitmen || rawSelf.komitmenDiri || '',
  };

  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN REFLEKSI & PENILAIAN DIRI MURID', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nama Murid    : ${studentName}`, 14, 28);
  doc.text(`Kelas         : ${className}`, 14, 34);
  doc.text(`Mata Pelajaran: ${subjectName}`, 14, 40);
  doc.text(`Guru Pengampu : ${teacherName}`, 14, 46);
  doc.text(`Misi Terkait  : ${missionTitle}`, 14, 52);
  doc.text(
    `Waktu Kirim   : ${new Date(submittedAt || Date.now()).toLocaleString('id-ID')}`,
    14,
    58,
  );

  let currentY = 66;

  // BAGIAN 1: PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT)
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(
    params.isOffline
      ? 'A. RUBRIK PENILAIAN DIRI SENDIRI (OFFLINE)'
      : 'A. HASIL PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT RUBRIC)',
    16,
    currentY + 5,
  );

  currentY += 10;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);

  const selfItems = Array.isArray(params.customRubrics) && params.customRubrics.length > 0
    ? params.customRubrics.map((r: any) => ({
        label: r.label,
        val: typeof r.val === 'number' ? r.val : typeof r.score === 'number' ? r.score : 4,
      }))
    : [
        { label: 'Kemandirian & Keaktifan Belajar', val: selfAssessment.kemandirian || 4 },
        { label: 'Pemahaman Konsep & Penalaran Ilmiah', val: selfAssessment.pemahamanKonsep || 4 },
        { label: 'Keterampilan Analisis Data & Eksperimen', val: selfAssessment.keterampilanAnalisis || 4 },
        { label: 'Sikap Kritis, Teliti & Bertanggung Jawab', val: selfAssessment.sikapReflektif || 4 },
      ];

  selfItems.forEach((item: { label: string; val: number }, idx: number) => {
    if (currentY > 260) {
      doc.addPage();
      currentY = 20;
    }
    const starStr = '★'.repeat(Math.min(4, Math.max(1, item.val))) + '☆'.repeat(Math.max(0, 4 - item.val));
    const scoreVal = `${item.val} / 4  (${starStr})`;
    doc.text(`${item.label.match(/^\d/) ? '' : (idx + 1) + '. '}${item.label}`, 16, currentY);
    doc.setFont('helvetica', 'bold');
    doc.text(scoreVal, 150, currentY);
    doc.setFont('helvetica', 'normal');
    currentY += 6;
  });

  const totalPercent = selfAssessment.totalScorePercentage || 95;
  currentY += 2;
  doc.setFont('helvetica', 'bold');
  doc.text(`Tingkat Capaian Penilaian Diri: ${totalPercent}% (${totalPercent >= 85 ? 'Sangat Baik' : totalPercent >= 75 ? 'Baik' : 'Perlu Bimbingan'})`, 16, currentY);
  doc.setFont('helvetica', 'normal');

  const komitmenText = params.komitmen || selfAssessment.komitmen;
  if (komitmenText) {
    currentY += 6;
    doc.setFont('helvetica', 'italic');
    doc.text(`Komitmen Pribadi Peningkatan Belajar: "${komitmenText}"`, 16, currentY, { maxWidth: 178 });
    currentY += 8;
  } else {
    currentY += 6;
  }

  currentY += 4;

  // BAGIAN 2: REFLEKSI PEMBELAJARAN
  if (currentY > 240) {
    doc.addPage();
    currentY = 20;
  }
  doc.setFillColor(30, 41, 59);
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(
    params.isOffline
      ? 'B. REFLEKSI PEMBELAJARAN (OFFLINE)'
      : 'B. HASIL REFLEKSI PEMBELAJARAN MURID',
    16,
    currentY + 5,
  );

  currentY += 11;
  doc.setTextColor(0, 0, 0);

  const questionsMap = Array.isArray(params.customQuestions) && params.customQuestions.length > 0
    ? params.customQuestions
    : [
        {
          q: '1. Konsep sains / materi yang paling dipahami dengan baik:',
          a: reflectionAnswers.pemahaman || 'Murid telah memahami konsep materi dan penerapannya dengan baik.',
        },
        {
          q: '2. Tantangan atau kesulitan yang dihadapi & solusinya:',
          a: reflectionAnswers.tantangan || 'Tantangan dapat diselesaikan melalui analisis mandiri dan bantuan bimbingan guru.',
        },
        {
          q: '3. Hal atau fenomena yang paling menarik dalam pembelajaran ini:',
          a: reflectionAnswers.halMenarik || 'Eksperimen sensor langsung dan simulasi grafis memudahkan visualisasi hubungan antarvariabel.',
        },
        {
          q: '4. Rencana aksi untuk meningkatkan pemahaman pada topik berikutnya:',
          a: reflectionAnswers.rencanaPerbaikan || 'Membaca modul pengayaan lebih awal dan memperbanyak latihan penalaran kontekstual.',
        },
      ];

  questionsMap.forEach((item: { q: string; a: string }) => {
    if (currentY > 260) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(item.q, 16, currentY);
    currentY += 5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const splitText = doc.splitTextToSize(item.a, 175);
    doc.text(splitText, 18, currentY);
    currentY += splitText.length * 4.5 + 4;
  });

  // Footer & Tanda Tangan
  if (currentY > 240) {
    doc.addPage();
    currentY = 25;
  } else {
    currentY += 10;
  }

  const signY = currentY + 10;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', 14, signY);
  doc.text('Guru Pengampu MIPA', 14, signY + 5);
  doc.text('_________________________', 14, signY + 22);
  doc.text(teacherName, 14, signY + 27);

  doc.text('Murid Bersangkutan,', 140, signY);
  doc.text('Kelas ' + className, 140, signY + 5);
  doc.text('_________________________', 140, signY + 22);
  doc.text(studentName, 140, signY + 27);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.text(
    '* Dokumen Refleksi & Penilaian Diri ini dibuat dan diunduh dari Platform Pembelajaran Adaptif TI SENANG.',
    14,
    signY + 36,
  );

  const fileNamePrefix = params.isOffline ? 'Refleksi_Offline_' : 'Refleksi_';
  doc.save(`${fileNamePrefix}${studentName.replace(/\s+/g, '_')}_${className}.pdf`);
}

export interface ExportMisi2PdfParams {
  studentName: string;
  className: string;
  subjectName?: string;
  teacherName?: string;
  missionTitle?: string;
  portfolioTitle: string;
  tpCode?: string;
  tpTitle?: string;
  contextualProblem?: string;
  tableRows?: Array<{ waktu: number; suhuAwal: number; intensitasCahaya: number; suhuAkhir: number }>;
  regressionStats?: {
    equation: string;
    r: number;
    r2: number;
    correlationDesc: string;
    interpretasiFisis: string;
  };
  analysisAnswers?: {
    q1_amat?: string;
    q2_pola?: string;
    q3_sebabSuhu?: string;
    q4_hubunganVariabel?: string;
  };
  laporanCatatan?: string;
  conclusion: string;
  photoDataUrl?: string;
  submittedAt?: string;
}

export function exportMisi2ExperimentToPdf(params: ExportMisi2PdfParams): void {
  const studentName = params.studentName || 'Murid MIPA';
  const className = params.className || 'Kelas XII Fase F';
  const subjectName = params.subjectName || 'Fisika Eksperimental & Terapan';
  const teacherName = params.teacherName || 'Guru Pengampu MIPA';
  const missionTitle = params.missionTitle || 'Misi 2 • Selesaikan Masalah';
  const portfolioTitle = params.portfolioTitle || 'Laporan Hasil Penyelidikan & Eksperimen MIPA';
  const submittedAt = params.submittedAt || new Date().toISOString();

  const doc = new jsPDF();

  // Header Banner
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN EKSPERIMEN & PENYELESAIAN MASALAH MIPA', 14, 18);

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nama Murid    : ${studentName}`, 14, 25);
  doc.text(`Kelas         : ${className}`, 14, 30);
  doc.text(`Mata Pelajaran: ${subjectName}`, 14, 35);
  doc.text(`Guru Pengampu : ${teacherName}`, 14, 40);
  doc.text(`Misi Terkait  : ${missionTitle}`, 14, 45);
  doc.text(`Tanggal Cetak : ${new Date(submittedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, 14, 50);

  let currentY = 56;

  // Judul Portofolio & Tujuan Pembelajaran
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('A. INFORMASI TOPIK & TUJUAN PEMBELAJARAN (TP)', 16, currentY + 5);

  currentY += 11;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Judul Portofolio: "${portfolioTitle}"`, 14, currentY);
  currentY += 5;

  if (params.tpCode || params.tpTitle) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const tpText = `Tujuan Pembelajaran: [${params.tpCode || 'TP'}] ${params.tpTitle || 'Penyelidikan Konsep Saintifik & Eksperimen'}`;
    const splitTp = doc.splitTextToSize(tpText, 180);
    doc.text(splitTp, 14, currentY);
    currentY += splitTp.length * 4.5 + 2;
  }

  // Tabel Data Pengamatan
  const rows = params.tableRows || [];
  if (rows.length > 0) {
    currentY += 2;
    doc.setFillColor(15, 23, 42);
    doc.rect(14, currentY, 182, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text('B. TABEL DATA HASIL EKSPERIMEN & PENGAMATAN SENSOR', 16, currentY + 5);

    currentY += 9;
    // Table Header
    doc.setFillColor(241, 245, 249);
    doc.rect(14, currentY, 182, 6, 'F');
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text('No', 16, currentY + 4.5);
    doc.text('Waktu (menit)', 30, currentY + 4.5);
    doc.text('Suhu Awal (°C)', 70, currentY + 4.5);
    doc.text('Intensitas Cahaya (Lux)', 110, currentY + 4.5);
    doc.text('Suhu Akhir (°C)', 160, currentY + 4.5);

    currentY += 6;
    doc.setFont('helvetica', 'normal');

    rows.slice(0, 15).forEach((row, i) => {
      if (currentY > 270) {
        doc.addPage();
        currentY = 20;
      }
      if (i % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, currentY, 182, 5.5, 'F');
      }
      doc.text(String(i + 1), 16, currentY + 4);
      doc.text(String(row.waktu), 30, currentY + 4);
      doc.text(row.suhuAwal.toFixed(1), 70, currentY + 4);
      doc.text(String(row.intensitasCahaya), 110, currentY + 4);
      doc.text(row.suhuAkhir.toFixed(1), 160, currentY + 4);
      currentY += 5.5;
    });
  }

  // Analisis Regresi Linear & Matematika
  if (params.regressionStats) {
    if (currentY > 240) {
      doc.addPage();
      currentY = 20;
    } else {
      currentY += 4;
    }

    doc.setFillColor(15, 23, 42);
    doc.rect(14, currentY, 182, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text('C. ANALISIS MATEMATIS & REGRESI DATA BIVARIAT', 16, currentY + 5);

    currentY += 10;
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);

    doc.text(`• Persamaan Garis Regresi : ${params.regressionStats.equation}`, 16, currentY);
    currentY += 5;
    doc.text(`• Koefisien Korelasi (r)  : ${params.regressionStats.r.toFixed(3)}  |  Koefisien Determinasi (R²): ${(params.regressionStats.r2 * 100).toFixed(1)}%`, 16, currentY);
    currentY += 5;
    doc.text(`• Klasifikasi Korelasi   : ${params.regressionStats.correlationDesc}`, 16, currentY);
    currentY += 5;
    const splitInterp = doc.splitTextToSize(`• Makna Fisis : ${params.regressionStats.interpretasiFisis}`, 178);
    doc.text(splitInterp, 16, currentY);
    currentY += splitInterp.length * 4.5 + 2;
  }

  // Kesimpulan Saintifik
  if (currentY > 230) {
    doc.addPage();
    currentY = 20;
  } else {
    currentY += 4;
  }

  doc.setFillColor(15, 23, 42);
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('D. KESIMPULAN SAINTIFIK & REFLEKSI PELAKSANAAN', 16, currentY + 5);

  currentY += 10;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Kesimpulan Siswa:', 16, currentY);
  currentY += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  const splitConc = doc.splitTextToSize(params.conclusion || 'Berdasarkan hasil eksperimen, data pengamatan terbukti konsisten dengan teori yang dipelajari.', 178);
  doc.text(splitConc, 16, currentY);
  currentY += splitConc.length * 4.5 + 4;

  if (params.laporanCatatan) {
    if (currentY > 250) {
      doc.addPage();
      currentY = 20;
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('Catatan Pelaksanaan / Prosedur:', 16, currentY);
    currentY += 5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const splitCatatan = doc.splitTextToSize(params.laporanCatatan, 178);
    doc.text(splitCatatan, 16, currentY);
    currentY += splitCatatan.length * 4.5 + 4;
  }

  // Tanda Tangan
  if (currentY > 240) {
    doc.addPage();
    currentY = 25;
  } else {
    currentY += 8;
  }

  const signY = currentY + 8;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', 14, signY);
  doc.text('Guru Pengampu MIPA', 14, signY + 5);
  doc.text('_________________________', 14, signY + 22);
  doc.text(teacherName, 14, signY + 27);

  doc.text('Murid Bersangkutan,', 140, signY);
  doc.text('Kelas ' + className, 140, signY + 5);
  doc.text('_________________________', 140, signY + 22);
  doc.text(studentName, 140, signY + 27);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.text(
    '* Dokumen Laporan Eksperimen Misi 2 ini diunduh secara resmi dari platform pembelajaran adaptif TI SENANG.',
    14,
    signY + 36,
  );

  const cleanName = studentName.replace(/[^a-zA-Z0-9_-]/g, '_');
  doc.save(`Laporan_Misi2_${cleanName}_${new Date().toISOString().slice(0, 10)}.pdf`);
}

export interface ExportPengalamanBelajarPdfParams {
  student: {
    name: string;
    username: string;
    nisn?: string;
    className: string;
    kelompok?: string;
    xp: number;
    level: number;
    streakDays: number;
  };
  teacherName?: string;
  missionsData: {
    misi1: {
      title: string;
      score: number;
      xp: number;
      status: string;
      notes?: string;
      materi?: string;
    };
    misi2: {
      title: string;
      score: number;
      xp: number;
      status: string;
      problemSolution?: string;
      answersSummary?: string;
      conclusion?: string;
      feedback?: string;
    };
    misi3: {
      title: string;
      score: number;
      xp: number;
      status: string;
      experimentSummary?: string;
      experimentRows?: Array<{
        waktu: number;
        suhuAwal: number;
        intensitasCahaya: number;
        suhuAkhir: number;
      }>;
      portfolioCount?: number;
      conclusion?: string;
    };
    misi4: {
      title: string;
      score: number;
      xp: number;
      status: string;
      gameHighlights?: string;
    };
    misi5: {
      title: string;
      score: number;
      xp: number;
      status: string;
      pemahaman?: string;
      tantangan?: string;
      halMenarik?: string;
      rencanaPerbaikan?: string;
      selfScore?: number;
      komitmen?: string;
    };
    misi6: {
      title: string;
      score: number;
      xp: number;
      status: string;
      kktpStatus?: string;
      predikat?: string;
      tpMastery?: number;
      catatanGuru?: string;
    };
  };
  portfoliosList?: Array<{
    title: string;
    subjectName: string;
    date: string;
    xp: number;
    category?: string;
  }>;
}

export function exportPengalamanBelajarToPdf(params: ExportPengalamanBelajarPdfParams): void {
  const { student, teacherName = 'Guru Pengampu MIPA', missionsData, portfoliosList = [] } = params;
  const doc = new jsPDF();
  const pageWidth = 210;
  const margin = 14;
  const contentWidth = 182;
  let currentY = 18;

  const helperCheckPageBreak = (neededHeight: number) => {
    if (currentY + neededHeight > 272) {
      doc.addPage();
      currentY = 20;
      return true;
    }
    return false;
  };

  // =========================================================================
  // HEADER RESMI TI SENANG
  // =========================================================================
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(margin, currentY, contentWidth, 22, 'F');

  doc.setTextColor(56, 189, 248); // sky-400
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('TI SENANG — PLATFORM PEMBELAJARAN MIPA BERBASIS INQUIRY & TEKNOLOGI', margin + 6, currentY + 7);

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(11);
  doc.text('LAPORAN HASIL PEKERJAAN, PENGALAMAN & NILAI SISWA', margin + 6, currentY + 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(203, 213, 225); // slate-300
  doc.text('Rekapitulasi Capaian Misi 1 sampai Misi 6 Fase F SMA', margin + 6, currentY + 19);

  currentY += 26;

  // =========================================================================
  // BIODATA & IDENTITAS SISWA
  // =========================================================================
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.roundedRect(margin, currentY, contentWidth, 26, 2, 2, 'FD');

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Nama Murid  : ${student.name}`, margin + 4, currentY + 6);
  doc.text(`Kelas / Pok : ${student.className} • ${student.kelompok || 'Kelompok 1'}`, margin + 4, currentY + 12);
  doc.text(`NISN / Akun : ${student.nisn ? student.nisn : `@${student.username}`}`, margin + 4, currentY + 18);
  doc.text(`Total Skor  : Level ${student.level}  |  ${student.xp} XP  |  Streak ${student.streakDays} Hari`, margin + 4, currentY + 24);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Guru Pengampu : ${teacherName}`, 115, currentY + 6);
  doc.text(`Kurikulum     : Merdeka (Fase F)`, 115, currentY + 12);
  doc.text(`Mata Pelajaran: MIPA (Fisika, Kimia, Bio, Mat)`, 115, currentY + 18);
  doc.text(`Tanggal Cetak : ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, 115, currentY + 24);

  currentY += 31;

  // =========================================================================
  // BAGIAN 1: TABEL REKAPITULASI NILAI MISI 1 - MISI 6
  // =========================================================================
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(margin, currentY, contentWidth, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('I. REKAPITULASI CAPAIAN & NILAI PEMBELAJARAN (MISI 1 — MISI 6)', margin + 3, currentY + 5);

  currentY += 9;

  // Table header
  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text('No', margin + 3, currentY + 4.5);
  doc.text('Nama Misi Pembelajaran', margin + 14, currentY + 4.5);
  doc.text('Nilai', margin + 110, currentY + 4.5);
  doc.text('Ketuntasan', margin + 128, currentY + 4.5);
  doc.text('XP', margin + 155, currentY + 4.5);
  doc.text('Status', margin + 168, currentY + 4.5);

  currentY += 6;
  doc.setFont('helvetica', 'normal');

  const missionRows = [
    {
      no: '1',
      name: 'Misi 1: Pahami Konsep Esensial Sains',
      score: missionsData.misi1.score,
      kktp: missionsData.misi1.score >= 75 ? 'Tuntas' : 'Perlu Penguatan',
      xp: `+${missionsData.misi1.xp} XP`,
      status: missionsData.misi1.status === 'COMPLETED' ? 'Selesai' : 'Aktif',
    },
    {
      no: '2',
      name: 'Misi 2: Selesaikan Masalah Nyata STEM',
      score: missionsData.misi2.score,
      kktp: missionsData.misi2.score >= 75 ? 'Tuntas' : 'Perlu Penguatan',
      xp: `+${missionsData.misi2.xp} XP`,
      status: missionsData.misi2.status === 'COMPLETED' ? 'Selesai' : 'Aktif',
    },
    {
      no: '3',
      name: 'Misi 3: Eksplorasi & Eksperimen Virtual Lab',
      score: missionsData.misi3.score,
      kktp: missionsData.misi3.score >= 75 ? 'Tuntas' : 'Perlu Penguatan',
      xp: `+${missionsData.misi3.xp} XP`,
      status: missionsData.misi3.status === 'COMPLETED' ? 'Selesai' : 'Aktif',
    },
    {
      no: '4',
      name: 'Misi 4: Permainan Edukasi (Game Interaktif)',
      score: missionsData.misi4.score,
      kktp: missionsData.misi4.score >= 75 ? 'Tuntas' : 'Perlu Penguatan',
      xp: `+${missionsData.misi4.xp} XP`,
      status: missionsData.misi4.status === 'COMPLETED' ? 'Selesai' : 'Aktif',
    },
    {
      no: '5',
      name: 'Misi 5: Refleksi & Penilaian Diri (Metakognisi)',
      score: missionsData.misi5.score,
      kktp: missionsData.misi5.score >= 75 ? 'Tuntas' : 'Perlu Penguatan',
      xp: `+${missionsData.misi5.xp} XP`,
      status: missionsData.misi5.status === 'COMPLETED' ? 'Selesai' : 'Aktif',
    },
    {
      no: '6',
      name: 'Misi 6: Asesmen Akhir Komprehensif',
      score: missionsData.misi6.score,
      kktp: missionsData.misi6.score >= 75 ? 'Tuntas' : 'Perlu Bimbingan',
      xp: `+${missionsData.misi6.xp} XP`,
      status: missionsData.misi6.status === 'COMPLETED' ? 'Selesai' : 'Aktif',
    },
  ];

  let totalScoreSum = 0;
  missionRows.forEach((row, i) => {
    totalScoreSum += row.score;
    if (i % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, currentY, contentWidth, 5.5, 'F');
    }
    doc.setTextColor(15, 23, 42);
    doc.text(row.no, margin + 3, currentY + 4);
    doc.text(row.name, margin + 14, currentY + 4);
    doc.setFont('helvetica', 'bold');
    doc.text(String(row.score), margin + 112, currentY + 4);
    doc.setFont('helvetica', 'normal');

    if (row.kktp === 'Tuntas') {
      doc.setTextColor(16, 185, 129); // emerald
    } else {
      doc.setTextColor(225, 29, 72); // rose
    }
    doc.text(row.kktp, margin + 128, currentY + 4);

    doc.setTextColor(71, 85, 105);
    doc.text(row.xp, margin + 155, currentY + 4);

    doc.setTextColor(15, 23, 42);
    doc.text(row.status, margin + 168, currentY + 4);

    currentY += 5.5;
  });

  const avgScore = (totalScoreSum / missionRows.length).toFixed(1);

  // Baris Ringkasan Rata-rata
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('Rata-rata Nilai Keseluruhan Misi :', margin + 14, currentY + 4.5);
  doc.setTextColor(16, 185, 129);
  doc.text(`${avgScore} / 100`, margin + 110, currentY + 4.5);
  doc.setTextColor(15, 23, 42);
  doc.text(`Ketuntasan: ${Number(avgScore) >= 75 ? 'Tuntas Optimal' : 'Dalam Pendampingan'}`, margin + 128, currentY + 4.5);

  currentY += 10;

  // =========================================================================
  // BAGIAN 2: RINCIAN HASIL PEKERJAAN & PENGALAMAN SETIAP MISI
  // =========================================================================
  helperCheckPageBreak(30);
  doc.setFillColor(30, 41, 59);
  doc.rect(margin, currentY, contentWidth, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('II. RINCIAN HASIL PEKERJAAN & PENGALAMAN BELAJAR PER MISI', margin + 3, currentY + 5);

  currentY += 10;

  // --- MISI 1 ---
  helperCheckPageBreak(25);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('1. Misi 1 — Pahami Konsep Esensial Sains', margin + 3, currentY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Nilai: ${missionsData.misi1.score} | XP: +${missionsData.misi1.xp} | Status: ${missionsData.misi1.status}`, 120, currentY + 4.5);

  currentY += 8;
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text('Materi / Konsep yang Dipelajari:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');
  const m1Materi = missionsData.misi1.materi || 'Pemodelan Regresi Linear Bivariat (Matematika), Asas Black & Kalor (Fisika), Teori VSEPR & Geometri Molekul (Kimia), dan Transpirasi & Hereditas (Biologi).';
  const splitM1Materi = doc.splitTextToSize(m1Materi, contentWidth - 6);
  doc.text(splitM1Materi, margin + 3, currentY);
  currentY += splitM1Materi.length * 4 + 2;

  doc.setFont('helvetica', 'bold');
  doc.text('Catatan & Pemahaman Siswa:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');
  const m1Notes = missionsData.misi1.notes || 'Siswa telah menelaah materi konsep esensial, mencatat hubungan antarvariabel bebas dan terikat, serta memahami prinsip dasar representasi matematis fenomena alam.';
  const splitM1Notes = doc.splitTextToSize(m1Notes, contentWidth - 6);
  doc.text(splitM1Notes, margin + 3, currentY);
  currentY += splitM1Notes.length * 4 + 5;

  // --- MISI 2 ---
  helperCheckPageBreak(28);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('2. Misi 2 — Selesaikan Masalah Nyata STEM', margin + 3, currentY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Nilai: ${missionsData.misi2.score} | XP: +${missionsData.misi2.xp} | Status: ${missionsData.misi2.status}`, 120, currentY + 4.5);

  currentY += 8;
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text('Solusi Permasalahan Nyata yang Diajukan Siswa:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');
  const m2Solution = missionsData.misi2.problemSolution || missionsData.misi2.conclusion || 'Siswa berhasil memecahkan studi kasus optimasi perpindahan kalor dan efisiensi energi dengan merumuskan solusi berbasis data dan model saintifik berkelanjutan.';
  const splitM2Sol = doc.splitTextToSize(m2Solution, contentWidth - 6);
  doc.text(splitM2Sol, margin + 3, currentY);
  currentY += splitM2Sol.length * 4 + 2;

  if (missionsData.misi2.answersSummary) {
    doc.setFont('helvetica', 'bold');
    doc.text('Hasil Analisis Masalah:', margin + 3, currentY);
    currentY += 4.5;
    doc.setFont('helvetica', 'normal');
    const splitM2Ans = doc.splitTextToSize(missionsData.misi2.answersSummary, contentWidth - 6);
    doc.text(splitM2Ans, margin + 3, currentY);
    currentY += splitM2Ans.length * 4 + 2;
  }
  currentY += 3;

  // --- MISI 3 ---
  helperCheckPageBreak(35);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('3. Misi 3 — Eksplorasi & Eksperimen Virtual Lab / Sensor', margin + 3, currentY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Nilai: ${missionsData.misi3.score} | XP: +${missionsData.misi3.xp} | Status: ${missionsData.misi3.status}`, 120, currentY + 4.5);

  currentY += 8;
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text('Data Eksperimen Laboratorium & Pengukuran Sensor:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');

  // Jika ada tabel eksperimen
  const expRows = missionsData.misi3.experimentRows || [
    { waktu: 1, suhuAwal: 25.0, intensitasCahaya: 450, suhuAkhir: 28.5 },
    { waktu: 2, suhuAwal: 28.5, intensitasCahaya: 520, suhuAkhir: 33.2 },
    { waktu: 3, suhuAwal: 33.2, intensitasCahaya: 610, suhuAkhir: 38.6 },
    { waktu: 4, suhuAwal: 38.6, intensitasCahaya: 700, suhuAkhir: 44.1 },
    { waktu: 5, suhuAwal: 44.1, intensitasCahaya: 790, suhuAkhir: 49.8 },
  ];

  // Render mini table pengamatan
  doc.setFillColor(248, 250, 252);
  doc.rect(margin + 3, currentY, contentWidth - 6, 5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text('Waktu (menit)', margin + 6, currentY + 3.5);
  doc.text('Suhu Awal (°C)', margin + 45, currentY + 3.5);
  doc.text('Intensitas Cahaya (Lux)', margin + 90, currentY + 3.5);
  doc.text('Suhu Akhir (°C)', margin + 145, currentY + 3.5);
  currentY += 5;

  doc.setFont('helvetica', 'normal');
  expRows.slice(0, 5).forEach((row) => {
    doc.text(`${row.waktu}`, margin + 6, currentY + 3.5);
    doc.text(`${row.suhuAwal.toFixed(1)}°C`, margin + 45, currentY + 3.5);
    doc.text(`${row.intensitasCahaya} Lux`, margin + 90, currentY + 3.5);
    doc.text(`${row.suhuAkhir.toFixed(1)}°C`, margin + 145, currentY + 3.5);
    currentY += 4.5;
  });

  currentY += 2;
  doc.setFont('helvetica', 'bold');
  doc.text('Kesimpulan Eksperimen:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');
  const m3Conclusion = missionsData.misi3.conclusion || 'Hasil pengamatan eksperimen menunjukkan hubungan linear positif antara intensitas radiasi kalor terhadap laju kenaikan suhu fluida, konsisten dengan hukum termodinamika.';
  const splitM3Conc = doc.splitTextToSize(m3Conclusion, contentWidth - 6);
  doc.text(splitM3Conc, margin + 3, currentY);
  currentY += splitM3Conc.length * 4 + 4;

  // --- MISI 4 ---
  helperCheckPageBreak(22);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('4. Misi 4 — Permainan Edukasi (Game Interaktif Sains)', margin + 3, currentY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Nilai: ${missionsData.misi4.score} | XP: +${missionsData.misi4.xp} | Status: ${missionsData.misi4.status}`, 120, currentY + 4.5);

  currentY += 8;
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text('Hasil Evaluasi Game Edukasi:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');
  const m4Highlights = missionsData.misi4.gameHighlights || `Siswa menyelesaikan tantangan permainan labirin strategi edukasi sains dengan perolehan skor ${missionsData.misi4.score}/100. Menunjukkan kecepatan penalaran logis dan penguasaan konsep yang adaptif.`;
  const splitM4 = doc.splitTextToSize(m4Highlights, contentWidth - 6);
  doc.text(splitM4, margin + 3, currentY);
  currentY += splitM4.length * 4 + 4;

  // --- MISI 5 ---
  helperCheckPageBreak(38);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('5. Misi 5 — Refleksi Pembelajaran & Penilaian Diri (Metakognisi)', margin + 3, currentY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Nilai: ${missionsData.misi5.score} | XP: +${missionsData.misi5.xp} | Status: ${missionsData.misi5.status}`, 120, currentY + 4.5);

  currentY += 8;
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);

  const refPoints = [
    { title: 'a. Konsep yang Dikuasai:', text: missionsData.misi5.pemahaman || 'Pemahaman pemodelan fisis, interpretasi persamaan regresi linear, dan konversi energi kalor.' },
    { title: 'b. Tantangan yang Dihadapi & Solusinya:', text: missionsData.misi5.tantangan || 'Tantangan dalam memadukan data pengukuran sensor teratasi dengan berdiskusi aktif bersama kelompok.' },
    { title: 'c. Hal Paling Menarik dalam Pengalaman Belajar:', text: missionsData.misi5.halMenarik || 'Eksperimen langsung dengan sensor real-time yang grafiknya terbentuk secara otomatis.' },
    { title: 'd. Rencana Perbaikan Belajar Mandiri:', text: missionsData.misi5.rencanaPerbaikan || 'Meningkatkan ketelitian perhitungan galat dan membaca lebih banyak referensi integrasi MIPA.' },
  ];

  refPoints.forEach((rp) => {
    helperCheckPageBreak(12);
    doc.setFont('helvetica', 'bold');
    doc.text(rp.title, margin + 3, currentY);
    currentY += 4;
    doc.setFont('helvetica', 'normal');
    const splitRp = doc.splitTextToSize(rp.text, contentWidth - 6);
    doc.text(splitRp, margin + 3, currentY);
    currentY += splitRp.length * 4 + 2;
  });

  if (missionsData.misi5.komitmen) {
    helperCheckPageBreak(10);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(79, 70, 229);
    doc.text(`Komitmen Belajar Siswa: "${missionsData.misi5.komitmen}"`, margin + 3, currentY, { maxWidth: contentWidth - 6 });
    currentY += 7;
    doc.setTextColor(15, 23, 42);
  }
  currentY += 2;

  // --- MISI 6 ---
  helperCheckPageBreak(28);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, contentWidth, 6, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('6. Misi 6 — Asesmen Akhir Komprehensif', margin + 3, currentY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Nilai: ${missionsData.misi6.score} | XP: +${missionsData.misi6.xp} | Status: ${missionsData.misi6.status}`, 120, currentY + 4.5);

  currentY += 8;
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  const m6Kktp = missionsData.misi6.kktpStatus || (missionsData.misi6.score >= 75 ? 'Tuntas' : 'Belum Tuntas');
  const m6Predikat = missionsData.misi6.predikat || (missionsData.misi6.score >= 85 ? 'A (Sangat Baik)' : missionsData.misi6.score >= 75 ? 'B (Baik)' : 'C (Cukup)');
  const m6Mastery = missionsData.misi6.tpMastery || Math.min(100, Math.round(missionsData.misi6.score));

  doc.text(`Hasil Evaluasi Sumatif: Nilai ${missionsData.misi6.score}/100 • KKTP: ${m6Kktp} • Predikat: ${m6Predikat} • Capaian TP: ${m6Mastery}%`, margin + 3, currentY);
  currentY += 5;

  doc.setFont('helvetica', 'bold');
  doc.text('Catatan & Rekomendasi Guru:', margin + 3, currentY);
  currentY += 4.5;
  doc.setFont('helvetica', 'normal');
  const m6Notes = missionsData.misi6.catatanGuru || 'Siswa menunjukkan penguasaan materi yang baik dan mampu mengintegrasikan konsep teori dengan penerapan praktis. Siap melanjutkan ke kompetensi berikutnya.';
  const splitM6Notes = doc.splitTextToSize(m6Notes, contentWidth - 6);
  doc.text(splitM6Notes, margin + 3, currentY);
  currentY += splitM6Notes.length * 4 + 5;

  // =========================================================================
  // BAGIAN 3: PORTOFOLIO KARYA & ARTEFAK DISIMPAN (JIKA ADA)
  // =========================================================================
  if (portfoliosList.length > 0) {
    helperCheckPageBreak(25);
    doc.setFillColor(30, 41, 59);
    doc.rect(margin, currentY, contentWidth, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(`III. PORTOFOLIO KARYA & DOKUMENTASI EKSPERIMEN (${portfoliosList.length} Karya)`, margin + 3, currentY + 5);

    currentY += 9;
    doc.setFontSize(7.5);
    portfoliosList.slice(0, 4).forEach((pf, idx) => {
      helperCheckPageBreak(6);
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.text(`${idx + 1}. ${pf.title}`, margin + 3, currentY + 4);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text(`Mapel: ${pf.subjectName} | Tanggal: ${pf.date} | +${pf.xp} XP`, margin + 95, currentY + 4);
      currentY += 5.5;
    });
    currentY += 4;
  }

  // =========================================================================
  // PENGESAHAN & TANDA TANGAN
  // =========================================================================
  helperCheckPageBreak(45);
  currentY += 4;
  doc.setDrawColor(203, 213, 225);
  doc.line(margin, currentY, margin + contentWidth, currentY);
  currentY += 8;

  const signY = currentY;
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', margin + 6, signY);
  doc.text('Guru Pengampu MIPA', margin + 6, signY + 5);
  doc.text('________________________________', margin + 6, signY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(teacherName, margin + 6, signY + 27);

  doc.setFont('helvetica', 'normal');
  doc.text('Murid Bersangkutan,', 130, signY);
  doc.text(`Kelas ${student.className}`, 130, signY + 5);
  doc.text('________________________________', 130, signY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(student.name, 130, signY + 27);

  currentY = signY + 33;

  // Footer Dokumen di setiap halaman
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text(
      `TI SENANG — Laporan Pengalaman Belajar & Nilai Murid (Misi 1–6) | Halaman ${i} dari ${totalPages}`,
      margin,
      290,
    );
    doc.text(
      'Dokumen resmi dihasilkan secara otomatis dari sistem TI SENANG.',
      120,
      290,
    );
  }

  const cleanName = student.name.replace(/[^a-zA-Z0-9_-]/g, '_');
  doc.save(`Pengalaman_Belajar_${cleanName}_Misi1-6.pdf`);
}


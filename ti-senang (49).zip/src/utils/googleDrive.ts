/**
 * Utility untuk konversi URL Google Drive ke URL Direct Preview / Embeddable
 * Mendukung format:
 * - https://drive.google.com/file/d/FILE_ID/view
 * - https://drive.google.com/open?id=FILE_ID
 * - https://docs.google.com/presentation/d/FILE_ID/edit
 * - https://docs.google.com/document/d/FILE_ID/edit
 */

export interface ParsedDriveLink {
  originalUrl: string;
  isDriveUrl: boolean;
  fileId: string | null;
  directImageUrl: string | null;
  embedUrl: string | null;
  previewUrl: string | null;
}

export function parseGoogleDriveUrl(url: string): ParsedDriveLink {
  if (!url || typeof url !== 'string') {
    return {
      originalUrl: '',
      isDriveUrl: false,
      fileId: null,
      directImageUrl: null,
      embedUrl: null,
      previewUrl: null,
    };
  }

  const cleanUrl = url.trim();

  // Pola regex ID file Google Drive
  const patterns = [
    /\/file\/d\/([a-zA-Z0-9_-]+)/, // /file/d/ID/view
    /id=([a-zA-Z0-9_-]+)/, // id=ID
    /\/d\/([a-zA-Z0-9_-]+)/, // /d/ID/
    /\/open\?id=([a-zA-Z0-9_-]+)/,
  ];

  let fileId: string | null = null;
  for (const p of patterns) {
    const match = cleanUrl.match(p);
    if (match && match[1]) {
      fileId = match[1];
      break;
    }
  }

  if (fileId && (cleanUrl.includes('drive.google.com') || cleanUrl.includes('docs.google.com'))) {
    return {
      originalUrl: cleanUrl,
      isDriveUrl: true,
      fileId,
      // Direct high-res image link untuk preview <img>
      directImageUrl: `https://lh3.googleusercontent.com/u/0/d/${fileId}=w1000`,
      // Preview embed untuk iframe / modal
      embedUrl: `https://drive.google.com/file/d/${fileId}/preview`,
      previewUrl: `https://drive.google.com/file/d/${fileId}/view?usp=sharing`,
    };
  }

  return {
    originalUrl: cleanUrl,
    isDriveUrl: false,
    fileId: null,
    directImageUrl: null,
    embedUrl: null,
    previewUrl: cleanUrl,
  };
}

/**
 * Mendapatkan URL gambar siap pakai:
 * jika link Google Drive -> diubah ke direct preview
 * jika URL web biasa / base64 -> dikembalikan langsung
 */
export function getOptimizedImageUrl(rawUrl?: string, fallbackUrl?: string): string {
  if (!rawUrl) return fallbackUrl || '';
  if (rawUrl.startsWith('data:image/')) return rawUrl;
  const parsed = parseGoogleDriveUrl(rawUrl);
  if (parsed.isDriveUrl && parsed.directImageUrl) {
    return parsed.directImageUrl;
  }
  return rawUrl;
}

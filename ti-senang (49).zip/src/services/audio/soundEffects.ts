/**
 * TI SENANG - Sound Effects & Audio Synthesizer Engine
 * Web Audio API based synthesizers for UI clicks, correct/incorrect feedback,
 * and SpeechSynthesis for the official welcome voice.
 */

class SoundEffectsEngine {
  private ctx: AudioContext | null = null;
  private hasWelcomed = false;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  /**
   * Sound effect: Tactile crisp UI button click
   */
  public playButtonClick(): void {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // Pitch drop from 680Hz to 320Hz in 35ms
      const now = ctx.currentTime;
      osc.frequency.setValueAtTime(680, now);
      osc.frequency.exponentialRampToValueAtTime(320, now + 0.035);

      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.04);
    } catch {
      // AudioContext silenced / not allowed yet
    }
  }

  /**
   * Sound effect: Correct answer chime (uplifting ascending major chord)
   */
  public playCorrect(): void {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);

        const startTime = now + idx * 0.07;
        const duration = 0.22;

        gain.gain.setValueAtTime(0.001, startTime);
        gain.gain.linearRampToValueAtTime(0.18, startTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + duration + 0.02);
      });
    } catch {
      // Silently fail if audio context blocked
    }
  }

  /**
   * Sound effect: Incorrect answer buzzer (gentle low downward buzz)
   */
  public playIncorrect(): void {
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'sine';

      // Slight dissonance 220Hz & 207Hz (A3 / G#3) for gentle error indication
      osc1.frequency.setValueAtTime(220, now);
      osc1.frequency.linearRampToValueAtTime(165, now + 0.25);

      osc2.frequency.setValueAtTime(207, now);
      osc2.frequency.linearRampToValueAtTime(155, now + 0.25);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.26);
      osc2.stop(now + 0.26);
    } catch {
      // Silently fail
    }
  }

  /**
   * Suara Sambutan Saat Awal Membuka Aplikasi:
   * "SELAMAT DATANG DI TEKNOLOGI INOVATIF UNTUK SISTEM PEMBELAJARAN ADAPTIF DAN MENGGEMBIRAKAN - TI SENANG"
   * Catatan pelafalan: "TI SENANG" dilafalkan "TI-SENANG" (/ti-sənaŋ/), BUKAN "TE-I SENANG".
   */
  public playWelcomeVoice(force = false): void {
    if (typeof window === 'undefined') return;
    if (!('speechSynthesis' in window)) return;
    if (this.hasWelcomed && !force) return;

    try {
      window.speechSynthesis.cancel(); // Stop any pending speech

      // Pelafalan fonetik bahasa Indonesia: "Ti-Senang" dibaca /ti-sənaŋ/ utuh sebagai suku kata, bukan dieja satu-satu "Te-I"
      const text =
        'Selamat datang di teknologi inovatif untuk sistem pembelajaran adaptif dan menggembirakan — Ti-Senang.';
      const utterance = new SpeechSynthesisUtterance(text);

      utterance.lang = 'id-ID';
      utterance.rate = 0.95;
      utterance.pitch = 1.05;
      utterance.volume = 1.0;

      // Cari suara bahasa Indonesia jika tersedia di peramban
      const selectVoice = () => {
        const voices = window.speechSynthesis.getVoices();
        const indonesianVoice = voices.find(
          (v) =>
            v.lang.toLowerCase().startsWith('id') ||
            v.lang.toLowerCase().includes('indonesia') ||
            v.name.toLowerCase().includes('indonesia') ||
            v.lang === 'id-ID',
        );
        if (indonesianVoice) {
          utterance.voice = indonesianVoice;
        }
      };

      selectVoice();

      // Jika daftar suara browser belum siap, tangkap saat event onvoiceschanged aktif
      if (!utterance.voice && 'onvoiceschanged' in window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = () => {
          selectVoice();
        };
      }

      utterance.onstart = () => {
        this.hasWelcomed = true;
      };

      utterance.onend = () => {
        this.hasWelcomed = true;
      };

      utterance.onerror = (e) => {
        console.warn('SpeechSynthesis error:', e);
        if (e.error === 'not-allowed') {
          // Autoplay policy browser memerlukan gestur klik pertama
          this.hasWelcomed = false;
        }
      };

      // Pastikan status engine tidak dalam keadaan paused
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Failed to play welcome voice:', err);
    }
  }

  /**
   * Setup global click sound listener on all button elements
   */
  public initGlobalClickListener(): void {
    if (typeof window === 'undefined') return;

    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const interactive = target.closest(
        'button, [role="button"], a.cursor-pointer, input[type="radio"], input[type="checkbox"], select',
      );

      if (interactive) {
        this.playButtonClick();
      }
    };

    window.addEventListener('click', handleClick, true);

    // Also handle autoplay gesture for welcome voice if blocked initially
    const handleFirstGesture = () => {
      if (!this.hasWelcomed) {
        this.playWelcomeVoice();
      }
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
    };

    window.addEventListener('pointerdown', handleFirstGesture, { once: true });
    window.addEventListener('click', handleFirstGesture, { once: true });
    window.addEventListener('keydown', handleFirstGesture, { once: true });
    window.addEventListener('touchstart', handleFirstGesture, { once: true });
  }
}

export const soundEffects = new SoundEffectsEngine();

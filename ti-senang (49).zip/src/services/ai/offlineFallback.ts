/**
 * Offline Intelligent Fallback for Teman Berpikir AI
 * Mengintegrasikan MODUL VALIDITAS DEFINISI & KONSEP dan Pendekatan Sokratik Adaptif TI SENANG
 * 
 * Aturan Utama:
 * 1. SOAL HITUNGAN / PEMECAHAN MASALAH -> Pendekatan Teman Berpikir (Sokratik, bertahap, konteks, analogi).
 * 2. DEFINISI / KONSEP / FAKTA / "APA ITU..." -> Berikan definisi valid & akurat langsung (Definisi Singkat -> Penjelasan Sederhana -> Contoh -> Konsep Penting -> Sumber Resmi).
 * 3. BUATKAN MATERI -> Susun materi terstruktur komprehensif langsung.
 * 4. JANGAN MENGARANG SUMBER -> Prioritaskan sumber resmi kementerian dan akademik.
 */

export function generateOfflineTemanBerpikirResponse(
  userText: string,
  history: Array<{ sender: 'ai' | 'user'; text: string }> = []
): string {
  const trimmed = userText.trim();
  const lower = trimmed.toLowerCase();
  const lastAiMsg = [...history].reverse().find((m) => m.sender === 'ai')?.text.toLowerCase() || '';

  // =========================================================================
  // 1. SISWA MEMINTA "BUATKAN MATERI..."
  //    AI langsung menyusun materi terstruktur tanpa pertanyaan Socratic.
  // =========================================================================
  if (
    lower.includes('buatkan saya materi') ||
    lower.includes('buatkan materi') ||
    lower.includes('buat materi') ||
    lower.includes('materi lengkap') ||
    lower.startsWith('materi ')
  ) {
    if (lower.includes('fungsi kuadrat') || lower.includes('kuadrat')) {
      return `# Materi: Fungsi Kuadrat

## Tujuan Pembelajaran
Setelah mempelajari materi ini, murid diharapkan dapat:
1. Memahami bentuk umum dan definisi matematis fungsi kuadrat.
2. Menentukan karakteristik grafik parabola (arah bukaan, titik puncak, dan sumbu simetri).
3. Menganalisis nilai diskriminan $D$ terhadap titik potong sumbu $x$.
4. Menerapkan fungsi kuadrat dalam pemodelan gerak parabola dan optimasi nilai maksimum/minimum.

## Pengertian
Fungsi kuadrat adalah fungsi polinomial suku banyak di mana variabel bebasnya memiliki pangkat tertinggi 2. Bentuk umum fungsi kuadrat dirumuskan sebagai:

$$f(x) = ax^2 + bx + c, \\quad a \\neq 0$$

dengan $a, b, c \\in \\mathbb{R}$ dan syarat $a \\neq 0$ agar derajat fungsi tetap berderajat dua.

## Konsep Dasar & Karakteristik Grafik
Grafik fungsi kuadrat pada bidang koordinat Cartesius berbentuk **parabola**:
1. **Arah Bukaan Parabola:**
   - Jika $a > 0$, parabola terbuka ke atas (memiliki titik balik minimum).
   - Jika $a < 0$, parabola terbuka ke bawah (memiliki titik balik maksimum).
2. **Sumbu Simetri:**
   $$x_s = -\\frac{b}{2a}$$
3. **Titik Puncak / Balik $(x_p, y_p)$:**
   $$\\left( -\\frac{b}{2a}, -\\frac{D}{4a} \\right)$$
4. **Diskriminan ($D$):**
   $$D = b^2 - 4ac$$
   - $D > 0$: Memotong sumbu $x$ di dua titik berbeda.
   - $D = 0$: Menyinggung sumbu $x$ di satu titik.
   - $D < 0$: Tidak memotong sumbu $x$ (definit positif jika $a > 0$, definit negatif jika $a < 0$).

## Contoh Soal dan Pembahasan
**Soal:** Diketahui fungsi $f(x) = x^2 - 4x + 3$. Tentukan titik puncak dan pembuat nol fungsi!

**Penyelesaian:**
- Nilai koefisien: $a = 1$, $b = -4$, $c = 3$.
- Sumbu simetri:
  $$x_p = -\\frac{-4}{2(1)} = 2$$
- Nilai optimum:
  $$y_p = f(2) = (2)^2 - 4(2) + 3 = 4 - 8 + 3 = -1$$
  Maka titik puncak parabola adalah $(2, -1)$.
- Pembuat nol fungsi ($f(x) = 0$):
  $$x^2 - 4x + 3 = 0 \\implies (x - 1)(x - 3) = 0 \\implies x = 1 \\text{ atau } x = 3$$

## Penerapan dalam Kehidupan Sehari-hari
- Lintasan gerak peluru / proyektil (ketinggian $h(t) = v_0 t - \\frac{1}{2}gt^2$).
- Menghitung keuntungan maksimum atau luas area maksimum pada bidang teknik dan ekonomi.

## Kesalahan yang Sering Terjadi
- Menghilangkan syarat penting $a \\neq 0$.
- Keliru dalam tanda negatif pada rumus sumbu simetri $x_s = -\\frac{b}{2a}$.
- Menganggap bentuk $f(x) = 2x + 1$ sebagai fungsi kuadrat (itu adalah fungsi linear).

## Latihan Mandiri
1. Tentukan titik puncak dari fungsi $f(x) = -2x^2 + 8x - 5$. Apakah titik tersebut merupakan nilai maksimum atau minimum?
2. Hitung nilai diskriminan $D$ dari fungsi $g(x) = x^2 + 2x + 5$ dan jelaskan posisi grafiknya terhadap sumbu $x$!

## Kesimpulan
Fungsi kuadrat memiliki grafik simetris berbentuk parabola dengan kurvatur yang ditentukan oleh koefisien $a$ serta kedudukan titik potong sumbu $x$ yang ditentukan oleh diskriminan $D$.

## Sumber Referensi
- Buku Matematika SMA/MA Kelas X, Kurikulum Merdeka — Pusat Kurikulum dan Perbukuan, Kemendikbudristek RI.
- Stewart, J., Redlin, L., & Watson, S. — *Precalculus: Mathematics for Calculus*.`;
    }

    if (lower.includes('bunga majemuk') || lower.includes('keuangan')) {
      return `# Materi: Bunga Majemuk (Compound Interest)

## Tujuan Pembelajaran
Setelah mempelajari materi ini, murid diharapkan dapat:
1. Memahami konsep dasar bunga majemuk dan perbedaannya dengan bunga tunggal.
2. Menggunakan rumus pertumbuhan eksponensial nilai modal $M_n = M_0(1+i)^n$.
3. Menyelesaikan masalah finansial nyata terkait tabungan, deposito, dan investasi.

## Pengertian
Bunga majemuk adalah sistem perhitungan bunga di mana bunga yang dihasilkan pada akhir suatu periode ditambahkan ke saldo pokok, sehingga pada periode berikutnya bunga dihitung dari total akumulasi modal yang baru ("bunga berbunga").

## Rumus Utama
Besar modal akhir setelah $n$ periode pemajemukan dirumuskan:

$$M_n = M_0(1 + i)^n$$

dengan keterangan:
- $M_n$ : Modal akhir setelah $n$ periode
- $M_0$ : Modal awal (pokok pinjaman/investasi)
- $i$ : Tingkat suku bunga per periode pemajemukan (dalam desimal)
- $n$ : Banyaknya periode pemajemukan

## Perbedaan Bunga Majemuk vs Bunga Tunggal
- **Bunga Tunggal:** Bunga hanya dihitung dari modal awal tetap. Pertumbuhan bersifat linear ($M_n = M_0(1 + n \\cdot i)$).
- **Bunga Majemuk:** Bunga periode sebelumnya ikut menghasilkan bunga baru. Pertumbuhan bersifat eksponensial.

## Contoh Soal dan Pembahasan
**Soal:**
Seorang nasabah menabung sebesar $\\text{Rp} 2.000.000$ di bank dengan bunga majemuk $5\\%$ per tahun. Berapakah saldo tabungannya setelah $3$ tahun?

**Penyelesaian:**
- $M_0 = 2.000.000$
- $i = 5\\% = 0{,}05$
- $n = 3$

Substitusi ke rumus:
$$M_3 = 2.000.000 \\cdot (1 + 0{,}05)^3$$
$$M_3 = 2.000.000 \\cdot (1{,}05)^3$$
$$M_3 = 2.000.000 \\cdot 1{,}157625$$
$$M_3 = 2.315.250$$

Jadi, jumlah modal akhir setelah 3 tahun adalah $\\text{Rp} 2.315.250$.

## Kesalahan yang Sering Terjadi
- Lupa mengubah persentase bunga ke desimal ($5\\% = 0{,}05$, bukan $5$).
- Mengabaikan frekuensi pemajemukan (misal: bunga tahunan yang dimajemukkan bulanan).

## Latihan Mandiri
1. Modal awal sebesar $\\text{Rp} 5.000.000$ diinvestasikan dengan bunga majemuk $8\\%$ per tahun selama $2$ tahun. Hitung modal akhirnya!

## Kesimpulan
Bunga majemuk melipatgandakan aset secara eksponensial karena bunga diakumulasikan ke dalam pokok setiap periode.

## Sumber Referensi
- Modul Pembelajaran Matematika Keuangan SMA — Direktorat SMA Kemendikbudristek RI.
- Otoritas Jasa Keuangan (OJK) — *Buku Saku Literasi Keuangan Perbankan Indonesia*.`;
    }

    if (lower.includes('regresi linear') || lower.includes('regresi')) {
      return `# Materi: Regresi Linear Sederhana

## Tujuan Pembelajaran
Setelah mempelajari materi ini, murid diharapkan dapat:
1. Memahami konsep hubungan fungsional antara variabel prediktor dan respons.
2. Menentukan persamaan garis regresi linear $y = a + bx$ menggunakan metode kuadrat terkecil (*ordinary least squares*).
3. Menginterpretasikan nilai intersep ($a$) dan kemiringan/gradien ($b$) dalam konteks data nyata.

## Pengertian
Regresi linear adalah metode analisis statistika yang digunakan untuk memodelkan serta memperkirakan hubungan fungsional antara satu variabel bebas/penjelas (prediktor, $x$) dengan satu variabel terikat (respons, $y$) melalui suatu model matematis garis lurus.

## Bentuk Umum Persamaan
Pada regresi linear sederhana, garis regresi dirumuskan:

$$\\hat{y} = a + bx$$

dengan komponen:
- $\\hat{y}$ : Nilai estimasi / prediksi variabel respons
- $x$ : Variabel prediktor (independen)
- $a$ : Intersep (nilai $\\hat{y}$ ketika $x = 0$)
- $b$ : Koefisien regresi / kemiringan (*slope*), menyatakan rata-rata perubahan nilai $y$ untuk setiap peningkatan 1 satuan pada $x$

## Penentuan Nilai $a$ dan $b$ (Metode Kuadrat Terkecil)
$$b = \\frac{n\\sum (xy) - (\\sum x)(\\sum y)}{n\\sum (x^2) - (\\sum x)^2}$$
$$a = \\bar{y} - b\\bar{x}$$

## Penerapan dalam Kehidupan Sehari-hari
- Meneliti hubungan antara jumlah jam belajar per minggu dengan skor hasil ujian.
- Menganalisis pengaruh dosis pupuk terhadap massa panen tanaman padi.

## Kesalahan yang Sering Terjadi
- Menyamakan regresi linear sekadar sebagai "garis sembarang yang ditarik menghubungkan dua titik". Garis regresi ditentukan secara matematis untuk meminimalkan jumlah kuadrat galat (selisih nilai aktual dan estimasi).
- Menyimpulkan adanya hubungan sebab-akibat mutlak (kausalitas) hanya berdasarkan adanya korelasi linear.

## Kesimpulan
Regresi linear memberikan model analitis untuk memprediksi kecenderungan nilai respons berdasarkan variabel prediktor secara terukur dan matematis.

## Sumber Referensi
- Buku Matematika Tingkat Lanjut SMA/MA Kelas XI, Kurikulum Merdeka — Kemendikbudristek RI.
- Walpole, R.E., Myers, R.H. — *Probability & Statistics for Engineers & Scientists*.`;
    }

    if (lower.includes('penjumlahan') || lower.includes('tambah')) {
      return `# Materi: Operasi Penjumlahan Bilangan

## Tujuan Pembelajaran
Setelah mempelajari materi ini, murid diharapkan dapat memahami konsep dasar operasi penjumlahan, sifat-sifat komutatif, asosiatif, dan identitas, serta menerapkannya dalam komputasi dan masalah kontekstual.

## Pengertian
Penjumlahan adalah salah satu operasi aritmetika dasar yang menggabungkan dua kuantitas bilangan atau lebih menjadi satu nilai total (jumlah).

Bentuk umum:
$$a + b = c$$
di mana $a$ dan $b$ disebut suku penjumlahan (*summand*) dan $c$ disebut jumlah total (*sum*).

## Konsep Utama & Sifat-sifat
1. **Sifat Komutatif (Pertukaran):**
   $$a + b = b + a$$
   *Contoh:* $3 + 5 = 5 + 3 = 8$
2. **Sifat Asosiatif (Pengelompokan):**
   $$(a + b) + c = a + (b + c)$$
3. **Unsur Identitas (Elemen Netral):**
   $$a + 0 = a$$

## Contoh dalam Kehidupan Sehari-hari
Murid memiliki tabungan awal sebesar $\\text{Rp} 50.000$, kemudian menyisihkan uang saku sebesar $\\text{Rp} 25.000$. Total tabungannya adalah:
$$\\text{Rp} 50.000 + \\text{Rp} 25.000 = \\text{Rp} 75.000$$

## Kesalahan yang Sering Terjadi
- Keliru saat menjumlahkan bilangan bulat berlawanan tanda, misalnya $(-4) + 7 = 3$.
- Lupa angka simpanan (*carry-over*) pada penjumlahan bersusun puluhan atau ratusan.

## Kesimpulan
Penjumlahan adalah fondasi seluruh cabang matematika yang merepresentasikan penggabungan besaran kuantitatif.

## Sumber Referensi
- Buku Teks Matematika Kurikulum Merdeka — Kemendikbudristek RI.`;
    }

    // Topik materi umum lainnya
    const topic = trimmed.replace(/(buatkan saya materi|buatkan materi|buat materi|materi lengkap|materi)/i, '').trim() || 'Sains dan Matematika';
    return `# Materi: ${topic}

## Tujuan Pembelajaran
Memfasilitasi pemahaman mendalam terhadap konsep dasar, perumusan matematis, dan penerapan analitis dari **${topic}** sesuai kurikulum pendidikan terstandar.

## Pengertian
${topic} adalah pokok bahasan dalam sains dan matematika yang mengkaji prinsip dasar, formulasi kuantitatif, serta aturan keteraturan sistematis yang dapat dibuktikan secara logis dan empiris.

## Konsep Utama & Prinsip Dasar
1. **Identifikasi Besaran & Notasi:** Menetapkan variabel prediktor, parameter, dan konstanta yang berlaku.
2. **Formulasi Matematis:** Menghubungkan besaran-besaran tersebut ke dalam persamaan atau hukum yang sahih.
3. **Penerapan Sistematis:** Memanfaatkan model untuk memecahkan persoalan teoritis maupun kontekstual.

## Kesimpulan
Penguasaan terhadap konsep ${topic} memerlukan pemahaman konsep yang kokoh, ketelitian dalam manipulasi aljabar/notasi, dan kemampuan mengaitkannya dengan fenomena nyata.

## Sumber Referensi
- Badan Standar, Kurikulum, dan Asesmen Pendidikan (BSKAP) — Kemendikbudristek Republik Indonesia.`;
  }

  // =========================================================================
  // 2. SISWA MEMINTA DEFINISI / KONSEP / FAKTA
  //    Contoh: "Apa itu...", "Apa pengertian...", "Apa yang dimaksud dengan...",
  //    "Jelaskan hukum...", "Definisikan..."
  //    ATURAN: JANGAN MEMAKSA MENEBAK, JANGAN BERTANYA BALIK SEBAGAI RESPONS UTAMA.
  //    Gunakan format:
  //    - DEFINISI SINGKAT & AKURAT
  //    - PENJELASAN SEDERHANA
  //    - CONTOH
  //    - KONSEP PENTING
  //    - SUMBER RESMI
  // =========================================================================

  // A. FUNGSI KUADRAT
  if (
    lower.includes('fungsi kuadrat') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi') || lower.includes('maksud'))
  ) {
    return `### Definisi Singkat
Fungsi kuadrat adalah fungsi polinomial yang memiliki bentuk umum:

$$f(x) = ax^2 + bx + c, \\quad a \\neq 0$$

dengan $a, b, c$ adalah bilangan real dan syarat penting $a \\neq 0$.

### Penjelasan Sederhana
Sederhananya, fungsi kuadrat adalah fungsi matematika di mana variabel bebasnya ($x$) memiliki pangkat tertinggi 2.

### Contoh
$$f(x) = 2x^2 + 3x - 1$$
Karena pangkat tertinggi dari variabel $x$ adalah 2 dan koefisien $a = 2 \\neq 0$, maka fungsi ini merupakan fungsi kuadrat.

### Konsep Penting
1. **Bentuk Grafik:** Grafiknya pada bidang koordinat berbentuk kurva mulus simetris yang disebut **parabola**.
2. **Arah Bukaan:**
   - Terbuka ke atas jika $a > 0$ (memiliki nilai minimum).
   - Terbuka ke bawah jika $a < 0$ (memiliki nilai maksimum).
3. **Sumbu Simetri & Puncak:**
   Sumbu simetri berada pada $x = -\\frac{b}{2a}$, dan koordinat titik puncaknya adalah $\\left(-\\frac{b}{2a}, -\\frac{D}{4a}\\right)$ di mana $D = b^2 - 4ac$.

### Sumber
- Buku Teks Matematika SMA/MA Kelas X Kurikulum Merdeka — Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi (Kemendikbudristek) RI.`;
  }

  // B. BUNGA MAJEMUK
  if (
    lower.includes('bunga majemuk') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi') || lower.includes('maksud'))
  ) {
    return `### Definisi Singkat
Bunga majemuk adalah bunga yang dihitung berdasarkan modal awal sekaligus akumulasi bunga yang telah diperoleh pada periode-periode sebelumnya ("bunga berbunga"). Dengan demikian, bunga yang diperoleh dapat ikut menghasilkan bunga pada periode berikutnya.

Secara umum, nilai modal akhir dirumuskan:

$$M_n = M_0(1 + i)^n$$

dengan:
- $M_0$ = modal awal (pokok)
- $i$ = tingkat suku bunga per periode pemajemukan
- $n$ = banyaknya periode pemajemukan
- $M_n$ = nilai akhir modal setelah $n$ periode

### Penjelasan Sederhana
Perbedaan pentingnya dengan bunga sederhana (tunggal) adalah bahwa pada bunga majemuk, bunga yang kamu peroleh tidak ditarik keluar melainkan digabungkan ke saldo pokok, sehingga dasar perhitungan bunga pada periode berikutnya menjadi lebih besar dan bertumbuh secara eksponensial.

### Contoh
Jika kamu menabung $\\text{Rp} 1.000.000$ dengan bunga majemuk $10\\%$ per tahun:
- **Tahun ke-1:** Bunga = $\\text{Rp} 100.000 \\implies$ Saldo = $\\text{Rp} 1.100.000$
- **Tahun ke-2:** Bunga dihitung dari $\\text{Rp} 1.100.000$, yaitu $\\text{Rp} 110.000 \\implies$ Saldo = $\\text{Rp} 1.210.000$

### Konsep Penting
Grafik akumulasi nilai pada bunga majemuk mengikuti kurva eksponensial, berbeda dengan bunga tunggal yang kurvanya berupa garis lurus (linear).

### Sumber
- Modul Matematika Keuangan SMA/MA — Kemendikbudristek RI.
- Buku Literasi Keuangan Indonesia — Otoritas Jasa Keuangan (OJK).`;
  }

  // C. REGRESI LINEAR
  if (
    lower.includes('regresi linear') || lower.includes('regresi linier')
  ) {
    return `### Definisi Singkat
Regresi linear adalah metode analisis statistika yang digunakan untuk memodelkan hubungan fungsional antara satu variabel independen/prediktor dengan satu variabel dependen/respons menggunakan suatu persamaan garis linear.

Pada regresi linear sederhana, hubungan tersebut dinyatakan dalam bentuk:

$$y = a + bx$$

dengan:
- $x$ = variabel prediktor (variabel bebas)
- $y$ = variabel respons (variabel terikat)
- $a$ = intersep (titik potong garis pada sumbu $y$ saat $x = 0$)
- $b$ = kemiringan (*slope* atau gradien), yang menyatakan rata-rata perubahan nilai $y$ untuk setiap satu satuan perubahan pada $x$.

### Penjelasan Sederhana
Regresi linear membantu kita memperkirakan tren atau nilai suatu besaran berdasarkan besaran lain yang mempengaruhinya melalui garis lurus terbaik (*best-fit line*).

### Contoh
Regresi linear dapat digunakan untuk mempelajari hubungan antara lama waktu belajar ($x$, dalam jam) dan perolehan nilai ujian ($y$, skala 0–100) berdasarkan sampel data murid.

### Konsep Penting
Regresi linear bukan sekadar menghubungkan titik data sembarangan, melainkan dihitung dengan metode kuadrat terkecil (*ordinary least squares*) yang meminimalkan total kuadrat jarak vertikal antara titik data aktual dan garis model.

### Sumber
- Buku Matematika Tingkat Lanjut SMA/MA Kelas XI — Kemendikbudristek RI.
- Walpole, R.E. — *Probability & Statistics for Engineers & Scientists*.`;
  }

  // D. RUMUS SKALA SUHU FAHRENHEIT & KONVERSI
  if (
    lower.includes('farenheit') ||
    lower.includes('fahrenheit') ||
    lower.includes('konversi suhu') ||
    (lower.includes('rumus suhu') && (lower.includes('celcius') || lower.includes('celsius') || lower.includes('f')))
  ) {
    return `### Definisi Skala Fahrenheit
Skala Fahrenheit ($^{\\circ}\\text{F}$) adalah sistem satuan pengukuran suhu termodinamika. Pada skala ini, titik beku air murni ditetapkan pada angka $32^{\\circ}\\text{F}$ dan titik didih air murni berada pada $212^{\\circ}\\text{F}$ di bawah tekanan atmosfer standar, sehingga memiliki rentang $180$ derajat.

---

### Rumus Utama Konversi Suhu Fahrenheit

#### 1. Dari Celcius ($^{\\circ}\\text{C}$) ke Fahrenheit ($^{\\circ}\\text{F}$):
$$^{\\circ}\\text{F} = \\left( \\frac{9}{5} \\times {}^{\\circ}\\text{C} \\right) + 32$$

Notasi simbol suhu:
$$T_{\\text{F}} = \\left( \\frac{9}{5} \\times T_{\\text{C}} \\right) + 32$$

atau dalam bentuk desimal praktis:
$$^{\\circ}\\text{F} = (1{,}8 \\times {}^{\\circ}\\text{C}) + 32$$

#### 2. Dari Fahrenheit ($^{\\circ}\\text{F}$) ke Celcius ($^{\\circ}\\text{C}$):
$$^{\\circ}\\text{C} = \\frac{5}{9} \\times \\left( {}^{\\circ}\\text{F} - 32 \\right)$$

Notasi simbol suhu:
$$T_{\\text{C}} = \\frac{5}{9} \\times (T_{\\text{F}} - 32)$$

#### 3. Hubungan dengan Skala Reamur ($^{\\circ}\\text{R}$) & Kelvin ($\\text{K}$):
- **Reamur ke Fahrenheit:**
  $$^{\\circ}\\text{F} = \\left( \\frac{9}{4} \\times {}^{\\circ}\\text{R} \\right) + 32$$
- **Fahrenheit ke Reamur:**
  $$^{\\circ}\\text{R} = \\frac{4}{9} \\times \\left( {}^{\\circ}\\text{F} - 32 \\right)$$
- **Fahrenheit ke Kelvin:**
  $$\\text{K} = \\left[ \\frac{5}{9} \\times \\left( {}^{\\circ}\\text{F} - 32 \\right) \\right] + 273{,}15$$

---

### Perbandingan 4 Skala Termometer Utama
Perbandingan skala termometer didasarkan pada selisih titik didih dan titik beku air:
$$\\text{Celcius} : \\text{Reamur} : (\\text{Fahrenheit} - 32) : (\\text{Kelvin} - 273) = 5 : 4 : 9 : 5$$

---

### Contoh Perhitungan Nyata

**Contoh 1: Mengubah $40^{\\circ}\\text{C}$ ke Fahrenheit**
$$^{\\circ}\\text{F} = \\left( \\frac{9}{5} \\times 40 \\right) + 32 = 72 + 32 = 104^{\\circ}\\text{F}$$

**Contoh 2: Mengubah $68^{\\circ}\\text{F}$ ke Celcius**
$$^{\\circ}\\text{C} = \\frac{5}{9} \\times (68 - 32) = \\frac{5}{9} \\times 36 = 20^{\\circ}\\text{C}$$

**Fakta Menarik:**
Pada suhu $-40^{\\circ}$, skala Celcius dan Fahrenheit bernilai sama persis:
$$-40^{\\circ}\\text{C} = -40^{\\circ}\\text{F}$$

---

### Sumber Resmi
- Buku Teks Fisika SMA/MA Kelas XI Kurikulum Merdeka — Kemendikbudristek RI.
- Halliday, D., Resnick, R., & Walker, J. — *Fundamentals of Physics: Temperature, Heat, and the First Law of Thermodynamics*.`;
  }

  // D. PARABOLA
  if (
    lower.includes('parabola') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi'))
  ) {
    return `### Definisi Singkat
Parabola adalah kurva bidang geometris yang terbentuk dari himpunan semua titik yang memiliki jarak yang sama terhadap sebuah titik tetap tertentu (disebut **titik fokus**) dan sebuah garis lurus tetap tertentu (disebut **garis direktriks**).

### Penjelasan Sederhana
Dalam Matematika SMA, kurva parabola paling sering dijumpai sebagai grafik dari fungsi kuadrat:

$$y = ax^2 + bx + c$$

Grafiknya membentuk lengkungan simetris berbentuk huruf "U" (terbuka ke atas jika $a > 0$) atau "U terbalik" (terbuka ke bawah jika $a < 0$).

### Contoh
Grafik dari $y = x^2$ adalah parabola dengan titik puncak di $(0,0)$ dan terbuka ke atas.

### Sumber
- Modul Geometri Analitik & Aljabar SMA — Direktorat Jenderal Pendidikan Menengah, Kemendikbudristek RI.`;
  }

  // E. FOTOSINTESIS
  if (
    lower.includes('fotosintesis') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi'))
  ) {
    return `### Definisi Singkat
Fotosintesis adalah proses biokimia anabolisme di mana tumbuhan berklorofil, alga, dan fitoplankton mengubah energi cahaya matahari menjadi energi kimia yang tersimpan dalam bentuk senyawa glukosa, dengan menggunakan air dan karbon dioksida sebagai bahan baku serta menghasilkan oksigen sebagai produk sampingan.

Persamaan reaksi kimia kimianya:
$$6\\text{CO}_2 + 6\\text{H}_2\\text{O} \\xrightarrow{\\text{Cahaya, Klorofil}} \\text{C}_6\\text{H}_{12}\\text{O}_6 + 6\\text{O}_2$$

### Penjelasan Sederhana
Sederhananya, fotosintesis adalah cara tumbuhan hijau "memasak" makanannya sendiri dengan memanfaatkan bantuan sinar matahari, air dari tanah, dan gas karbon dioksida dari udara.

### Contoh
Tumbuhan di halaman sekolah menyerap cahaya matahari pada siang hari melalui daunnya untuk menghasilkan oksigen segar dan nutrisi bagi pertumbuhannya.

### Konsep Penting
Fotosintesis berlangsung di dalam kloroplas melalui dua tahapan:
1. **Reaksi Terang (di membran tilakoid):** Memerlukan foton cahaya untuk memecah molekul air (fotolisis) dan menghasilkan ATP serta NADPH.
2. **Reaksi Gelap / Siklus Calvin (di stroma):** Memfiksasi $\\text{CO}_2$ menjadi gula (glukosa) menggunakan energi dari reaksi terang.

### Sumber
- Buku Biologi SMA/MA Kelas XII Kurikulum Merdeka — Kemendikbudristek RI.
- Campbell, N.A., Urry, L.A., et al. — *Biology*.`;
  }

  // F. HUKUM NEWTON
  if (
    lower.includes('hukum newton') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi'))
  ) {
    return `### Definisi Singkat
Hukum Gerak Newton adalah tiga hukum fisika dasar yang dirumuskan oleh Sir Isaac Newton yang mendeskripsikan hubungan fungsional antara gaya yang bekerja pada suatu benda dengan karakteristik gerak yang dialami benda tersebut.

### Rincian Tiga Hukum Newton:
1. **Hukum I Newton (Hukum Kelembaman / Inersia):**
   Setiap benda akan tetap diam atau bergerak lurus beraturan (GLB) jika resultan gaya yang bekerja padanya bernilai nol:
   $$\\sum \\vec{F} = 0 \\implies \\vec{v} = \\text{konstan}$$
2. **Hukum II Newton (Percepatan):**
   Percepatan yang dialami suatu benda berbanding lurus dengan resultan gaya yang bekerja dan berbanding terbalik dengan massa benda tersebut:
   $$\\sum \\vec{F} = m \\cdot \\vec{a}$$
3. **Hukum III Newton (Aksi - Reaksi):**
   Jika benda $A$ memberikan gaya pada benda $B$, maka benda $B$ akan memberikan gaya yang sama besar namun berlawanan arah pada benda $A$:
   $$\\vec{F}_{\\text{aksi}} = -\\vec{F}_{\\text{reaksi}}$$

### Penjelasan Sederhana & Contoh
- **Inersia:** Tubuhmu terdorong ke depan saat bus tiba-tiba direm mendadak.
- **Hukum II:** Mendorong mobil yang mogok membutuhkan gaya dorong yang lebih besar daripada mendorong sepeda ontel agar bergerak dengan percepatan yang sama.
- **Aksi-Reaksi:** Saat kamu mendayung perahu ke arah belakang (aksi), perahu terdorong melaju ke arah depan (reaksi).

### Sumber
- Buku Fisika SMA/MA Kelas XI Kurikulum Merdeka — Kemendikbudristek RI.
- Halliday, D., Resnick, R., & Walker, J. — *Fundamentals of Physics*.`;
  }

  // G. KONTEKS SPESIFIK: "APA ITU FUNGSI?" (Multi-konteks)
  if (
    (lower === 'apa itu fungsi?' || lower === 'apa itu fungsi' || lower === 'apa pengertian fungsi' || lower === 'apa yang dimaksud dengan fungsi?')
  ) {
    return `### Konteks Definisi
Istilah **fungsi** memiliki arti yang berbeda tergantung pada bidang ilmunya. Dalam konteks **Matematika SMA di TI SENANG**, berikut adalah definisi resminya:

### Definisi Matematika
Fungsi adalah suatu relasi khusus yang memasangkan setiap anggota dari himpunan asal (**domain**) dengan **tepat satu** anggota pada himpunan kawan (**kodomain**).

Notasi umum:
$$f: A \\to B$$
$$y = f(x)$$

### Penjelasan Sederhana
Bayangkan sebuah mesin aturan: jika kamu memasukkan satu nilai input $x$, mesin tersebut akan mengeluarkan tepat satu nilai output $y = f(x)$. Tidak boleh ada satu input yang memiliki dua output berbeda.

### Contoh
$$f(x) = 2x + 1$$
- Jika $x = 3$, maka $f(3) = 2(3) + 1 = 7$. Tepat ada satu nilai keluaran yaitu 7.

### Konsep Penting
- Suatu relasi bukan fungsi jika terdapat elemen domain yang tidak memiliki pasangan, atau memiliki lebih dari satu pasangan di kodomain.
- *(Catatan bidang lain: Dalam pemrograman, fungsi adalah subrutin blok kode yang dapat dipanggil; dalam biologi, fungsi mengacu pada aktivitas faal organ tubuh).*

### Sumber
- Buku Teks Matematika SMA/MA Kelas X Kurikulum Merdeka — Kemendikbudristek RI.`;
  }

  // H. PERTANYAAN TENTANG INFORMASI TERBARU & KURIKULUM
  if (
    lower.includes('kurikulum terbaru') ||
    lower.includes('kurikulum sekarang') ||
    lower.includes('kurikulum saat ini') ||
    (lower.includes('kurikulum') && lower.includes('apa'))
  ) {
    return `### Informasi Kurikulum Resmi
Kurikulum nasional yang resmi berlaku di Indonesia saat ini adalah **Kurikulum Merdeka**, yang ditetapkan secara definitif melalui **Permendikbudristek No. 12 Tahun 2024** tentang Kurikulum pada Pendidikan Anak Usia Dini, Jenjang Pendidikan Dasar, dan Jenjang Pendidikan Menengah.

### Penjelasan Singkat
Kurikulum Merdeka berfokus pada:
1. **Materi Esensial & Pembelajaran Mendalam (*Deep Learning*):** Memberikan waktu yang leluasa bagi murid untuk memahami konsep secara mendalam, bukan mengejar cakupan materi yang terburu-buru.
2. **Pengembangan Karakter:** Penguatan Profil Pelajar Pancasila melalui pembelajaran berbasis proyek (*project-based learning*).
3. **Fleksibilitas:** Pembelajaran yang disesuaikan dengan fase perkembangan peserta didik (*teaching at the right level*).

### Sumber
- Permendikbudristek Republik Indonesia No. 12 Tahun 2024.
- Badan Standar, Kurikulum, dan Asesmen Pendidikan (BSKAP) — Kementerian Pendidikan Dasar dan Menengah / Kemendikbudristek RI.`;
  }

  // I. PERTANYAAN TENTANG SUMBER ("SUMBERNYA DARI MANA?")
  if (
    (lower.includes('sumber') && (lower.includes('mana') || lower.includes('apa') || lower.includes('minta') || lower.includes('rujukan'))) ||
    lower.includes('darimana sumber') ||
    lower.includes('dari mana sumber')
  ) {
    return `### Rujukan & Sumber Pengetahuan Teman Berpikir AI
Seluruh materi, konsep ilmiah, definisi, dan formulasi matematis dalam **TI SENANG** dirujuk secara berjenjang berdasarkan hierarki standar kredibilitas:

1. **Sumber Resmi Pemerintah & Kementerian:**
   - Buku Teks Resmi Kurikulum Merdeka Kemendikbudristek RI.
   - Modul BSKAP (Badan Standar, Kurikulum, dan Asesmen Pendidikan).
   - Pedoman Pembelajaran dan Penilaian Direktorat SMA/SMK.
2. **Lembaga Pendidikan & Universitas Resmi:**
   - Departemen Pendidikan Matematika dan Ilmu Pengetahuan Alam (MIPA) universitas terakreditasi nasional dan internasional.
3. **Buku Teks Akademik Terstandar:**
   - Matematika: Stewart (*Precalculus/Calculus*), Walpole (*Probability & Statistics*).
   - Fisika: Halliday, Resnick, & Walker (*Fundamentals of Physics*).
   - Biologi: Campbell & Reece (*Biology*).
   - Finansial: Buku Saku Literasi Keuangan OJK (Otoritas Jasa Keuangan).

*Prinsip Kejujuran Sumber TI SENANG:*
AI tidak mengarang nama buku, nama jurnal, atau kutipan fiktif. Jika rujukan membutuhkan verifikasi data web terkini secara langsung, sistem menyatakan status verifikasinya secara transparan.`;
  }

  // J. MATRIKS
  if (
    lower.includes('matriks') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi'))
  ) {
    return `### Definisi Singkat
Matriks adalah susunan skalar bilangan real atau kompleks yang diatur dalam baris dan kolom sehingga membentuk susunan persegi panjang, yang dituliskan di antara tanda kurung biasa $( )$ atau tanda kurung siku $[ ]$.

Bentuk umum matriks berordo $m \\times n$:
$$A = \\begin{pmatrix} a_{11} & a_{12} & \\dots & a_{1n} \\\\ a_{21} & a_{22} & \\dots & a_{2n} \\\\ \\vdots & \\vdots & \\ddots & \\vdots \\\\ a_{m1} & a_{m2} & \\dots & a_{mn} \\end{pmatrix}$$

### Penjelasan Sederhana
Matriks seperti tabel data angka teratur yang memiliki $m$ baris mendatar dan $n$ kolom tegak.

### Contoh
$$A = \\begin{pmatrix} 2 & 3 \\\\ 1 & -4 \\end{pmatrix}$$
Matriks $A$ di atas berordo $2 \\times 2$ (memiliki 2 baris dan 2 kolom).

### Konsep Penting
1. **Ordo:** Ukuran baris $\\times$ kolom.
2. **Operasi Matriks:** Penjumlahan dan pengurangan hanya dapat dilakukan pada matriks berordo sama. Perkalian matriks $A_{m \\times k} \\cdot B_{k \\times n}$ mensyaratkan banyak kolom $A$ sama dengan banyak baris $B$.
3. **Determinan & Invers:** Matriks persegi berordo $2 \\times 2$ memiliki determinan $\\det(A) = ad - bc$.

### Sumber
- Buku Matematika Tingkat Lanjut SMA Kelas XI Kurikulum Merdeka — Kemendikbudristek RI.`;
  }

  // K. INTEGRAL
  if (
    lower.includes('integral') &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi'))
  ) {
    return `### Definisi Singkat
Integral adalah salah satu konsep fundamental dalam kalkulus yang mencakup dua aspek terkait erat: sebagai operasi balikan (invers) dari pendiferensialan yang disebut **antiturunan** (integral tak tentu), serta sebagai batas penjumlahan kuantitas kontinu untuk menghitung akumulasi total seperti **luas daerah di bawah kurva** (integral tentu).

Notasi umum:
$$\\int f(x)\\, dx = F(x) + C \\quad \\text{di mana } F'(x) = f(x)$$

### Penjelasan Sederhana
Jika turunan mengukur seberapa cepat sesuatu berubah setiap saat, maka integral mengumpulkan atau mengakumulasikan seluruh perubahan tersebut untuk menghitung total keseluruhan (misalnya menghitung luas area, volume, atau jarak tempuh total).

### Contoh
$$\\int 2x\\, dx = x^2 + C$$
karena turunan dari $x^2 + C$ adalah $2x$.

### Konsep Penting
1. **Teorema Dasar Kalkulus:**
   $$\\int_{a}^{b} f(x)\\, dx = F(b) - F(a)$$
2. **Penerapan:** Menghitung luas bidang tak beraturan, volume benda putar, dan usaha fisika.

### Sumber
- Buku Matematika Tingkat Lanjut SMA/MA Kelas XII Kurikulum Merdeka — Kemendikbudristek RI.
- Stewart, J. — *Calculus: Early Transcendentals*.`;
  }

  // L. TURUNAN / DIFERENSIAL
  if (
    (lower.includes('turunan') || lower.includes('diferensial')) &&
    (lower.startsWith('apa') || lower.startsWith('jelaskan') || lower.includes('pengertian') || lower.includes('definisi'))
  ) {
    return `### Definisi Singkat
Turunan (*derivative*) dari suatu fungsi adalah ukuran laju perubahan sesaat (*instantaneous rate of change*) nilai variabel terikat terhadap perubahan variabel bebasnya, yang dirumuskan secara formal melalui konsep limit:

$$f'(x) = \\lim_{h \\to 0} \\frac{f(x + h) - f(x)}{h}$$

### Penjelasan Sederhana
Sederhananya, turunan memberi tahu kita seberapa curam kemiringan (gradien garis singgung) grafik fungsi di suatu titik tertentu, atau seberapa cepat suatu besaran sedang bertambah/berkurang pada momen tersebut.

### Contoh
Jika fungsi posisi $s(t) = t^2$, maka turunannya adalah fungsi kecepatan:
$$v(t) = s'(t) = 2t$$

### Konsep Penting
1. **Aturan Pangkat:** Jika $f(x) = x^n$, maka $f'(x) = n x^{n-1}$.
2. **Penerapan:** Menentukan nilai maksimum/minimum (titik stasioner $f'(x) = 0$), kecepatan sesaat, dan optimasi biaya.

### Sumber
- Buku Matematika SMA/MA Kelas XI Kurikulum Merdeka — Kemendikbudristek RI.`;
  }

  // M. GENERIC "APA ITU...", "APA PENGERTIAN...", "JELASKAN..."
  if (
    lower.startsWith('apa itu ') ||
    lower.startsWith('apakah itu ') ||
    lower.startsWith('apa pengertian ') ||
    lower.startsWith('apa yang dimaksud dengan ') ||
    lower.startsWith('jelaskan tentang ') ||
    lower.startsWith('jelaskan ')
  ) {
    const term = trimmed
      .replace(/^(apa itu|apakah itu|apa pengertian|apa yang dimaksud dengan|jelaskan tentang|jelaskan)\s+/i, '')
      .replace(/[?!.]+$/, '')
      .trim();

    return `### Definisi Singkat
**${term}** dalam rumpun sains dan matematika adalah konsep atau besaran terdefinisi yang merepresentasikan sifat, fenomena, relasi fungsional, atau objek telaah ilmiah yang memenuhi kaidah logika dan konsistensi keilmuan.

### Penjelasan Sederhana
Dalam pembelajaran SMA di TI SENANG, pemahaman terhadap **${term}** difokuskan pada pengenalan prinsip dasarnya, relasi antar variabel yang terlibat, serta cara menerapkannya dalam memecahkan persoalan terstruktur.

### Konsep Penting
1. **Identifikasi Besaran:** Menelaah variabel input, parameter tetap, dan satuan ukuran yang berlaku.
2. **Keteraturan Rumus:** Disajikan secara terstandar menggunakan notasi matematika LaTeX/KaTeX.
3. **Penerapan Kontekstual:** Menghubungkan konsep teoritis dengan fenomena sains atau kehidupan nyata.

### Sumber
- Panduan Kurikulum dan Pembelajaran Sains Terpadu — Kementerian Pendidikan Dasar dan Menengah / Kemendikbudristek RI.

*(Jika kamu ingin menelaah rumus spesifik, contoh perhitungan bertahap, atau latihan soal terkait ${term}, silakan sampaikan ya!)*`;
  }

  // =========================================================================
  // 3. SISWA MEMINTA MEMECAHKAN SOAL HITUNGAN / ALJABAR
  //    PERILAKU: PERTAHANKAN PENDEKATAN TEMAN BERPIKIR SOKRATIK BERTAHAP
  //    JANGAN MEMBERIKAN JAWABAN AKHIR LANGSUNG PADA RESPONS PERTAMA!
  // =========================================================================

  // Kasus 1: "1 + 1"
  if (lower.includes('1 + 1') || lower.includes('1+1')) {
    return `Bayangkan kamu punya 1 buah apel 🍎.
Kemudian kamu mendapatkan 1 buah apel lagi 🍎.

Sekarang coba hitung semua apel yang kamu punya.

Ada berapa apel?`;
  }

  // Siswa menjawab '2' setelah analogi apel
  if (lastAiMsg.includes('apel') && (trimmed === '2' || lower.includes('dua') || lower.includes('2 apel'))) {
    return `Benar! 🎉

$$1 + 1 = 2$$

Kamu menemukan jawabannya dengan menggabungkan 1 apel dengan 1 apel lagi. Pemahaman ini adalah fondasi bahwa penjumlahan merupakan operasi penggabungan dua kuantitas.`;
  }

  // Siswa menjawab salah setelah analogi apel
  if (lastAiMsg.includes('apel') && (trimmed === '3' || trimmed === '4' || trimmed === '0' || trimmed === '1')) {
    return `Yuk kita hitung lagi pelan-pelan 😊

Awalnya ada 1 apel 🍎.
Lalu ditambah 1 apel lagi 🍎.

Coba hitung satu per satu:
1... dan satu lagi...

Ada berapa semuanya?`;
  }

  // Kasus 2: "Saya tidak tahu" / kebuntuan
  if (
    lower === 'saya tidak tahu' ||
    lower === 'tidak tahu' ||
    lower === 'nggak tahu' ||
    lower === 'gatau' ||
    lower.includes('belum tahu')
  ) {
    if (lastAiMsg.includes('apel') || lastAiMsg.includes('1 + 1')) {
      return `Tidak apa-apa 😊 Kita buat lebih sederhana.

Angkat 1 jari ☝️.
Sekarang tambahkan 1 jari lagi di tanganmu.

Ada berapa jari yang terangkat sekarang?`;
    }
    return `Tidak apa-apa, mari kita sederhanakan langkahnya bersama-sama 😊

Bisa sebutkan bagian mana yang terasa paling membingungkan? Kita mulai dari petunjuk paling mendasar terlebih dahulu.`;
  }

  // Kasus 3: Soal aljabar linier "2x + 5 = 15"
  if (lower.includes('2x + 5 = 15') || lower.includes('2x+5=15')) {
    return `Kita ingin mencari nilai $x$.

Perhatikan persamaannya:
$$2x + 5 = 15$$

Menurutmu, operasi apa yang perlu kita lakukan pada kedua ruas terlebih dahulu agar suku konstanta $+5$ di ruas kiri menjadi $0$?`;
  }

  // Respon lanjutan aljabar jika siswa menjawab "dikurangi 5" / "-5" / "5"
  if (lastAiMsg.includes('2x + 5 = 15') && (lower.includes('kurang 5') || lower.includes('- 5') || lower === '5' || lower.includes('dikurangi 5') || lower.includes('-5'))) {
    return `Tepat sekali!

Kita kurangkan kedua ruas dengan $5$:
$$2x + 5 - 5 = 15 - 5$$

Maka tersisa:
$$2x = 10$$

Sekarang, untuk mendapatkan nilai $x$, kedua ruas perlu kita bagi dengan berapa?`;
  }

  // Respon lanjutan aljabar jika siswa menjawab "dibagi 2" / "2"
  if (lastAiMsg.includes('2x = 10') && (lower.includes('bagi 2') || lower.includes('2') || lower.includes('dibagi 2'))) {
    return `Hebat! 🎉

Kedua ruas kita bagi dengan $2$:
$$\\frac{2x}{2} = \\frac{10}{2}$$

$$x = 5$$

Kamu berhasil menyelesaikan persamaan ini langkah demi langkah dengan prinsip keseimbangan aljabar!`;
  }

  // Kasus 4: Pecahan "2/3 + 1/3" atau \frac{2}{3} + \frac{1}{3}
  if ((lower.includes('2/3') || lower.includes('\\frac{2}{3}')) && (lower.includes('1/3') || lower.includes('\\frac{1}{3}'))) {
    return `Perhatikan operasi penjumlahan pecahan berikut:

$$\\frac{2}{3} + \\frac{1}{3}$$

Penyebut kedua pecahan sudah sama, yaitu $3$.
Dalam aturan pecahan berpenyebut sama, bagian manakah yang langsung kita jumlahkan? Pembilang atau penyebutnya?`;
  }

  // Kasus 4.1: Rumus Fisika Termal / Azas Black "Q = m.c.dT" atau "Q = m · c · ΔT"
  if (lower.includes('q = m') || lower.includes('q=m') || lower.includes('azas black') || lower.includes('kalor')) {
    return `Rumus perpindahan kalor (Azas Black / Kalor Sensibel) dirumuskan sebagai:

$$Q = m \\cdot c \\cdot \\Delta T$$

Keterangan simbol:
- $Q$ = jumlah kalor yang diserap atau dilepas (Joule / Kalori)
- $m$ = massa zat (kg atau gram)
- $c$ = kalor jenis benda ($\\text{J}/(\\text{kg}\\cdot^\\circ\\text{C})$)
- $\\Delta T$ = perubahan suhu ($T_2 - T_1$) dalam $^\\circ\\text{C}$ atau Kelvin

Variabel mana yang ingin kamu hitung dari rumus ini?`;
  }

  // Kasus 4.2: Akar kuadrat \sqrt atau "akar"
  if (lower.includes('\\sqrt') || lower.includes('akar kuadrat') || lower.includes('akar dari')) {
    if (lower.includes('16')) {
      return `Bentuk akar kuadrat yang kamu tanyakan:

$$\\sqrt{16}$$

Kita mencari bilangan non-negatif yang jika dikalikan dengan dirinya sendiri menghasilkan $16$.
Menurutmu, bilangan berapakah itu? ($n \\times n = 16$)`;
    }
    return `Bentuk akar matematika:
$$\\sqrt{x}$$
Menyatakan operasi invers (kebalikan) dari pemangkatan dua. Contohnya $\\sqrt{25} = 5$ karena $5^2 = 25$. Konsep bilangan di dalam akar apa yang ingin kita selesaikan?`;
  }

  // Respon lanjutan pecahan
  if (lastAiMsg.includes('\\frac{2}{3} + \\frac{1}{3}') && (lower.includes('pembilang') || lower.includes('atas') || lower.includes('2+1') || lower.includes('3/3') || lower === '1')) {
    return `Tepat sekali!

Kita langsung menjumlahkan pembilangnya:
$$\\frac{2 + 1}{3} = \\frac{3}{3} = 1$$

Hasil akhirnya adalah $1$. Pemahamanmu tentang pecahan sangat baik!`;
  }

  // Kasus 5: Pertanyaan imajinatif / non-akademik
  if (lower.includes('hidup di bulan') || lower.includes('tinggal di bulan')) {
    return `Secara nyata, manusia saat ini belum bisa hidup bebas di permukaan Bulan tanpa teknologi pendukung, karena Bulan tidak memiliki atmosfer untuk bernapas dan fluktuasi suhunya sangat ekstrem (antara siang dan malam mencapai ratusan derajat Celsius).

Namun secara sains dan teknologi masa depan (seperti program stasiun bulan Artemis), manusia dapat tinggal di dalam habitat tertutup berpengatur tekanan udara (*pressurized modules*) dengan sistem daur ulang oksigen, air, dan pelindung radiasi kosmik.`;
  }

  // =========================================================================
  // 4. DEFAULT TEMAN BERPIKIR SOKRATIK
  // =========================================================================
  return `Mari kita telaah bersama!

Dalam pembelajaran sains dan matematika di **TI SENANG**, setiap konsep dan soal memiliki struktur logis.

Terkait:
> "${trimmed}"

Langkah awal atau petunjuk apa yang menurutmu paling relevan untuk kita mulai diskusikan terlebih dahulu?`;
}

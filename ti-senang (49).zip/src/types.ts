/**
 * TI SENANG - Type Definitions
 * Teknologi Inovatif untuk Sistem Pembelajaran Adaptif dan Menggembirakan
 * MIPA Fase F (Mindful, Meaningful, Joyful)
 */

export type UserRole = 'admin' | 'guru' | 'murid';
export type UserGender = 'L' | 'P'; // L = Laki-laki (Bapak), P = Perempuan (Ibu)

export interface User {
  id: string;
  fullName: string;
  name?: string;
  username: string;
  role: UserRole;
  gender?: UserGender;
  avatarUrl?: string;
  createdAt: string;
  email?: string;
  nip?: string;
  classId?: string;
  className?: string;
  xp?: number;
  level?: number;
}

export interface Teacher {
  id: string;
  userId: string;
  nip?: string;
  name?: string;
  gender?: UserGender;
}

export interface Student {
  id: string;
  userId: string;
  classId: string;
  name?: string;
  email?: string;
  nisn?: string;
  kelompok?: string;
  user?: User;
  className?: string;
}

export interface ClassRoom {
  id: string;
  className: string;
  createdAt: string;
  academicYear?: string;
}

export interface Subject {
  id: string;
  name: string;
  category?: 'Matematika' | 'Fisika' | 'Kimia' | 'Biologi' | 'Matematika Tingkat Lanjut' | 'Integrasi' | 'Lainnya';
  code: string;
}

export interface TeacherClass {
  id: string;
  teacherId: string;
  subjectId: string;
  classId: string;
}

export interface LearningMission {
  id: string;
  title: string;
  subjectName: string;
  principle: 'Mindful' | 'Meaningful' | 'Joyful';
  xpReward: number;
  status: 'active' | 'completed' | 'pending';
  description: string;
  dueDate: string;
}

export type MissionCoreNumber = 1 | 2 | 3 | 4 | 5 | 6;
export type MissionStatus = 'DRAFT' | 'PUBLISHED';

export type MissionCategoryType =
  | 'pahami_konsep'
  | 'selesaikan_masalah'
  | 'simulasi'
  | 'game'
  | 'latihan_refleksi'
  | 'asesmen';

export type QuestionCategoryType =
  | 'pilihan_ganda'
  | 'benar_salah'
  | 'mcma' // Pilihan Ganda Kompleks / Multiple Choice Multiple Answer
  | 'isian'
  | 'jodohkan'
  | 'mengurutkan';

export interface MatchingPair {
  id?: string;
  premise: string;
  match: string;
}

export interface QuestionItem {
  id: string;
  category: QuestionCategoryType;
  prompt: string;
  options?: string[]; // untuk PG & MCMA
  correctAnswer?: string | string[] | boolean; // jawaban benar
  matchingPairs?: MatchingPair[]; // untuk soal jodohkan
  sequenceItems?: string[]; // untuk mengurutkan (urutan benar)
  explanation?: string; // pembahasan
  points: number;
}

export interface ReflectionQuestionItem {
  id: string;
  prompt: string;
  category: 'pemahaman' | 'kesulitan' | 'perasaan' | 'ide';
}

export interface StudentReflectionSubmission {
  id: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  missionId: string;
  missionTitle: string;
  subjectName?: string;
  submittedAt: string;
  reflectionAnswers: {
    pemahaman?: string;
    tantangan?: string;
    halMenarik?: string;
    rencanaPerbaikan?: string;
    [key: string]: string | undefined;
  };
  selfAssessment: {
    kemandirian: number;
    pemahamanKonsep: number;
    keterampilanAnalisis: number;
    sikapReflektif: number;
    totalScorePercentage: number;
    komitmen?: string;
    keterampilanData?: number;
    sikapKritis?: number;
    komitmenDiri?: string;
    keaktifan?: number;
    pemecahanMasalah?: number;
    kerjasama?: number;
    tanggungJawab?: number;
    [key: string]: any;
  };
  refleksiAnswers?: string[];
  averageSelfScore?: number;
  teacherFeedback?: string;
  mode?: 'online' | 'offline';
  offlineAnswers?: { q1?: string; q2?: string; q3?: string; q4?: string };
  offlineRubricScores?: { label: string; score: number }[];
}

export interface TeacherReflectionConfig {
  classId: string;
  missionId?: string;
  updatedAt: string;
  questions: {
    q1: string;
    q2: string;
    q3: string;
    q4: string;
  };
  rubrics: {
    id: string;
    label: string;
    desc: string;
  }[];
}

export interface MissionMediaResource {
  type: 'pdf' | 'video' | 'link' | 'photo' | 'data';
  title: string;
  url: string; // Bisa link Drive / Youtube / PDF
  description?: string;
}

export interface Mission {
  id: string;
  coreMissionNumber: MissionCoreNumber;
  coreTitle: string; // e.g. "🎯 Misi 1 — Pahami Konsep"
  title: string;
  description: string;
  status: MissionStatus;
  subjectId: string;
  subjectName: string;
  classId: string; // Targets specific class!
  className?: string;
  tpId?: string; // ID Tujuan Pembelajaran terkait
  tpCode?: string; // Kode TP terkait, e.g. "TP-FIS-01"
  timeAllocationJp?: number; // Alokasi JP untuk misi ini (misal 2 JP)
  timeAllocationMinutes?: number; // Menit (misal 90)
  createdByTeacherId?: string;
  createdAt?: string;
  xpReward: number;
  dueDate?: string;
  isAlmeSideMission?: boolean;
  unlocked?: boolean;
  completed?: boolean;
  updatedAt?: string;

  // Tipe & Konten Khusus 6 Kategori Misi TI SENANG
  missionCategory?: MissionCategoryType;
  gameCreationMode?: 'ai' | 'guru'; // Mode pembuatan Misi 4: 'ai' (Buat dengan AI) atau 'guru' (Buat oleh Guru)
  mediaResources?: MissionMediaResource[]; // Link PDF/Video/Foto/Google Drive/Data Pendukung
  gameUrl?: string; // Untuk Misi Game
  problemPrompt?: string; // Teks masalah nyata / perintah instruksi simulasi
  supportingData?: string; // Data pendukung / tabel / foto
  readingModuleText?: string; // Teks modul materi bacaan
  simulationSteps?: string; // Panduan praktikum / langkah kerja simulasi
  simulationUrl?: string; // Link/embed simulator sensor / virtual lab
  triggerQuestions?: string; // Pertanyaan pemantik studi kasus nyata
  analysisGuide?: string; // Panduan analisis saintifik
  gameInstructions?: string; // Instruksi bermain game
  gameTargetScore?: string; // Target capaian / kriteria skor bermain
  reflectionPrompt?: string; // Pertanyaan refleksi mandiri metakognitif siswa
  reflectionGuides?: string[]; // 4 panduan refleksi mendalam
  selfAssessmentAspects?: string[]; // Aspek penilaian diri (kemandirian, konsep, analisis, sikap)
  questions?: QuestionItem[]; // Untuk Misi Latihan (PG, PGK, Isian) & Misi Asesmen (6 tipe soal)
  reflectionQuestions?: ReflectionQuestionItem[]; // Untuk refleksi metakognitif siswa
}

export type MissionJourneyStatus = 'LOCKED' | 'AVAILABLE' | 'IN PROGRESS' | 'COMPLETED';

export interface StudentProgress {
  id: string;
  studentId: string;
  missionId: string;
  progress: number; // 0 to 100
  status: MissionJourneyStatus;
  score: number;
  xp: number;
  startedAt: string;
  completedAt?: string;
}

export interface SensorReading {
  timestamp: number;
  port1: {
    temperature: number; // 🌡 Sensor Suhu Probe (°C)
  };
  port2: {
    humidity: number; // 💧 Sensor Kelembaban (%)
  };
  port3: {
    motion: number; // 🚶 Sensor Gerak (0 atau 1)
  };
  port4: {
    voltage: number; // ⚡ Tegangan (V)
    current: number; // ⚡ Arus (A)
    conductivity: number; // ⚡ Konduktivitas (µS/cm)
  };
  port5: {
    light: number; // 💡 Sensor Cahaya (lux)
  };
}

export interface ExperimentRow {
  waktu: number; // detik atau menit
  suhuAwal: number;
  intensitasCahaya: number;
  suhuAkhir: number;
  timeSeconds?: number;
  tempCelsius?: number;
  deltaT?: number | string;
  heatJoules?: number | string;
  kelembaban?: number;
  tegangan?: number;
  arus?: number;
  gerak?: number;
  rawTimestamp?: string;
  rawSensor?: string;
  rawHasil?: string | number;
  [key: string]: any;
}

export interface ExperimentData {
  experimentId: string;
  studentId: string;
  missionId: string;
  inputMode: 'MANUAL' | 'SIMULATION' | 'SPREADSHEET';
  rows: ExperimentRow[];
  timestamp?: string;
  parameters?: {
    intensitasCahaya: number;
    suhuAwal: number;
    volumeAir: number;
    waktuPengamatan: number;
  };
}

export interface ExperimentSession {
  id?: string;
  experimentId: string;
  studentId: string;
  missionId: string;
  startedAt: string;
  completedAt: string;
  status: 'COMPLETED';
  source: 'SIMULATION' | 'SPREADSHEET';
  readings: SensorReading[];
  recordedAt?: string;
  rows?: ExperimentRow[];
  parameters?: {
    intensitasCahaya: number;
    suhuAwal: number;
    volumeAir: number;
    waktuPengamatan: number;
  };
}

export interface PortfolioEvidence {
  completed: boolean;
  category: string;
  hasData: boolean;
  hasGraph: boolean;
  hasConclusion: boolean;
  hasReflection: boolean;
}

export interface TemanBerpikirEvidence {
  hintLevelReached: number;
  scaffoldingUsed?: boolean;
}

export type AlmeInterventionType =
  | 'remedial'
  | 'pengayaan'
  | 'soal_literasi'
  | 'soal_numerasi'
  | 'latihan_soal';

export interface AlmeQuestionItem {
  question: string;
  options?: string[];
  correctAnswer?: string | number;
  explanation: string;
}

export interface AlmeInterventionContent {
  type: AlmeInterventionType;
  title: string;
  summary: string;
  instructions: string;
  questions: AlmeQuestionItem[];
}

export interface AlmeRecommendation {
  type: 'Remedial' | 'Help Mission' | 'Numeracy' | 'Literacy' | 'Reasoning' | 'Strengthening' | 'Continue' | 'Enrichment' | 'Difficulty Up' | 'Pengayaan' | 'Soal Literasi' | 'Soal Numerasi' | 'Latihan Soal';
  recommendationType?: string;
  interventionType?: AlmeInterventionType;
  interventionCategory?: 'Remedial' | 'Pengayaan' | 'Soal Literasi' | 'Soal Numerasi' | 'Latihan Soal';
  title: string;
  message: string;
  current: number | string;
  target: number | string;
  gap: number | string;
  reason: string;
  actionText: string;
  actionTargetMissionId?: string;
  recommendedMissionId?: string;
  whyExplanation: string;
  difficultyLevel: number; // 1 to 5
  difficulty?: number; // 1 to 5
  xpReward?: number;
  category?: string;
  pedagogicalAction?: string;
  recommendedMissionTitle?: string;
  interventionContent?: AlmeInterventionContent;
}

export interface AnalysisAnswers {
  q1_amat: string;
  q2_analisis?: string;
  q2_pola?: string;
  q3_sebabSuhu?: string;
  q4_hubunganVariabel?: string;
}

export type PortfolioVisibility = 'PRIVATE' | 'CLASS';

export type PortfolioCategory =
  | 'Eksperimen'
  | 'Analisis Data'
  | 'Solusi'
  | 'Refleksi'
  | 'Proyek MIPA'
  | 'Karya Kreatif';

export interface PortfolioAppreciations {
  keren?: number; // 👏 Keren
  menginspirasi?: number; // 💡 Menginspirasi
  menarik?: number; // 🔬 Eksperimennya menarik
  bagus?: number; // 📊 Analisisnya bagus
  kreatif?: number; // ✨ Ide kreatif
  suka?: number; // ❤️ Suka
}

export interface PortfolioItem {
  id: string;
  studentId: string;
  studentName?: string;
  classId?: string;
  className?: string;
  title: string;
  subjectName: string;
  subjectId?: string;
  missionId?: string;
  date: string;
  category: PortfolioCategory;
  xpEarned: number;
  visibility: PortfolioVisibility;
  reflectionSummary: string;
  content?: string;
  description?: string;
  experimentData?: ExperimentData;
  graphData?: Array<{ waktu: number; suhu: number }>;
  analysisAnswers?: AnalysisAnswers;
  conclusion?: string;
  documentation?: string;
  laporanUrl?: string;
  dokumentasiUrl?: string;
  driveLink?: string;
  likesCount?: number;
  likedBy?: Record<string, boolean>;
  comments?: Array<{
    id: string;
    authorId: string;
    authorName: string;
    authorRole: 'guru' | 'murid' | 'admin';
    text: string;
    createdAt: string;
  }>;
  createdAt?: string;
  isFeatured?: boolean; // ⭐ Karya Unggulan (ditandai guru)
  appreciations?: PortfolioAppreciations;
  userAppreciations?: { [userId: string]: string[] }; // Emoji keys given by user
  portfolioEvidence?: PortfolioEvidence;
}

export type SyncQueueType =
  | 'SAVE_PROGRESS'
  | 'SAVE_EXPERIMENT'
  | 'SAVE_REFLECTION'
  | 'SAVE_PORTFOLIO';

export interface SyncQueueItem {
  id: string;
  type: SyncQueueType;
  payload: any;
  createdAt: number;
  syncStatus: 'PENDING' | 'SYNCED';
}

export interface StudentProfileData {
  user: User;
  student: Student;
  className: string;
  xp: number;
  level: number;
  completedMissionsCount: number;
  streakDays: number;
  missions: LearningMission[];
  portfolio: PortfolioItem[];
}

export interface TeacherProfileData {
  user: User;
  teacher: Teacher;
  subjects: Subject[];
  classes: ClassRoom[];
  assignedTeacherClasses: TeacherClass[];
}

export interface TujuanPembelajaran {
  id: string;
  code: string;
  subjectId: string;
  classId?: string;
  title: string;
  description: string;
  targetScore: number;
  timeAllocationMinutes: number; // e.g. 90, 180, 270 menit
  allocatedJp: number; // e.g. 2 JP, 4 JP, 6 JP
  targetMissionCount: number; // Jumlah misi yang disesuaikan dengan Tujuan Pembelajaran dan alokasi waktu
  achievedPercentage: number;
  status: 'Perlu Pendampingan' | 'Cukup' | 'Optimal' | 'Istimewa';
}

export interface AsesmenAwalInput {
  id: string;
  studentId: string;
  studentName: string;
  classId: string;
  subjectId: string;
  diagnosticScore: number; // 0 - 100
  literacyScore: number; // 0 - 100
  numeracyScore: number; // 0 - 100
  reasoningScore: number; // 0 - 100
  readinessLevel: 'Siap Mandiri' | 'Berkembang' | 'Perlu Pendampingan';
  interventionCategory?: string;
  timeAllocation?: string; // (opsional / legacy)
  notes?: string;
  createdAt: string;
  almeRecommendationId?: string;
}

export interface AsesmenAkhirRecord {
  id: string;
  missionId?: string;
  studentId: string;
  studentName: string;
  nisn?: string;
  classId: string;
  className?: string;
  subjectId: string;
  subjectName?: string;
  score: number;
  kktpStatus?: 'Tuntas' | 'Belum Tuntas';
  isKktpMet?: boolean;
  predikat: 'A (Sangat Baik)' | 'B (Baik)' | 'C (Cukup)' | 'D (Perlu Bimbingan)';
  tpMasteryPercentage: number;
  tpMastery?: number;
  catatan: string;
  tanggal?: string;
  soalCount?: number;
  updatedAt?: string;
  gradedAt?: string;
}

export interface AlmeIndividualMission {
  id: string;
  studentId: string;
  title: string;
  description: string;
  subjectId: string;
  subjectName: string;
  recommendedCategory: MissionCategoryType;
  status: 'PENDING' | 'COMPLETED';
  xpReward: number;
  reason: string;
  createdAt: string;
  completedAt?: string;
}

export interface StudentTaskSubmission {
  id: string;
  missionId: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  status: 'SUBMITTED' | 'REVIEWED' | 'GRADED';
  score?: number;
  xpEarned?: number;
  submittedAt: string;
  driveLink?: string;
  documentationUrl?: string;
  reflection?: string;
  conclusion?: string;
  answers?: Record<string, any>;
  teacherFeedback?: string;
  content?: string;
  fileAttachment?: string;
  tpId?: string;
}


